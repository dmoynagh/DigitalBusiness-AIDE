#!/usr/bin/env python3
"""Extract AIDE binder sources and regenerate binders deterministically."""

from __future__ import annotations

import argparse
import hashlib
import re
from pathlib import Path


SOURCE_RE = re.compile(
    r"<!-- BEGIN SOURCE: (?P<name>[^\n]+) -->\n(?P<body>.*?)\n<!-- END SOURCE: (?P=name) -->",
    re.DOTALL,
)


def extract(binder: Path, destination: Path) -> None:
    text = binder.read_text(encoding="utf-8")
    matches = list(SOURCE_RE.finditer(text))
    if not matches:
        raise SystemExit(f"No source blocks found in {binder}")
    destination.mkdir(parents=True, exist_ok=True)
    for match in matches:
        (destination / match.group("name")).write_text(
            match.group("body").rstrip() + "\n", encoding="utf-8"
        )


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()[:12]


def generate(
    destination: Path,
    title: str,
    version: int,
    date: str,
    note: str,
    sources: list[Path],
) -> None:
    lines = [
        f"# {title}",
        "",
        "> **Generated Binder — do not edit directly.** Edit the individual master documents and regenerate the Binder.",
        f"> **Binder Version {version}** ({date}). {note}",
        "",
        "This Binder is a current-context consumption artefact; authoritative masters remain individual files.",
        "",
        "## Binder manifest",
        "",
    ]
    lines.extend(f"- `{p.name}` — sha256 `{digest(p)}`" for p in sources)
    lines.extend(["", "---", ""])
    for index, path in enumerate(sources):
        body = path.read_text(encoding="utf-8").rstrip()
        lines.extend(
            [
                f"<!-- BEGIN SOURCE: {path.name} -->",
                body,
                f"<!-- END SOURCE: {path.name} -->",
            ]
        )
        if index != len(sources) - 1:
            lines.extend(["", "---", ""])
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)

    extract_parser = sub.add_parser("extract")
    extract_parser.add_argument("binder", type=Path)
    extract_parser.add_argument("destination", type=Path)

    generate_parser = sub.add_parser("generate")
    generate_parser.add_argument("destination", type=Path)
    generate_parser.add_argument("--title", required=True)
    generate_parser.add_argument("--version", required=True, type=int)
    generate_parser.add_argument("--date", required=True)
    generate_parser.add_argument("--note", required=True)
    generate_parser.add_argument("sources", nargs="+", type=Path)

    args = parser.parse_args()
    if args.command == "extract":
        extract(args.binder, args.destination)
    else:
        generate(
            args.destination,
            args.title,
            args.version,
            args.date,
            args.note,
            args.sources,
        )


if __name__ == "__main__":
    main()
