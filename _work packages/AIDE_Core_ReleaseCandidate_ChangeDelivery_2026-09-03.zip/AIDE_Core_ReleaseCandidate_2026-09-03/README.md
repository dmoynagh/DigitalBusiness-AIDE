# AIDE Core Release Candidate — 2026-09-03

This package is the furthest truthful execution possible in the current environment.

- `registry-staging/` — 8 immutable, validated Capability Packages and ZIPs.
- `candidate-outputs/` — structurally assembled but **unissued** AIDE Core Set output templates.
- `release-evidence/` — Build Platform selection, 8 WorkPackages, 8 Outcomes, validation and candidate manifest.
- `source-changes/` — one Capabilities OpenItems live-state update recording the exercised Build selection.
- `finalize_after_registry.py` — stamps the actual `AIDE_Core@vN` after Registry Batch release and Set assignment.
- `AIDE_Core_ReleaseCandidate_ChangeDelivery_Instructions_2026-09-03.md` — exact application/continuation instructions.

Do not publish `candidate-outputs/` directly.
