---
name: aide-core-status
description: "Report the exact AIDE Core release marker and resolution provenance packaged with this plugin."
---

# AIDE Core Status

**Issue status:** UNISSUED CANDIDATE

**Set release:** `__AIDE_CORE_SET_RELEASE__`

**Resolution digest:** `2b999844145b775a0e1b025d3266c59636dd91a19d1c2dfd4be5843aac35888e`

**Output:** `aide-core-openai`

This member is generated provenance only; it is not an AIDE Capability.
