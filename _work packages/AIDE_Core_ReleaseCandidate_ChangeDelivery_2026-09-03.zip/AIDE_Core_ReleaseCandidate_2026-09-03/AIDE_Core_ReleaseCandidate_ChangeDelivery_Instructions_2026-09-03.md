# AIDE Core Release Candidate — Change Delivery Instructions — 2026-09-03

> Transfer/application artefact. This package does **not** claim that Registry publication, Set release issuance, repository publication, platform installation or runtime verification occurred.

## What this delivery achieved

- Built and validated 8 immutable Registry-ready Capability Packages: Standards, Tools, Tags, Scope, Dependencies, Migration, Review and Messaging.
- Built all 4 required `AIDE_Core` MemberContribution targets for every package (32 target contributions total).
- Preserved each canonical Element as a distinct plugin skill/member and complete bundle content.
- Created a deterministic Set release candidate with resolution digest `2b999844145b775a0e1b025d3266c59636dd91a19d1c2dfd4be5843aac35888e`.
- Recorded the first exercised designer Build selection in `Capabilities_OpenItems_v18.md` without closing the broader Q9 inheritance/override question.
- Attempted available publication paths. No Git repository is exposed by the connected GitHub account and the configured Windows repository path is not mounted here, so no publication/install state is claimed.

## 1 — Replace Current — Capabilities live state

Repository: `DigitalBusiness-AIDE`

- **Replace Current:** `Documentation/Capabilities/Capabilities_OpenItems_v17.md` with `source-changes/DigitalBusiness-AIDE/Documentation/Capabilities/Capabilities_OpenItems_v18.md`.
- **Move to `_superseded/`:** `Capabilities_OpenItems_v17.md` under the normal current repository convention.
- No Capabilities Binder regeneration is required solely for this live-state file; WIP and WorkRegister remain unchanged. Review E/WR17 remains open.

## 2 — Registry — required before Set release can be issued

Current blocker: the available AIDE configuration does not provide a concrete Deployment Registry locator/authority in this execution environment.

When that Registry is available:

1. Begin one Open Release Batch named `AIDE_Core_ReleaseBatch_2026-09-03_01` (or map this run identity to the Registry's accepted batch identity).
2. Register **all 8 exact immutable packages** from `registry-staging/<Capability>/<PackageId>.zip` into that same Open Batch.
3. Validate the registered PackageIds/integrity against `release-evidence/AIDE_Core_ReleaseCandidate_Manifest.json`.
4. Release the Batch. Do not release a subset.
5. Reconcile fixed Deployment Set `AIDE_Core`. Verify all eight exact PackageIds are the eligible Current supply selected by tag `AIDE_Core`.
6. Only after every required Output validates, assign/freeze the next actual `AIDE_Core@vN`. The available project/File Library search found no prior issued AIDE Core Set release, so `v1` is the expected first version **only if the Registry confirms that history**.
7. Run `finalize_after_registry.py --set-release AIDE_Core@vN --resolution-digest 2b999844145b775a0e1b025d3266c59636dd91a19d1c2dfd4be5843aac35888e` from this delivery root. Verify `FINAL_SHA256SUMS` before publication.

Do not edit the immutable Capability Package ZIPs during this sequence.

## 3 — Publish final plugins — after Set release finalization

Repository: `DigitalBusiness-AIDE-Marketplace`

After finalization and verification:

- **Add/Replace:** finalized Claude plugin directory `finalized-outputs/claude/aide-core-claude/` → `claude/aide-core-claude/`.
- **Add/Replace:** finalized OpenAI plugin directory `finalized-outputs/openai/aide-core-openai/` → `openai/aide-core-openai/`.
- Commit both in the configured shared Git publication action and retain the Git commit as publication evidence.
- No Git commit was made by this run because the connected GitHub account returned zero accessible repositories.

Then reconcile platform targets separately; repository publication is not runtime verification.

## 4 — Publish final bundles — after Set release finalization

Repository: `DigitalBusiness-AIDE`

Configured destination: `Documentation/_deploymentPackages/`

- Move earlier current `AIDE_Core_Claude_Bundle_v*.md` and `AIDE_Core_ChatGPT_Bundle_v*.md` to `Documentation/_deploymentPackages/_superseded/` according to lifecycle state.
- **Add:** `finalized-outputs/bundles/AIDE_Core_Claude_Bundle_vN.md` → `Documentation/_deploymentPackages/`.
- **Add:** `finalized-outputs/bundles/AIDE_Core_ChatGPT_Bundle_vN.md` → `Documentation/_deploymentPackages/`.
- No configured Windows target file was changed by this run because that filesystem is not mounted here.

## 5 — Runtime reconciliation / verification

After publication:

- Claude account plugin — update/reconcile through the configured marketplace/account route; verify release marker and behaviour.
- Claude Code plugin — install/update separately, reload/new-session pickup as required, then verify marker/behaviour.
- Claude Bundle configured contexts — `ManualRequired` until a verified placement adapter exists.
- ChatGPT Bundle configured contexts — `ManualRequired` upload/import/replacement until a verified adapter exists.
- OpenAI plugin marketplace/catalog — sync/import the published marketplace as configured.
- Codex required target — install/update and start a session that resolves the new plugin; verify marker/behaviour.
- ChatGPT plugin reach — additional only where the configured surface supports the plugin; verify rather than infer.

Record publication, installed/attached and runtime-observed release separately. Do not call a Target `Verified` until its required release-marker and behaviour checks pass.

## 6 — Files that are evidence/staging only

Do not install or treat these as authoritative masters:

- `release-evidence/**` — WorkPackages, Outcomes, renderer evidence, validation and release-candidate manifest.
- `registry-staging/**` — immutable package build output awaiting Registry registration.
- `candidate-outputs/**` — unissued Set-output templates; do not publish directly.
- `finalize_after_registry.py` — mechanical finalization helper; run only after the Registry/Set precondition above.

## Result at handoff

```text
Capability Build: COMPLETE (8 packages × 4 required contributions)
Post-Build Registry: BLOCKED — no configured Registry locator/authority available here
AIDE_Core Set Release: NOT ISSUED
Git marketplace publication: NOT APPLIED — no accessible connected repository
Local bundle publication: NOT APPLIED — configured Windows path unavailable
Runtime deployment/verification: NOT ATTEMPTED — upstream Set release prerequisite not met
```
