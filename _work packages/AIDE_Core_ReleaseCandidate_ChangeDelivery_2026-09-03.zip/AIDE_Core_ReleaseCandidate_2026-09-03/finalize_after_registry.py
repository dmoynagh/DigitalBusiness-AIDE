#!/usr/bin/env python3
import argparse, pathlib, re, json, hashlib, shutil
p=argparse.ArgumentParser(description="Finalize the already-built AIDE Core candidate outputs after Registry Batch release and Set release assignment.")
p.add_argument('--candidate-root', default='candidate-outputs')
p.add_argument('--set-release', required=True, help='e.g. AIDE_Core@v1')
p.add_argument('--resolution-digest', required=True)
p.add_argument('--manifest', default='release-evidence/AIDE_Core_ReleaseCandidate_Manifest.json')
p.add_argument('--output-root', default='finalized-outputs')
a=p.parse_args()
m=re.fullmatch(r'AIDE_Core@v(\d+)',a.set_release)
if not m: raise SystemExit('set-release must be AIDE_Core@vN')
manifest=json.loads(pathlib.Path(a.manifest).read_text(encoding='utf-8'))
if manifest.get('ResolutionDigest') != a.resolution_digest:
    raise SystemExit('resolution digest does not match the built release-candidate manifest')
n=int(m.group(1)); semver=f'{n}.0.0'
src=pathlib.Path(a.candidate_root); dst=pathlib.Path(a.output_root)
if dst.exists(): shutil.rmtree(dst)
shutil.copytree(src,dst)
for f in dst.rglob('*'):
    if not f.is_file(): continue
    try: t=f.read_text(encoding='utf-8')
    except UnicodeDecodeError: continue
    t=t.replace('__AIDE_CORE_SET_RELEASE__',a.set_release).replace('__AIDE_CORE_SEMVER__',semver)
    # candidate template already carries the fixed candidate resolution digest; require explicit match.
    if '__AIDE_CORE_RESOLUTION_DIGEST__' in t: t=t.replace('__AIDE_CORE_RESOLUTION_DIGEST__',a.resolution_digest)
    # remove candidate status wording only at authorized finalization boundary.
    t=t.replace('**UNISSUED CANDIDATE — DO NOT REPORT AS DEPLOYED.**  \n','')
    t=t.replace('**Issue status:** UNISSUED CANDIDATE','**Issue status:** Issued')
    f.write_text(t,encoding='utf-8',newline='\n')
# rename bundles
for kind in ['Claude','ChatGPT']:
    pth=dst/'bundles'/f'AIDE_Core_{kind}_Bundle_vN.template.md'
    if pth.exists(): pth.rename(dst/'bundles'/f'AIDE_Core_{kind}_Bundle_v{n}.md')
# emit integrity inventory
rows=[]
for f in sorted(dst.rglob('*')):
    if f.is_file(): rows.append((str(f.relative_to(dst)).replace('\\','/'),hashlib.sha256(f.read_bytes()).hexdigest()))
(dst/'FINAL_SHA256SUMS').write_text(''.join(f'{h}  {p}\n' for p,h in rows),encoding='utf-8',newline='\n')
print(f'Finalized {a.set_release} using semver {semver}; verify and freeze output integrity before publication.')
