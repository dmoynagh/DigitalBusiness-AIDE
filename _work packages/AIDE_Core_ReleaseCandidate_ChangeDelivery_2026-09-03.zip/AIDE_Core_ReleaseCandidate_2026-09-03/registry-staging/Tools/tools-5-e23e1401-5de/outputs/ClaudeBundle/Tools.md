# AIDE Core — Tools contribution

> Capability: `Tools@v5`  
> Build Target: `ClaudeBundle`  
> Output Tag: `AIDE_Core`  
> Composition posture: `MemberContribution`

Canonical Elements follow as unchanged source bodies. Packaging delimiters are non-semantic.

<!-- BEGIN AIDE CORE ELEMENT: AIDE_ToolsProduction@v3 -->
# AIDE Tools Production — Standard

> **Identity:** `AIDE_ToolsProduction@v3`
> **Common name:** Tools Production
> **Version 3** (2026-09-02). Adds value-based dual-audience Contents/Summary production for substantial Tools.

## Contents

- **Purpose and canonical contract** — complete platform-independent Tool semantics.
- **Release rule** — reassessment, LastEvaluated and semantic Element release behaviour.
- **Canonical orientation and output** — Contents/Summary applicability plus returned result.

## Summary

Produce or validate one complete canonical Tool Element from confirmed behaviour without inventing
authority or leaking platform mechanics. Reassessment may advance only `LastEvaluated`; changed
semantics produce a new Element release. Substantial Tools receive useful Contents/Summary
orientation where it improves comprehension and navigation.

## Purpose and inputs

Produce or validate one complete platform-independent canonical Tool Element from the current
Capability Definition, confirmed Tool behaviour and documented production inputs. Resolve Element
identity/release, logical actions, Scope, Dependencies, Migration, prior history and Current Migration.

## Canonical Tool contract

Specify stable outcome identity/common name; actions and triggers; inputs/defaults/preconditions;
ordered procedure and decision authority; escalation; outputs/effects; reporting; failure/partial/
idempotency/resumption semantics. Do not leak generic platform mechanics or infer new authority.

## Release rule

Reassess changed inputs. If Tool meaning is unchanged, update only `LastEvaluated`. If meaning
changes, validate the new canonical outcome, convert Current Migration and confirm the next Element
release. Document version, Element release and Capability release remain distinct.

## Canonical orientation

Apply `AIDE_DocumentationMethodology` and the Tools DocType rule. For a substantial canonical Tool,
provide:

- Contents — a concise map of significant action/decision areas and stable locations; and
- Summary — intended outcome, overall flow, principal decision/effect points and constraints.

Detailed inputs, procedure, failure and idempotency sections remain authoritative. Omit or use an
equivalent structure where the Tool is small/self-evident or the sections would add clutter,
duplication or reduce usability.

## Output

Return the canonical Tool plus production/checkpoint/release result. Platform Build/package/
Deployment remain later concerns.

```yaml
MigrationSummary:
  CurrentVersion: v3
  LatestRequiredVersion: none
  LatestOnUpdateVersion: none

Transition:
  Version: v2
  Posture: None

Transition:
  Version: v3
  Posture: None
```

---
Dependencies: !AIDE_DocumentationMethodology@v28, AIDE_Capability@v2, AIDE_Scope@v2, AIDE_Dependencies@v3, AIDE_Migration@v3
References: Capabilities_Tools_Design_v7, AIDE_UpdateCapabilityElementsTool@v1
<!-- END AIDE CORE ELEMENT: AIDE_ToolsProduction@v3 -->

<!-- BEGIN AIDE CORE ELEMENT: AIDE_UpdateCapabilityElementsTool@v1 -->
# AIDE Update Capability Elements — Tool

> **Identity:** `AIDE_UpdateCapabilityElementsTool@v1`
> **Common name:** Update Capability Elements
> **Version 1** (2026-09-02). First design-side Element production/update Tool.

## Actions

`Evaluate | Update | Validate | Status`

## Procedure

1. Resolve the current Capability Definition, target Elements and documented Element Production inputs.
2. Compare each current input/version with its `LastEvaluated` checkpoint.
3. Reassess potentially stale Elements using the applicable production contract.
4. If meaning is unchanged, update only the evaluated checkpoint.
5. If meaning changes, update and validate the canonical Element, complete Current Migration and
   confirm the next Element release/history.
6. If current inputs conflict or are insufficient, return the smallest actionable defect; do not choose/invent.
7. Update the Capability release only if composition or substantive Capability-level Definition changed.

## Migration from Build Capability v2

Calls that used `AIDE_BuildCapabilityTool@v2` to produce canonical Standards/Tools migrate to this
Tool. Do not reinterpret an unreviewed v2 invocation as Build Capability v3.

---
Dependencies: !AIDE_DocumentationMethodology@v27, AIDE_Capability@v1, AIDE_StandardsProduction@v3, AIDE_ToolsProduction@v2
References: Capabilities_UpdateCapabilityElements_Tool_Design_v1, AIDE_BuildCapabilityTool@v2
<!-- END AIDE CORE ELEMENT: AIDE_UpdateCapabilityElementsTool@v1 -->

<!-- BEGIN AIDE CORE ELEMENT: AIDE_BuildCapabilityTool@v6 -->
# AIDE Build Capability — Tool

> **Identity:** `AIDE_BuildCapabilityTool@v6`
> **Common name:** Build Capability
> **Version 6** (2026-09-03). Makes WorkPackage mapping and coordinated post-Build Registry authority explicit.

## Actions

`Request | ValidateReadiness | Authorise | Status`

## Procedure

1. Resolve the current Capability Definition, released Elements/composition and production currency.
2. Require resolved Build Platforms and at least one explicit `Build:true`.
3. Resolve one unambiguous effective Build Target Profile/Definition set, including governed Profile
   membership/request selection and any Capability-specific overrides.
4. Resolve applicability, required reach, conformance/degradation permission and output Tags for
   every selected target; block unsupported applicable requirements rather than dropping them.
5. Resolve applicable Capability Build/platform rules, Registry-compatible package acceptance and
   explicit post-Build request. When Registry publication is requested, resolve
   `AIDE_DeploymentRegistryTool@v2` action `Register` and configured Registry. Direct registration
   is valid for an independent package; an established coordinated multi-package change requires
   the same Open Release Batch for every participating registration.
6. If an Element may be stale, return `UpdateElementsRequired`; do not produce it here.
7. Validate that the requested force scope, if any, cannot imply false semantic release changes.
8. Create/authorise the self-contained `AIDE_WorkPackage@v3` for Capability Builder:
   - Inputs carry Definition, released Elements, selected Build Platforms, exact source snapshot
     and effective Profile/Definitions;
   - RequiredOutputs carry all applicable required target outputs and the complete Package;
   - Constraints carry reach/applicability/conformance/degradation, required Tags, force scope and
     post-Build request/inputs or explicit none;
   - Acceptance carries freshness, target completeness, semantic preservation, provenance,
     integrity and package validation; and
   - Return requires Package/Build evidence plus separate post-Build/Registry state.
9. Return WorkPackage identity, readiness, selected platforms/targets, post-Build request and
   blockers. Keep actual post-Build result outside the validated package.

## Required migration from v2

`AIDE_BuildCapabilityTool@v2` canonical production calls move to
`AIDE_UpdateCapabilityElementsTool@v1`. Calls retaining Build-request orchestration use the current
`AIDE_BuildCapabilityTool` release; v3 names the Required transition checkpoint, not the release to
which current invocations are pinned.

```yaml
MigrationSummary:
  CurrentVersion: v6
  LatestRequiredVersion: v3
  LatestOnUpdateVersion: none

Transition:
  Version: v3
  Posture: Required
  Action: Review every v2 invocation; move Element production to AIDE_UpdateCapabilityElementsTool@v1 and retain only Build-request orchestration here.

Transition:
  Version: v4
  Posture: None

Transition:
  Version: v5
  Posture: None

Transition:
  Version: v6
  Posture: None
```

---
Dependencies: !AIDE_DocumentationMethodology@v28, AIDE_Capability@v3, AIDE_CapabilityBuild@v4, AIDE_WorkPackage@v3
References: Capabilities_BuildCapability_Tool_Design_v6, AIDE_UpdateCapabilityElementsTool@v1, Capabilities_BuildTargetProfile_Design_v2, AIDE_DeploymentRegistryTool@v2
<!-- END AIDE CORE ELEMENT: AIDE_BuildCapabilityTool@v6 -->

<!-- BEGIN AIDE CORE ELEMENT: AIDE_CapabilityBuilderTool@v4 -->
# AIDE Capability Builder — Tool

> **Identity:** `AIDE_CapabilityBuilderTool@v4`
> **Common name:** Capability Builder
> **Version 4** (2026-09-03). Validates snapshot-relative Tags and executes post-Build workflow without freezing it into Package bytes.

## Procedure

1. Accept/validate the authorised WorkPackage under `AIDE_Build`.
2. Resolve current Definition, released Elements, selected Build Platforms, effective Build Target
   Profile/Definitions and applicable rules.
3. Determine affected internal work; reuse/cache only with valid provenance and integrity.
4. Build every selected platform and applicable required target output to the complete external
   contract. Do not silently omit a target or invent `NotApplicable`/degradation.
5. Run/validate applicable Tag Builders against the exact authoritative source snapshot resolved
   by the WorkPackage; fail visibly if freshness cannot be established.
6. Assemble the complete `CapabilityPackage` Registry envelope: Logical Package Identity,
   PackageId/integrity, Capability/Element composition, source/production/Build provenance,
   Profile/Definition revisions, complete Build Target output/member identities and integrity,
   Build-owned composition posture, effective Tags, reach/applicability/conformance/degradation,
   dependencies/Migration, tag-freshness/source-snapshot evidence and namespaced extensions.
7. Validate the complete Package against WorkPackage Acceptance.
8. Freeze the validated PackageId payload; do not write post-Build request, Registry receipt or
   lifecycle state into it.
9. Invoke the WorkPackage-nominated post-Build Tool if successful. Registry publication uses
   `AIDE_DeploymentRegistryTool@v2`; direct registration is valid for an independent package, while
   an established coordinated change requires the common Open Release Batch.
10. Return WorkPackage Outcome with actual Package and separate post-Build/Registry receipt state.

Force build never increments semantic releases. Missing/unknown required platform or governing
capability state blocks rather than being assumed.

---
Dependencies: !AIDE_DocumentationMethodology@v28, AIDE_CapabilityBuild@v4, AIDE_Build@v8, AIDE_WorkPackage@v3, AIDE_Tags@v3
References: Capabilities_CapabilityBuilder_Tool_Design_v4, Capabilities_BuildTargetProfile_Design_v2, AIDE_DeploymentRegistryTool@v2
<!-- END AIDE CORE ELEMENT: AIDE_CapabilityBuilderTool@v4 -->
