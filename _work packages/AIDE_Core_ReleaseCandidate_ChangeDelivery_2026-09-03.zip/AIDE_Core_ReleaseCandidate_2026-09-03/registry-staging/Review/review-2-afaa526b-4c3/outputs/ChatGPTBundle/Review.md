# AIDE Core — Review contribution

> Capability: `Review@v2`  
> Build Target: `ChatGPTBundle`  
> Output Tag: `AIDE_Core`  
> Composition posture: `MemberContribution`

Canonical Elements follow as unchanged source bodies. Packaging delimiters are non-semantic.

<!-- BEGIN AIDE CORE ELEMENT: AIDE_Review@v4 -->
# AIDE Review — Standard

> **Identity:** `AIDE_Review@v4`
> **Common name:** Review
> **Version 4** (2026-09-02). Defines Contents and Review Result as the orientation surface for substantial durable Review documents.

---

## Contents

- **Purpose and roles** — applicability, governing principles, Lead/Reviewer responsibilities and trigger contract.
- **Review definition** — Input Contract, Type, Level, Mode, Reviewer resolution and request construction.
- **Lifecycle and evidence** — routing, response, states, Rounds, Findings, disposition, re-review and scope.
- **Result and persistence** — high-level outcome, durable document orientation and evidence retention.
- **Safety and seams** — failure handling and external environment/Messaging dependencies.

## Summary

Review introduces a proportionate independent reasoning path while keeping the Lead responsible for
the work and every disposition. A resolved Input Contract drives one or more recorded Rounds through
Findings, authorised change and re-review to a concise Review Result.

Substantial durable Review documents use Contents where navigation adds value and position Review
Result near the top as the Summary-equivalent surface. Detailed Round/Finding/evidence records remain
authoritative; no duplicative Summary is required.

## Purpose

Provide a stable way to bring a meaningfully independent reasoning source into work, obtain
insight or challenge shaped to the actual objective, manage the exchange proportionately to risk,
and return a clear result without transferring ownership of the work to the Reviewer.

## Applicability

Apply this Standard whenever an activity is identified as a Review, whether initiated directly,
recommended by an AI, required or recommended by a governing Standard/workflow, configured by a
WorkPackage, or triggered by consequence/risk.

A mechanical self-check, document-format validation, or independent research task is not a Review
merely because it tests something. It uses this Standard only when it creates the Lead/Reviewer
assessment lifecycle defined here.

## Governing principles

- Review introduces a second reasoning path to improve substantive integrity, decisions, and risk
  management.
- The Lead owns the work and its final disposition. The Reviewer owns Findings.
- A Finding is evidence, not an instruction.
- Type, Level, Mode, and Reviewer are independent Review inputs.
- Review effort and stopping confidence are proportionate to Level.
- Review may discover beyond authorised scope; execution may not silently expand beyond it.
- Review owns the assessment exchange and its Review/Round state. Messaging owns AI-MESSAGE relay/receipt semantics; environment/platform routes own concrete delivery mechanics.
- A separate Review document is optional; reconstructable Review evidence is not.
- Review stops at justified confidence or explicit judgment, not perfection.

## Roles

### Lead

The Lead owns the current work, states or validates the Review objective and authorised scope,
supplies an accurate account of the work, handles the response, owns Finding disposition, and
preserves the net coherence and simplicity of the resulting work.

### Reviewer

The Reviewer provides the separate reasoning path. It applies the effective Type, Level, and Mode;
reports material Findings with evidence/reasoning and uncertainty; and may offer possible remedies
without treating them as requirements.

### Role assignment

Roles are contextual. The AI/platform responsible for or initiating the current work is normally
the Lead. The environment resolver supplies a meaningfully independent default Reviewer and may be
overridden explicitly.

The same AI family is not permanently Lead or Reviewer. Roles can reverse across work, and actual
models may change between Rounds. Every Round records the actual Lead model and Reviewer model.

## Trigger contract

A Trigger provides:

- `Source` — user/Lead, AI recommendation, governing Standard/workflow/project rule, WorkPackage,
  or risk/consequence condition;
- `Basis` — why Review is warranted now;
- `Posture` — `Required`, `Recommended`, or `Optional`;
- `Subject`; and
- optional suggested `Type` and `Level`.

The trigger source owns its criteria. Review resolves and executes the resulting Review.

An AI should recommend Review where consequence, reach, difficulty of reversal, uncertainty,
novelty, weak evidence, or a valuable second perspective makes the expected benefit material.
Recommendation does not become requirement unless the governing source makes it one.

`Stress Test` may be recommended but starts only after explicit user direction.

## Review Input Contract

Before the first request is sent, resolve:

```yaml
ReviewInput:
  Trigger:
    Source: <identity>
    Basis: <reason>
    Posture: Required | Recommended | Optional
  Subject: <thing or question under review>
  Objective: <what the Review is trying to learn or determine>
  AuthorisedScope: <execution boundary>
  Type: Check | Inspect | Evaluate | Robust | Stress Test | <omitted when DirectProfile is used>
  DirectProfile: <optional purpose, learning objective, lens/method, response expectations>
  Level: Low | Standard | Medium | High | Extreme
  Mode: Full | Blind
  Reviewer:
    Identity: <review source>
    RequiredCapabilities: <where applicable>
  ReviewMaterial: <context, artefacts, evidence, constraints, assumptions, uncertainties>
  ResponseExpectations: <useful payload>
  ContinuationPosture: <Type and Level informed>
```

`DirectProfile` lets the caller supply the profile content for a one-off Review. It does not add a
sixth Type or create a new reusable Profile.

Values resolve in this order:

1. direct instruction for this Review;
2. trigger or work-item configuration;
3. selected Review Profile defaults;
4. shared Review operating defaults;
5. environment-local availability/defaults.

Defaults fill gaps and never silently override an explicit value. Surface a conflict between
authoritative sources rather than choosing one without notice. Ask only for input that cannot be
safely resolved from the work and available configuration.

## Type

Type defines why the Review is being performed, what it is trying to learn, the lens/method the
Reviewer applies, and the expected response.

The standard profiles are defined only in `AIDE_ReviewProfiles@v2`:

```text
Check → Inspect → Evaluate → Robust → Stress Test
```

This ordering describes increasing distance from the current claim/artefact/design, not increasing
thoroughness. Level controls intensity.

## Level

Level defines the assurance effort, capability, independence, evidence, iteration, and stopping
confidence justified by the work.

Assess Level over four factors:

- `Consequence` — severity if wrong;
- `Reach` — downstream breadth;
- `Reversibility` — cost/difficulty of correction; and
- `Uncertainty` — novelty, ambiguity, assumption load, and evidence weakness.

Use judgment, not a score. Do not average away one serious factor. Work size and complexity may
inform but do not determine Level.

| Level | Meaning | Review posture |
|---|---|---|
| Low | Low consequence; easy to reverse | Quick focused pass; surface obvious/material issues; stop early. |
| Standard | Normal consequence and uncertainty | Normal independent review with reasonable evidence checking and further Rounds where useful. |
| Medium | Material consequence, uncertainty, reach, or difficulty of reversal | Stronger capability; broader examination; challenge assumptions; normally re-review substantive change. |
| High | Significant consequence or systemic risk | Deep independent review; substantial evidence; high confidence threshold; persist while material issues remain. |
| Extreme | Exceptional or critical consequence | Best justified available capability; maximum practical independence/evidence; very high confidence threshold; rare. |

Higher Level increases strength, not Type. Actual model names and routes are environment data.

### Dynamic Level

Reassess Level when a material Finding changes the understood consequence, reach, reversibility,
or uncertainty. Escalate or de-escalate accordingly, record a short reason, and re-resolve
Reviewer/model/route for the next Round when needed.

A Level change affects subsequent behaviour and does not invalidate completed Rounds.

## Mode

Mode controls exposure to the Lead's existing solution or reasoning:

- `Full` — expose the current approach, reasoning, artefacts, and relevant context.
- `Blind` — withhold selected solution/reasoning content to reduce anchoring and elicit an
  independent approach.

Blind Mode does not withhold information needed to answer the objective accurately. Record what
was deliberately withheld.

## Reviewer resolution

Resolve Reviewer after Type, Level, Mode, and required evidence/capabilities are known, and before
final request packaging.

The Reviewer is a review source/family, not a permanently pinned model version. Environment data
supplies:

- available reviewer identities/families;
- actual models and capability tiers;
- evidence/file/repository/web capabilities;
- independence characteristics;
- routes from the current surface;
- availability, usage, access, and cost constraints; and
- fallbacks.

Review does not define where that environment data is stored.

## Review Request

Build the request to maximise the chance of an effective and accurate Review for the objective.
Include:

- Review and Round identity;
- Subject, Objective, and AuthorisedScope;
- effective Type purpose/lens and Level expectations;
- Mode and deliberate withholding;
- sufficient relevant ReviewMaterial;
- constraints, assumptions, uncertainties, and evidence;
- specific questions/instructions; and
- ResponseExpectations.

The request is accurate, sufficient, relevant, attackable, and non-persuasive. It exposes the work
without arguing the Lead's conclusion or including context merely because it exists.

## Routing and communication

Review hands Messaging/the resolved route:

```yaml
ReviewDelivery:
  CurrentSurface: <surface>
  Reviewer: <resolved reviewer>
  ReviewId: <identity>
  RoundId: <identity>
  Request: <complete review request>
```

Environment/platform routing owns concrete route selection/send-return mechanics and packaging constraints; Messaging owns reusable AI-MESSAGE envelope/receipt/reconciliation semantics,
delivery state, and failures.

For indirect/manual communication, use `AIDE_Messaging` and its AI-MESSAGE envelope. Supply the
user with destination, requested model/capability, instructions, a ready-to-copy message, and exact
return instructions. Use a Markdown file where the request is exceptionally large.

Do not embed platform-to-platform routes or transport implementation in Review.

Review/Round identity in the substantive Review payload is authoritative for Review lifecycle
semantics; Messaging correlation remains transport-level evidence. Positive disagreement between
the two is a quarantine condition, not a tie to resolve.

## Response contract

Act on a response only after it is correlated to one Review and Round.

```yaml
ReviewResponse:
  ReviewId: <identity>
  RoundId: <identity>
  Reviewer: <actual reviewer identity>
  ActualModel: <actual model, if known>
  Status: Complete | Partial | ClarificationNeeded | Failed
  Payload: <Type-defined review response>
  ContinuationSignal: <optional material-value signal>
```

Preserve the response unchanged in the Round record. A partial or clarification-needed response
keeps the Review open. An uncorrelated response is held for clarification and is not dispositioned.

## Lifecycle and states

The stable Review states are:

```text
Initiated
Awaiting Response
Response Received
Continuing
Complete
Escalated
```

Normal flow:

```text
Initiated
  → request resolved and sent
Awaiting Response
  → correlated response returned
Response Received
  → Lead handles Findings and change
Continuing | Complete | Escalated
```

There is no hard Round limit. After every handled response, determine whether:

- another Round is likely to add material information;
- unresolved Findings remain material to the current Level;
- Review-driven changes require verification;
- sufficient confidence has been reached; or
- the remaining matter is a user/work-owner judgment.

Continue, complete, or escalate from that assessment. Do not continue merely because further
imperfections can be imagined.

## Round record

Rounds are append-only. Each Round records:

- Review/Round identity and number;
- actual Lead identity/model;
- actual Reviewer identity/model;
- effective Type, Level, and Mode;
- request and supplied material;
- route/transport reference where useful;
- response unchanged;
- Findings and Lead dispositions arising from the Round;
- changes made;
- outcome; and
- reason for continuing, completing, or escalating.

Later Rounds may refer to earlier Rounds but do not replace them.

## Findings and disposition

A Finding preserves:

- observation;
- materiality/why it matters;
- evidence or reasoning;
- uncertainty;
- likely consequence/risk; and
- optional remedy.

The Lead records one or more dispositions:

```text
Accept | Decline | Defer | Supersede | Investigate | Change | Escalate
```

The Finding remains unchanged. A remedy is advisory until adopted. The Lead records the resulting
change or reason for no change and the re-review decision.

## Re-review

Re-review evaluates the revised outcome and whether it resolves the Finding without introducing
new problems.

| Level | Re-review expectation |
|---|---|
| Low | Re-review when the Lead judges the change material. |
| Standard | Re-review material changes or significant Finding resolutions. |
| Medium | Normally re-review substantive changes in reviewed scope. |
| High | Return substantive Review-driven changes before completion. |
| Extreme | Re-review material remediations as part of the cycle; the resulting state normally must survive Review. |

Minor editorial/local change that does not materially alter what was assessed does not require a
new Round.

## Scope control

Review may identify an issue outside AuthorisedScope. Neither Lead nor Reviewer may implement it
under the current authority.

Mark the Finding `OutOfScope` and return:

- the Finding;
- why it matters;
- likely consequence/risk; and
- suggested direction where useful.

The director/work owner decides re-scope, separate work, defer, or decline. This rule applies
strictly to WorkPackages and directed work.

## Review Result

Every completed or escalated Review returns:

```yaml
ReviewResult:
  ReviewId: <identity>
  Subject: <subject>
  ScopeReviewed: <scope>
  Type: <named Type, or DirectProfile>
  FinalLevel: <level>
  Mode: <mode>
  ReviewersAndModels: <actual Round history summary>
  Outcome: Complete | Escalated | Unresolved
  MaterialFindings: <summary with dispositions>
  ChangesWithinScope: <summary>
  ReReviewStatus: <required/completed/not required/outstanding>
  OutOfScopeFindings: <summary>
  ResidualRisks: <accepted or unresolved differences>
  CompletionReason: <why Review stopped>
```

The Result tells the director of work what was reviewed, what mattered, what changed, what remains,
and what needs attention without requiring reconstruction of the exchange.

## Persistence

Every Review preserves the Review Result and enough Round evidence to reconstruct what happened.

Use the surrounding work record for routine/transient Review where it can preserve the required
semantics, including a WorkPackage Outcome.

Create a separate Documentation Methodology `Review` document where Review is substantive
design-side evidence, High/Extreme, materially multi-Round, carries significant unresolved or
out-of-scope Findings, is required as assurance evidence, or is explicitly requested.

A durable Review document follows the governing document methodology. It contains the Review
Result and the complete Rounds or stable references to them. Review does not create a competing
record type.

For a substantial durable Review document, include a concise semantic Contents block when it adds
navigation value and place the current Review Result near the top after Contents as the
Summary-equivalent surface. Do not add a separate duplicative Summary when Result already performs
that role. Detailed Round/Finding/evidence records remain authoritative. Transient Review embedded
in a surrounding record may use that record's existing orientation.

## Failure handling

- Preserve request, identity, and route state after delivery failure so the same Round can be
  retried or rerouted.
- Quarantine a response whose Review/Round payload identity positively disagrees with Messaging
  transport correlation; do not attach or disposition it until clarified.
- Do not report delivery success as Review completion.
- Do not silently skip Required Review; record an authorised exception and accepted consequence.
- Do not mark a Finding resolved because a change was attempted.
- Do not infer permission to expand scope from a Finding.
- Surface unavailable independence/capability rather than claiming the selected Level was met.

## External dependencies

Review consumes but does not own:

- environment configuration for reviewer/model/route availability and local mappings; and
- `AIDE_Messaging` for AI-MESSAGE relay/receipt/reconciliation on indirect/manual cross-context
  transport.

Concrete direct-route mechanics remain environment/platform Build concerns. Communication ownership
is no longer an open architecture seam; the environment settings/storage home remains external.

```yaml
MigrationSummary:
  CurrentVersion: v4
  LatestRequiredVersion: none
  LatestOnUpdateVersion: none

Transition:
  Version: v4
  Posture: None
```

---
Dependencies: !AIDE_DocumentationMethodology@v28, Capabilities_Review_Design_v4, AIDE_Messaging@v2
References: AIDE_ReviewProfiles@v2, Capabilities_Design_v14, Capabilities_Tools_Design_v7
<!-- END AIDE CORE ELEMENT: AIDE_Review@v4 -->

<!-- BEGIN AIDE CORE ELEMENT: AIDE_ReviewProfiles@v2 -->
# AIDE Review Profiles — Standard

> **Identity:** `AIDE_ReviewProfiles@v2`
> **Common name:** Review Profiles
> **Version 2** (2026-09-01). Makes current Review contract references versionless while preserving the five established Review Types/defaults.

---

## Purpose

Define reusable Review methods over the `AIDE_Review` Input Contract so a caller can select a
purposeful review lens without rebuilding its instructions each time.

## Profile contract

Every reusable Review Profile defines:

- `Name` — stable Type identity;
- `Purpose` — why the Type exists;
- `LearningObjective` — what the Review is trying to find out;
- `Boundary` — how far outside the current claim/artefact/design it may step;
- `LensMethod` — how the Reviewer approaches the work;
- `EvidenceExpectations` — what verification, comparison, or external evidence is expected;
- `ExpectedResponse` — what a useful payload contains;
- `DefaultLevel`;
- `DefaultMode`; and
- `ContinuationGuidance`.

Type defaults fill unresolved inputs. They do not override an explicit value or the effective Level
assessment for the actual task.

## Shared Type rules

- Choose Type from what the Review is trying to learn, not how important the work is.
- Type determines method; Level scales how strongly that method is applied.
- A Type may expose a more serious issue and justify switching Type in a later Round. Record the
  change and reason rather than silently broadening the active Type.
- Report material issues first. Do not propose complexity merely because an imperfection can be
  removed.
- Evidence and remedies are proportionate to Level and the Review objective.
- Level-based re-review rules in `AIDE_Review` apply to every Type.

## Default matrix

| Type | Boundary | Default Level | Default Mode | Core question |
|---|---|---:|---|---|
| Check | Criterion-bound | Low | Full | Is this specific proposition or condition correct/satisfied? |
| Inspect | Artefact-bound | Standard | Full | What is wrong, missing, inconsistent, weak, or materially improvable? |
| Evaluate | Outcome-bound | Medium | Full | Does this approach deliver the intended outcomes well, and how could it be better? |
| Robust | Design/framing-bound | High | Full | Is the design itself sound, and where could its assumptions or structure fail? |
| Stress Test | Environment/adversary-bound | Extreme | Full | How does this withstand capable adversarial, competitive, or demanding external scrutiny? |

`Evaluate + Blind` is the normal form for an independent approach before the Lead's solution is
shown. Blind Mode remains an explicit selection because many Evaluate Reviews need to assess the
current approach directly.

## Check

### Purpose

Determine whether a specific proposition, requirement, calculation, contract point, expected
result, or condition is correct or satisfied.

### Learning objective

> Is the stated criterion met, and what evidence supports that answer?

### Boundary

Check is criterion-bound. It verifies the stated target and does not become a general search for
defects. If the check exposes a broader material issue, report it and recommend an appropriate
Type/Level change.

### Lens and method

- identify the exact claim or criterion;
- establish the authoritative evidence or test;
- verify the result and relevant assumptions;
- distinguish pass, fail, qualified/conditional result, and unknown;
- identify any evidence gap that prevents a reliable answer.

### Evidence expectations

Use evidence directly relevant to the criterion. At higher Levels, independently verify the
source, calculation, test, or trace from requirement to result rather than accepting an assertion.

### Expected response

- answer: Pass, Fail, Qualified, or Unknown;
- criterion applied;
- supporting evidence/test;
- defect or unmet condition where present;
- uncertainty/evidence gap; and
- any broader issue requiring another Type.

### Defaults and continuation

- `DefaultLevel: Low`
- `DefaultMode: Full`
- normally complete after a reliable answer;
- continue for missing evidence, material ambiguity, or verification of a material correction;
- do not broaden into Inspect without an explicit Type change.

## Inspect

### Purpose

Examine an existing artefact, implementation, document, code change, plan, or outcome for defects,
omissions, inconsistencies, drift, and meaningful improvement.

### Learning objective

> What is wrong, missing, inconsistent, weak, or materially improvable in what exists?

### Boundary

Inspect is artefact-bound. It accepts the authorised design/intent as the governing frame and
tests the artefact against it. It can identify a better local approach, but it does not redesign
the governing model unless a Finding justifies an Evaluate or Robust escalation.

### Lens and method

- inspect the artefact itself rather than only its description;
- compare against authoritative requirements, intent, scope, interfaces, and expected outcomes;
- find defects, omissions, inconsistencies, weak implementation choices, and scope drift;
- consider straightforward alternatives where they materially improve the outcome;
- prioritise by materiality rather than volume.

### Evidence expectations

Use the artefact and its authoritative contract. At higher Levels, inspect supporting tests,
source material, dependency behaviour, execution evidence, and relevant adjacent effects.

### Expected response

- material Findings in priority order;
- affected location or element;
- evidence/reasoning and consequence;
- contract/intent comparison where applicable;
- uncertainty; and
- possible local improvement where useful.

### Defaults and continuation

- `DefaultLevel: Standard`
- `DefaultMode: Full`
- continue where material defects remain, accepted fixes materially change the artefact, or the
  current artefact cannot yet be tested reliably;
- recommend Evaluate/Robust when the defect appears to originate in the governing approach rather
  than the artefact.

## Evaluate

### Purpose

Assess whether a concept, design, decision, plan, or proposed approach delivers the intended
outcomes well and how it could be improved.

### Learning objective

> Does this approach meet the objective well, where does it fall short, and are there materially
> better alternatives?

### Boundary

Evaluate is outcome-bound. It may challenge important assumptions and compare credible
alternatives, but it begins from the premise that the proposed direction is a plausible design
worth assessing. It improves within or around that design; Robust may reject the design/framing
itself.

### Lens and method

- test fitness against objective, success criteria, constraints, and authorised scope;
- examine trade-offs, consequences, dependencies, and key assumptions;
- identify strengths, weaknesses, gaps, and avoidable complexity;
- compare credible alternatives where they could materially improve outcomes;
- avoid redesigning for marginal gains;
- distinguish decision input from a mandatory remedy.

### Evidence expectations

Use stated outcomes, constraints, evidence, and alternatives already considered. At higher Levels,
verify important assumptions and compare stronger external or internal approaches where available.

### Expected response

- overall assessment;
- material strengths and weaknesses;
- outcome/constraint fit;
- key trade-offs and consequences;
- credible alternatives and comparative advantage where relevant;
- recommendation or decision input;
- unresolved uncertainties.

### Defaults and continuation

- `DefaultLevel: Medium`
- `DefaultMode: Full`
- prefer `Blind` where the objective is an independent approach and exposure to the current
  solution would anchor the Reviewer;
- continue while materially different evidence, alternatives, or revised decisions are changing
  the assessment;
- complete when the Lead has sufficient decision-quality input for the Level, including an
  explicit residual uncertainty where necessary;
- change to Robust where the design/framing itself becomes the central question.

## Robust

### Purpose

Find material weaknesses normal inspection or evaluation may miss, including weaknesses caused by
the chosen design or framing itself.

### Learning objective

> Is this the right design, where can it fail or behave unexpectedly, and would a materially
> different design avoid the problem?

### Boundary

Robust is design/framing-bound. It may step back from the current design, challenge the problem
framing and foundational assumptions, and perform a blank-sheet comparison where consequence or
Findings justify it.

### Lens and method

- challenge foundational and operational assumptions;
- probe edge cases, unusual interactions, degraded states, and failure paths;
- look for hidden dependencies, second-order effects, and invalid safeguards;
- distinguish material failure modes from theoretical imperfections;
- step back and ask whether the problem is being solved in the wrong way;
- compare materially different designs when that exposes or avoids structural weakness;
- test whether added safeguards create disproportionate complexity.

### Evidence expectations

Inspect available evidence for assumptions, failure behaviour, interfaces, and safeguards. At
higher Levels, seek independent verification, precedents, or simulations where they materially
improve confidence. External threat/comparator research is not mandatory unless the objective
requires it; that is a defining Stress Test emphasis.

### Expected response

- material weaknesses/failure modes;
- trigger conditions and affected outcomes;
- evidence/reasoning and uncertainty;
- likely consequence and reach;
- challenged assumptions or framing;
- materially different design alternatives where justified;
- whether action appears proportionate; and
- residual risks or areas requiring judgment.

### Defaults and continuation

- `DefaultLevel: High`
- `DefaultMode: Full`
- use `Blind` where an independent blank-sheet framing is more valuable than direct critique;
- continue while material structural Findings, changed assumptions, or revised designs warrant
  further examination;
- substantive review-driven changes are normally returned under the High re-review posture;
- complete when material failure paths and design alternatives are adequately understood for the
  Level, not when every theoretical risk is removed.

## Stress Test

### Activation

Stress Test is user-activated only. An AI may recommend it and explain the expected value, but no
Standard, workflow, WorkPackage default, or autonomous risk trigger starts it without explicit
user direction.

### Purpose

Determine how well the subject withstands deliberate, intelligent, and sustained challenge,
including exploitation of weakness and comparison against strong external alternatives.

### Learning objective

> What could a capable adversary, competitor, hostile environment, demanding customer, auditor,
> or expert discover, exploit, outperform, or use against this?

### Boundary

Stress Test is environment/adversary-bound. It steps outside the current design to test the work
against hostile or demanding reality, known failures, credible threats, strong comparators, and
external scrutiny.

### Lens and method

- assume weaknesses will be actively sought rather than encountered accidentally;
- challenge foundational assumptions and combine weaknesses into realistic paths;
- identify plausible adversary/challenger objectives and capabilities;
- test technical, architectural, operational, commercial, process, and human surfaces selected by
  the Review objective;
- seek relevant known attacks, failures, precedents, solutions, benchmarks, and competitors;
- compare resilience against credible stronger approaches;
- distinguish theoretical possibilities from realistically exploitable/material weakness;
- identify where the subject is stronger as well as weaker;
- assess whether proposed mitigation is proportionate to the protected outcome.

### Optional Stress Test parameters

- `AdversaryOrChallenger`
- `AdversaryObjective`
- `SubjectScope`
- `ProtectedOutcomesOrAssets`
- `ChallengeSurfaces`
- `ComparatorSet`
- `Constraints`
- `AssumptionsToAttack`
- `EvidenceAccess`
- `MaterialityThreshold`

Resolve only the parameters relevant to the actual objective.

### Evidence expectations

Actively seek external examples, comparators, known failures, threat paths, benchmarks, or stronger
solutions where the Reviewer has the capability and the scope permits it. If required evidence
access is unavailable, state the limitation; do not present a speculative scan as an Extreme
Stress Test.

Research performed to support the Review remains evidence gathering inside this Review. A
standalone request to discover options or facts without the Review lifecycle belongs to Research,
not this Type.

### Expected response

- strongest material weaknesses first;
- realistic challenge/exploitation or outperformance scenarios;
- external examples/comparators and their relevance;
- consequence, likelihood/materiality, and uncertainty;
- performance of current safeguards/design against the challenge;
- comparative strengths as well as weaknesses;
- residual risks that cannot reasonably be eliminated;
- proportionate mitigation directions; and
- questions requiring user/Lead judgment.

### Defaults and continuation

- `DefaultLevel: Extreme`
- `DefaultMode: Full`
- continue while material challenge paths, combined weaknesses, comparator evidence, or material
  remediations remain insufficiently tested for Extreme confidence;
- re-review material remediations as part of the cycle;
- stop when major paths are adequately explored and dispositioned, further Findings are marginal
  or speculative, or the residual issue is an explicit strategic/risk judgment;
- never pursue complexity solely to eliminate a theoretical weakness.

## Type changes and combined objectives

Use one primary Type per Round so the request has a clear learning objective. Where a Review needs
multiple lenses:

- sequence them as separate Rounds or separate Reviews when each needs a distinct response;
- state the primary Type and a narrow secondary question where separation would add no value; or
- change Type after a Finding exposes a materially different question.

Record each Round's effective Type. Do not create hybrid names such as `Robust-Deep`; Level already
expresses intensity.

## Five-use-case defaults

| Use case | Normal starting profile | Common variation |
|---|---|---|
| Design exploration | Evaluate + Medium + Full | Blind for an independent approach; Robust when framing itself is uncertain. |
| Pre-confirmation design | Evaluate + Medium | Robust + High for foundational or hard-to-reverse design. |
| WorkPackage authoring | Check + Low or Inspect + Standard | Raise Level when incorrect scope/contract would have material downstream reach. |
| Build plan | Evaluate + Medium | Robust + High for consequential architecture or weak assumptions. |
| Post-execution | Inspect + Standard | Robust + High where implementation or design integrity requires broader challenge. |

These are starting defaults. Effective Level follows consequence, reach, reversibility, and
uncertainty; explicit work configuration or instruction may select another Type/Mode.

```yaml
MigrationSummary:
  CurrentVersion: v2
  LatestRequiredVersion: none
  LatestOnUpdateVersion: none

Transition:
  Version: v1
  Posture: None

Transition:
  Version: v2
  Posture: None
```

---
Dependencies: !AIDE_DocumentationMethodology@v26, Capabilities_Review_Design_v3, AIDE_Review@v3
<!-- END AIDE CORE ELEMENT: AIDE_ReviewProfiles@v2 -->

<!-- BEGIN AIDE CORE ELEMENT: AIDE_ReviewTool@v3 -->
# AIDE Review — Tool

> **Identity:** `AIDE_ReviewTool@v3`
> **Common name:** Review
> **Version 3** (2026-09-01). Quarantines positive disagreement between Review/Round payload identity and Messaging transport correlation.

---

## Purpose

Initiate, resolve, construct, route, record, continue, and conclude one proportionate independent
Review lifecycle while preserving Lead ownership, authorised scope, Round evidence, and the
external communication boundary.

## Logical actions

```yaml
Tool:
  Identity: AIDE_ReviewTool@v3
  CommonName: Review
  PrimaryInvocation: review
  LogicalActions: [Start, Receive, Continue, Status, Complete]
```

Platform Build may render these actions through commands, skills, UI actions, or conversational
intent without changing their semantics.

## Trigger and Scope

Run on explicit Review request, accepted AI recommendation, governing Review Trigger, WorkPackage
Review posture, qualifying consequence/risk trigger, or receipt of a correlated response for an
active Review.

The Tool may recommend Review when consequence, reach, reversibility, uncertainty, novelty, weak
evidence, or a valuable second reasoning path makes the expected benefit material. It must not
turn recommendation into requirement. Stress Test starts only on explicit user direction.

```yaml
Scope:
  Context: >
    Apply when a purposeful independent assessment exchange is requested, accepted, required,
    recommended for material value, or resumed from a correlated Review response.
```

## Start

1. Resolve the Review Trigger, Subject, Objective, Authorised Scope, Type/profile, Level, Mode,
   Reviewer requirements, material, response expectations, and continuation posture under
   `AIDE_Review@v3`.
2. Use direct instruction, work configuration, Review Profile defaults, shared defaults, then
   environment data in that precedence.
3. Infer strong low-risk facts and state them; batch questions for genuinely missing inputs;
   escalate authoritative conflicts.
4. Resolve a meaningfully independent Reviewer/model/route from the environment. If the requested
   Level cannot be met, surface the shortfall rather than claiming it was performed.
5. Shape sufficient relevant, attackable, non-persuasive material. In Blind Mode withhold only the
   anchoring content needed to achieve the objective.
6. Create Review/Round identity and the purpose-shaped Review Request.
7. Preserve the request/material list before handing it to the `AIDE_Messaging` / resolved route.
8. Record route/delivery state and set the Review to `Awaiting Response`.

For an indirect/manual route, use `AIDE_Messaging` and provide a copy-ready request plus
exact return instructions; Review does not implement transport itself.

## Receive

1. Correlate the substantive payload to exactly one Review and Round.
2. Where Messaging transport correlation is available, compare it with the payload identity; a
   positive disagreement is quarantined and is not attached/dispositioned.
3. Preserve the response unchanged and record actual Reviewer/model.
4. Record response status: Complete, Partial, ClarificationNeeded, or Failed.
5. Hold an uncorrelated, ambiguous, or positively cross-layer-mismatched response for clarification; do not disposition it.
6. Surface material Findings to the Lead while preserving Reviewer ownership of Finding text.
7. Record Lead disposition, in-scope changes, re-review need, out-of-scope findings, and residual
   risk.

## Continue

After a usable response/change:

1. reassess consequence, reach, reversibility, and uncertainty;
2. record any Level change and reason;
3. re-resolve Reviewer/model/route if needed;
4. apply Level-specific re-review expectations;
5. continue only while another Round is likely to add material value; and
6. set `Continuing`, `Complete`, or `Escalated` without imposing a fixed Round cap.

Review discovery never silently expands authorised execution scope.

## Status

Return Review identity/state, Subject, current Type/Level/Mode, Reviewer/model/route where known,
Round count/current Round, response state, unresolved material Findings/dispositions, re-review
requirement, out-of-scope findings, and next action.

## Complete

Produce the `ReviewResult` required by `AIDE_Review@v3`: scope reviewed, effective Type/final Level/
Mode, actual Reviewer/model history, outcome, material Findings and Lead dispositions, changes,
re-review state, out-of-scope Findings, residual risks, and completion reason.

Store the result and reconstructable Round evidence in the surrounding work record for transient
Review or in a durable Documentation Methodology Review artefact where the persistence rule
requires it.

## Failure and integrity

- Required Review cannot be silently skipped; authorised exception and consequence are recorded.
- Delivery failure preserves request/route state for retry/reroute.
- Partial/clarification response keeps Review open.
- Positive disagreement between Review/Round payload identity and Messaging transport correlation is
  quarantined until clarified.
- Transport success is not substantive Review completion.
- A Finding is not resolved merely because a fix was attempted.
- Reviewer/model change is explicit in the next Round.
- Re-running status/receive handling must not duplicate Round evidence or dispositions.

```yaml
MigrationSummary:
  CurrentVersion: v3
  LatestRequiredVersion: none
  LatestOnUpdateVersion: none

Transition:
  Version: v1
  Posture: None

Transition:
  Version: v2
  Posture: None

Transition:
  Version: v3
  Posture: None
```

---
Dependencies: !AIDE_DocumentationMethodology@v26, AIDE_Review@v3, Capabilities_Review_Tool_Design_v3, AIDE_Messaging@v2, AIDE_ReviewProfiles@v2
<!-- END AIDE CORE ELEMENT: AIDE_ReviewTool@v3 -->
