# AIDE Core — Migration contribution

> Capability: `Migration@v2`  
> Build Target: `ClaudeBundle`  
> Output Tag: `AIDE_Core`  
> Composition posture: `MemberContribution`

Canonical Elements follow as unchanged source bodies. Packaging delimiters are non-semantic.

<!-- BEGIN AIDE CORE ELEMENT: AIDE_Migration@v3 -->
# AIDE Migration — Standard

> **Identity:** `AIDE_Migration@v3`
> **Common name:** Migration
> **Version 3** (2026-09-02). Defines the aggregate-operation seam and authoritative-corpus treatment while preserving per-artefact Migration semantics.

---

## Contents

- **Transition contract** — postures, summaries, owner declarations and affected-use/update triggers.
- **Execution integrity** — ordering, saved checkpoints, outcomes, failure state and resumability.
- **Dependency constraints** — exact-version blocks and supported-baseline handling.
- **Aggregate operation seam** — authoritative selection plus Required-Migration and Update behaviour.

## Summary

Migration applies owner-declared version transitions to one dependent artefact at a time. Required
work gates affected reliance; OnUpdate work waits for a qualifying save; None requires no consumer
transformation. Only verified saved state advances dependency conformance checkpoints, and partial
success remains durable and resumable.

`AIDE_UpdateTool` may orchestrate this behaviour over Domains, session Domains, Documentation
Topics, explicit artefacts or criteria-selected sets. It owns aggregate selection and reporting,
but each artefact remains governed by this Standard and `AIDE_MigrationTool`. Required-Migration
selection does not sweep OnUpdate-only artefacts; explicit aggregate Update reconciles Required and
OnUpdate work for every selected authoritative artefact.

## Purpose

Safely move a dependent artefact from its last proven dependency conformance checkpoint toward the
currently available dependency version using owner-declared transitions rather than inferred deltas.

## Transition posture

Every released migratable capability version declares exactly one posture:

```text
Required | OnUpdate | None
```

- `Required` — applicable work must complete before affected use.
- `OnUpdate` — old state remains usable; apply on the next modification/save.
- `None` — no state change is required for existing consumers.

Posture is version-level. Items inside one version do not mix postures.

## MigrationSummary

Expose a compact summary:

```yaml
MigrationSummary:
  CurrentVersion: v20
  LatestRequiredVersion: v18
  LatestOnUpdateVersion: v19
  SupportedBaseline: v8   # optional
```

Use the summary as a cheap negative/possible-work test. It does not replace detailed transition
history or Scope evaluation.

Where skill headers or equivalent metadata are eagerly loaded/discoverable, platform builds should
surface this summary there and load detailed transition instructions only when the summary indicates
possible work.

## Transition declaration

For each released version:

```yaml
Transition:
  Version: v18
  Posture: Required | OnUpdate | None
  Scope: <optional AIDE_Scope declaration>
  Change: <why existing consumers are affected>
  Items:
    - <ordered transition instruction>
  Success: <how completion is proven>
```

`None` may contain only version and posture.

Transition instructions must be explicit enough to produce the required state and establish
success. They may invoke existing Tools. Do not encode generic platform packaging/invocation
mechanics in the canonical transition.

## Required check

When an artefact is about to be relied upon for relevant use:

1. query its versioned dependencies;
2. compare each checkpoint with `LatestRequiredVersion`;
3. load detailed transition history only where Required work may exist;
4. evaluate Scope/current state; and
5. if applicable Required work remains, migrate before affected use continues.

There is no general Migration startup sweep. `!!` remains the Dependencies startup-presence
posture.

## OnUpdate

When an artefact is modified/saved, reconcile pending migration work through the current available
version.

OnUpdate does not block ordinary use. If Required work causes a save, apply pending applicable
OnUpdate work in that same update where possible.

## Ordering

- Discover relevant pending work before changing the artefact.
- Process dependencies of the artefact being processed in their declared order unless a more specific
  governing order applies. A saved conformance checkpoint creates no ordering by itself; mutual
  conformance checkpoints between artefacts create no cross-artefact migration order.
- Process versions oldest to newest.
- Process items within one version in declared order.
- Re-evaluate applicability before each version.
- Stop on unresolved conflict rather than silently choosing.

## Checkpoint

The dependency conformance version is the last **saved, proven** checkpoint.

- Do not advance it because a newer version merely exists.
- Persist a new checkpoint only when the artefact itself is updated/saved.
- `None` and `NotApplicable` count as traversed for the next saved checkpoint.
- On partial success, persist only through the last successful version.

## Outcomes

`Completed` — applicable work succeeded.

`NotApplicable` — the dependency applies but the transition does not; treat the version as traversed
for the next saved checkpoint.

`Deferred` — applicable work was authoritatively postponed; do not advance through it; maintain a
Migration-owned temporary state entry and surface the consequence.

`Failed` — execution could not complete; discard partial changes from the failed version, preserve
prior successful work/checkpoints, maintain temporary state, and report noisily.

## Failure state

On defer/failure, write/update a compact owner-labelled state entry using the generic document-state
location/rendering supplied by the governing document methodology. Include enough information to
understand the current condition, and where known state what would make the migration succeed.
Remove the Migration-owned entry after a later successful update resolves it.

## Exact-version constraints

`X@!vN` is a hard present dependency constraint owned by `AIDE_Dependencies`, not a saved
conformance checkpoint or ordinary Migration gap. If exact vN is unavailable, affected use or
migration requiring the dependency is blocked and another version may not silently substitute.
Migration reports the dependency block and does not move/relax the pin by inference. Changing the
pin is an explicit dependent-artefact modification.

## Supported baseline

Retain detailed history needed to migrate from the oldest supported conformance version to current.
If `SupportedBaseline` is declared, a consumer older than it is outside the normal migration path
and requires explicit recovery/upgrade handling.

## Failure and safety

- Missing required transition history → fail loudly.
- Dependency version regression → report; do not treat as forward migration.
- Dependency state changes mid-run → stop and resume after state stabilises.
- Concurrent artefact modification → do not overwrite newer work.
- Ambiguous/contradictory transition instruction → stop and identify the owning version.
- Re-running resumes from persisted successful checkpoints and must not duplicate completed work.

## Aggregate operations and authority

`AIDE_UpdateTool` owns aggregate target resolution, authoritative-corpus selection, orchestration
and whole-operation reporting. Supported target forms are one Domain, multiple Domains, current
session Domains, a Documentation Topic, explicit artefacts and criteria-selected sets inside an
authorised boundary.

Mutation is limited to authoritative artefacts within the selected target and work authority.
External-owner/consuming artefacts encountered through reachability or dependency resolution are
reported and skipped unless independently selected through an authoritative target with authority
to modify them. Multi-Domain selection does not imply Domain inheritance or merging.

For aggregate **Required Migration**, select/invoke Apply only where applicable Required work is
outstanding. Do not select an artefact solely for OnUpdate work. If Required work causes a save,
normal per-artefact OnUpdate-through-current behaviour still applies.

For aggregate **Update**, the explicit request is a qualifying update for each selected authoritative
artefact. Invoke per-artefact Update and reconcile applicable Required and OnUpdate work through
current where possible.

The aggregate result never advances dependency checkpoints itself. Per-artefact Migration advances
only through proven saved state and reports Completed, NotApplicable, Deferred or Failed truthfully.
Preserve successful artefacts when another fails and report overall partial completion.

Governed documents participate through their genuine `AIDE_DocumentationMethodology` dependency.
Do not create or require a synthetic universal `AIDE_Doc` dependency solely as a migration hook.

```yaml
MigrationSummary:
  CurrentVersion: v3
  LatestRequiredVersion: none
  LatestOnUpdateVersion: none

Transition:
  Version: v1
  Posture: None

Transition:
  Version: v2
  Posture: None

Transition:
  Version: v3
  Posture: None
```

---
Dependencies: !AIDE_DocumentationMethodology@v28, Capabilities_Migration_Design_v3, AIDE_Dependencies@v3, AIDE_Scope@v2
References: AIDE_MigrationTool@v3, AIDE_UpdateTool@v1, AIDE_Domain
<!-- END AIDE CORE ELEMENT: AIDE_Migration@v3 -->

<!-- BEGIN AIDE CORE ELEMENT: AIDE_MigrationTool@v3 -->
# AIDE Migration — Tool

> **Identity:** `AIDE_MigrationTool@v3`
> **Common name:** Migration
> **Version 3** (2026-09-02). Executes one-artefact Migration under optional aggregate Update orchestration.

---

## Contents

- **Purpose, actions and inputs** — the per-artefact execution contract.
- **Check, Apply, Update, Resume and Status** — logical behaviours and checkpoint handling.
- **Integrity, reporting and aggregate seam** — failure safety, resumability and caller interaction.

## Summary

This Tool checks and executes `AIDE_Migration` for one target artefact, preserves only proven saved
progress, resumes without replaying completed work and reports every blocker or partial result.
Aggregate corpus selection is owned by `AIDE_UpdateTool`, which may invoke this Tool but cannot
alter its per-artefact transition or checkpoint semantics.

## Purpose

Check, apply, update, resume, and report migration of dependent artefacts under
`AIDE_Migration@v3`, preserving truthful saved conformance checkpoints and durable partial
progress.

## Logical actions

```yaml
Tool:
  Identity: AIDE_MigrationTool@v3
  CommonName: Migration
  PrimaryInvocation: migration
  LogicalActions: [Check, Apply, Update, Resume, Status]
```

Platform Build may render these actions as slash commands, skills, UI actions, or conversational
intents without changing their semantics.

## Trigger and inputs

Run when affected use requires a Required check, an artefact modification qualifies for OnUpdate,
a migration action is requested, unresolved Migration state is resumed, or another governing
Standard/Tool invokes Migration.

Resolve one target artefact, dependencies and Dependency Query facts, applicable `MigrationSummary`,
detailed transitions when needed, current operation/authority, exact-version constraint result, and
existing Migration-owned state.

Infer safe low-cost facts; ask once for genuinely missing information; escalate substantive
ambiguity or authority conflict.

## Check

1. Query relevant versioned dependencies.
2. For use, compare checkpoints to `LatestRequiredVersion`.
3. For update, compare checkpoints to current/OnUpdate summary state.
4. Load detailed history only where the summary indicates possible work.
5. Evaluate supported baseline and Scope.
6. Return pending Required/OnUpdate work, traversable None/NotApplicable state, defer/failure state,
   and blocking conditions.
7. Make no artefact change.

## Apply

1. Resolve all relevant pending work before changing state.
2. Process dependencies by declared processing precedence unless specifically overridden.
3. Process versions oldest to newest and items in declared order.
4. Re-evaluate applicability before each version.
5. Apply items and verify each version's `Success` condition.
6. Preserve durable success stepwise.
7. When Required causes a save, continue through pending applicable OnUpdate/None versions to
   current where possible.
8. Save only proven state and advance checkpoints only through successfully traversed saved state.
9. Remove Migration-owned temporary state when resolved.

## Update

Perform the intended artefact modification together with all applicable Required and OnUpdate work
through current. Do not stop merely because Required work exists: the operation is already a
qualifying save event.

If work cannot complete, preserve only the last successful state/checkpoint and surface the
unresolved condition.

## Resume

Read persisted checkpoints/state, re-resolve current dependency facts, confirm earlier durable
success, and continue from the first unresolved version without replaying completed work.

## Status

Report artefact, dependency, checkpoint, available/current version, summary relation, pending
Required/OnUpdate work, supported-baseline result, clear/deferred/failed state, and next action.

## Failure and integrity

- Failed version: discard that version's partial changes; keep prior successful work/checkpoint;
  write/update compact Migration-owned state and report noisily.
- Deferred: preserve authorised deferral and consequence; do not advance through it.
- Concurrent artefact change: do not overwrite newer work.
- Moving dependency facts: stop and resume against stable state.
- Missing/ambiguous transition: stop and identify the unresolved owner decision rather than infer it.
- Unsatisfied exact-version constraint: block affected use, report the required exact version, and do
  not substitute/move the pin through Migration.

Check/Status are read-only and idempotent. Apply/Update/Resume are resumable and must not duplicate
already completed version work.

## Reporting

Summary reporting states what was checked/applied, resulting checkpoints, and anything still
blocking or needing attention. Failure, defer, unsupported baseline, exact-version constraint failure, and
conflict always surface regardless of narration preference.

## Aggregate caller seam

`AIDE_UpdateTool` may invoke this Tool once per artefact after resolving an authorised aggregate
selection. Do not expand that resolved target, mutate reachable external-owner artefacts or report
aggregate completion. Return the target's selected transitions, saved checkpoints, skips, blockers,
failure/defer state and next action so the caller can compose a truthful whole-operation report.

```yaml
MigrationSummary:
  CurrentVersion: v3
  LatestRequiredVersion: none
  LatestOnUpdateVersion: none

Transition:
  Version: v1
  Posture: None

Transition:
  Version: v2
  Posture: None

Transition:
  Version: v3
  Posture: None
```

---
Dependencies: !AIDE_DocumentationMethodology@v28, AIDE_Migration@v3, AIDE_Dependencies@v3, Capabilities_Migration_Tool_Design_v3
References: AIDE_Scope@v2, AIDE_UpdateTool@v1
<!-- END AIDE CORE ELEMENT: AIDE_MigrationTool@v3 -->

<!-- BEGIN AIDE CORE ELEMENT: AIDE_UpdateTool@v1 -->
# AIDE Update — Tool

> **Identity:** `AIDE_UpdateTool@v1`
> **Common name:** Update
> **Version 1** (2026-09-02). Introduces aggregate Required-Migration and Update orchestration over authorised AIDE targets.

---

## Contents

- **Target and authority** — supported aggregate selectors and authoritative-corpus boundary.
- **Actions** — Resolve, Check Required, Apply Required, Update and Status.
- **Execution integrity** — ordering, partial completion, idempotency and reporting.

## Summary

Use this Tool to apply migration/update behaviour across one or more Domains, current session
Domains, a Documentation Topic, explicit artefacts or a criteria-selected set. The Tool resolves
and reports the aggregate selection, but delegates each artefact's transition work and checkpoint
advancement to `AIDE_MigrationTool`.

Apply Required selects only artefacts with outstanding applicable Required work. Update is a
qualifying update for every selected authoritative artefact and reconciles its applicable Required
and OnUpdate work. Consuming/external-owner artefacts remain report-only unless separately selected
with authority.

## Logical actions

```yaml
Tool:
  Identity: AIDE_UpdateTool@v1
  CommonName: Update
  PrimaryInvocation: update
  LogicalActions: [Resolve, CheckRequired, ApplyRequired, Update, Status]
```

Run on explicit user/work-owner request or authorised governing Standard/Tool invocation.
`SessionDomains` is a target selector, not an automatic startup sweep. Platform automation requires
its own authority and does not change `AIDE_Migration` trigger semantics.

## Target

Accept exactly one:

```yaml
Target:
  Kind: Domain | Domains | SessionDomains | DocumentationTopic | Artefacts | Criteria
  Value: <identity/list/query where required>
```

Resolve membership and current authoritative artefacts through the applicable Domain,
Documentation Topic/Index and Working Context contracts. Multiple Domains remain separate;
selection does not create inheritance or merge semantics.

Criteria may use owner-supplied type, identity, dependency/checkpoint, Tags/Scope,
migration-state/posture and current/authoritative facts inside an explicitly bounded corpus.

## Authority

Mutate only artefacts that are both authoritative within the resolved target and within current
work authority. Report and skip consuming copies, external-owner sources, dependency-reachable
artefacts outside the target, unresolved authority and excluded candidates. Do not expand to
dependency closure or infer authority from filesystem reachability.

## Resolve

Read-only: return the deterministic candidate classification and selected authoritative corpus,
including every exclusion or ambiguity.

## Check Required

Read-only: invoke per-artefact Migration Check and report outstanding applicable Required work.
Behind-current or OnUpdate-only state does not by itself select an artefact for required action.

## Apply Required

Invoke per-artefact Apply only where Required work is outstanding. Do not sweep OnUpdate-only
artefacts. If Required work saves an artefact, allow normal per-artefact reconciliation through
pending applicable OnUpdate/None versions.

## Update

Treat the explicit request as a qualifying update for every selected authoritative artefact and
invoke per-artefact Update. Reconcile applicable Required and OnUpdate work through current where
possible. Do not invent substantive content merely to advance metadata; save only truthful proven
state.

## Status

Return current aggregate selection/progress, prior failure/defer state where available and next
actions without mutation.

## Ordering and integrity

Use explicit target order, otherwise authoritative corpus order or stable identity order, and
report it. This is operational order only. Each artefact retains `AIDE_Migration` dependency,
version and item order.

Resolve/CheckRequired/Status are read-only. ApplyRequired/Update are resumable and must not duplicate
proven work. Detect concurrent artefact changes and never overwrite newer authority.

## Partial completion

Preserve successful artefact updates/checkpoints when another target fails or defers. Continue with
independent targets where safe. Return `Partial`/`Failed` with every outstanding target; never claim
aggregate completion from partial per-artefact success.

## Reporting

Report target/action, resolved boundaries/authority, selected artefacts, exclusions and unresolved
candidates, per-artefact result/change/checkpoints, skipped/current/NotApplicable outcomes,
blockers/failures/deferrals and aggregate status/next action.

## Ownership boundary

This Tool owns only aggregate target resolution, selection, orchestration and reporting.
`AIDE_Migration`/`AIDE_MigrationTool` own each artefact's transition discovery, ordering, success,
failure/defer state, durable progress and dependency-checkpoint advancement.

Use genuine declared dependencies. Governed documents use `AIDE_DocumentationMethodology`; do not
create a synthetic universal `AIDE_Doc` dependency solely as an update/migration hook.

```yaml
MigrationSummary:
  CurrentVersion: v1
  LatestRequiredVersion: none
  LatestOnUpdateVersion: none

Transition:
  Version: v1
  Posture: None
```

---
Dependencies: !AIDE_DocumentationMethodology@v28, AIDE_Migration@v3, AIDE_MigrationTool@v3, AIDE_Dependencies@v3, AIDE_Scope@v2
References: Capabilities_Update_Tool_Design_v1, AIDE_Domain, AIDE_Index@v2, AIDE_Tags@v2
<!-- END AIDE CORE ELEMENT: AIDE_UpdateTool@v1 -->
