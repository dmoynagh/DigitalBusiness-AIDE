# AIDE Core — Tools Capability Build WorkPackage

> WorkPackage: `AIDE_Core_Tools_Build_01`  
> Contract: `AIDE_WorkPackage@v3`  
> Build orchestration: `AIDE_BuildCapabilityTool@v6` / `AIDE_CapabilityBuilderTool@v4`

```yaml
WorkPackage:
  Objective: Build one complete immutable Registry-compatible Capability Package for Tools@v5 under AIDE_Core Profile v2.
  AuthorisedScope: Preserve current released semantic Elements; render all four required AIDE_Core target contributions; do not change semantic releases or platform policy.
  Inputs:
    CapabilityDefinition: Capabilities_Tools_Definition_v6.md
    CapabilityRelease: Tools@v5
    SourceSnapshotDigest: b3c4798c516d9f3d86eeeb4eb6f2d4f1ae6b33d67bb60f3bb8fd26260fd8916a
    BuildPlatforms: [Claude=Build:true, ChatGPT=Build:true, OpenAI=Build:true]
    BuildTargetProfile: AIDE_Core@ProfileRevision-v2
  RequiredOutputs: [ClaudePlugin, ClaudeBundle, ChatGPTBundle, OpenAIPlugin, CapabilityPackage]
  Acceptance: Complete four-target output, semantic preservation, AIDE_Core Tags, source-snapshot freshness, provenance, integrity and package validation.
  Constraints:
    Conformance: FullUnlessDeclaredOverride
    Degradation: none declared
    Force: absent
    PostBuildTool: AIDE_DeploymentRegistryTool@v2 Register
    ReleaseBatch: AIDE_Core_ReleaseBatch_2026-09-03_01
  Review: Governing review only; no additional result review triggered for mechanical rendering.
  Return: Package evidence plus separate Registry result.
  WorkRegisterItems: none
```
