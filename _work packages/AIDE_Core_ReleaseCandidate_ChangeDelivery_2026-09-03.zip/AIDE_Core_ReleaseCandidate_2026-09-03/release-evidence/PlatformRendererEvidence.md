# AIDE Core — Platform Renderer Evidence

## Build-selection decision

The design owner explicitly selected every current `AIDE_Core` member and every required Profile target for this run. The operational Build Platforms are therefore resolved as `Build:true` for Claude, ChatGPT and OpenAI for the target representations required by Profile v2. No new selection mechanism or inheritance model is introduced.

## Representation mechanics used

- **ClaudePlugin** — skills-only Claude plugin contribution; final candidate uses `.claude-plugin/plugin.json` and `skills/<skill>/SKILL.md`.
- **OpenAIPlugin** — skills-only OpenAI plugin contribution; final candidate uses `.codex-plugin/plugin.json` and `skills/<skill>/SKILL.md`.
- **ClaudeBundle / ChatGPTBundle** — Markdown member contributions preserving complete canonical Element source bodies and assembled in stable logical Capability order.

Current official renderer references verified during the run:

- Claude Code plugins: https://code.claude.com/docs/en/plugins
- OpenAI Build Plug-ins: https://learn.chatgpt.com/docs/build-plugins

Runtime reach, installation and session pickup are not inferred from structural build validation.

## Validation boundary

No `claude` or `codex` CLI executable is available in this execution container, so provider CLI validation was not performed here. Structural validation, manifest parsing, complete-member checks, source/integrity hashing and semantic-preservation checks are performed locally. Runtime verification remains a Deployment Target concern.
