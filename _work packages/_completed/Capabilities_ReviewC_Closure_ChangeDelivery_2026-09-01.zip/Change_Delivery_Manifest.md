# Change Delivery Manifest

- `Capabilities_Architecture_Review_2026-09-01-3_Capabilities_v1.md` — sha256 `c361f2878a9db25c8994c5ef6d9ea306b3c4090b59cf8f856578fec6181f9519`
- `Capabilities_Binder_Core_v5.md` — sha256 `f484050e38d21dc4d158f03fff1604ad19a9665d3081cc7dda88deefca68a255`
- `Capabilities_Index_v19.md` — sha256 `5db0a87aaa50b16cf29a495e33c06a0cf08804bfd80933dd807bf73d612e841b`
- `Capabilities_WIP_v15.md` — sha256 `e9f536d589b7fb8a6264cf10af3230ab378ccb9b3fabe4451abfe16be6f9b525`
- `Capabilities_WorkRegister_v17.md` — sha256 `e87a80cf1613458aac904b7ae31ecd110d974943b46dba2906801710b329ed81`
- `Change_Delivery_Instructions.md` — sha256 `42c1fa1bb9efd636e8a793b76ed3b0628f189bccebe15e65fc8d0b1d3e14a7e5`
- `ReviewC_R3_LeadDisposition_gpt-006.md` — sha256 `7e82aeef5419a75738a8d17aaea1d47adb5b5a9648f67ddb491b2c1693c25df3`
