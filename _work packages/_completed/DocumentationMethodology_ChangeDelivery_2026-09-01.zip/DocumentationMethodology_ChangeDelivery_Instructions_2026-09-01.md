# Documentation Methodology — Change Delivery Instructions — 2026-09-01

## Purpose

Apply the completed Documentation Methodology v22 substantive pass that combines the authorised
Review A `DocumentationTopic` seam clarification with the already-confirmed single top-level-topic
WIP-series rule. No Review B material is included.

## Destination

Apply all replacements in the same current Documentation Methodology master folder that presently
contains the v6/v18/v19/v21 masters and `DocumentationMethodology_Binder_v2.md`. This package does
not authorise a folder rename or ownership move.

## Replace Current

Add these files as the new Current masters and replace the corresponding current versions:

- `DocumentationMethodology_Index_v7.md` — replaces `DocumentationMethodology_Index_v6.md`.
- `DocumentationMethodology_Design_v19.md` — replaces `DocumentationMethodology_Design_v18.md`.
- `DocumentationMethodology_Decisions_v20.md` — replaces `DocumentationMethodology_Decisions_v19.md`.
- `AIDE_DocumentationMethodology_Standard_v22.md` — replaces `AIDE_DocumentationMethodology_Standard_v21.md`; current identity is `AIDE_DocumentationMethodology@v22`.
- `DocumentationMethodology_Guide_v22.md` — replaces `DocumentationMethodology_Guide_v21.md`.
- `DocumentationMethodology_Binder_v3.md` — replaces generated `DocumentationMethodology_Binder_v2.md`.

## Move to superseded

Move the replaced issued versions to the project’s normal Superseded physical location under the
current Working Practices convention:

- `DocumentationMethodology_Index_v6.md`
- `DocumentationMethodology_Design_v18.md`
- `DocumentationMethodology_Decisions_v19.md`
- `AIDE_DocumentationMethodology_Standard_v21.md`
- `DocumentationMethodology_Guide_v21.md`
- `DocumentationMethodology_Binder_v2.md`

Do not mass-rename or rewrite historical/superseded WIP files. New/current WIP checkpoints use the
single `{TopLevelTopic}_WIP_vN.md` series.

## No change

- Do **not** update `AIDE_Bundle_StandardsTools_v5.md` in this package. The common temporary Bundle
  remains a separate regeneration job.
- Do not change Working, OpenItems or WorkRegister delegation semantics beyond what the included
  v22 masters state.
- Do not apply unrelated Review B findings.

## Review continuation

Return `DocumentationMethodology_Binder_v3.md` to Review A together with the revised Core Binder
from the coordinated Core pass. Review A remains High / Continuing until the seam is re-reviewed.

## Migration

`AIDE_DocumentationMethodology@v22` transition posture: `None`. No corpus-wide transformation or
historical WIP rename is required solely for this release.
