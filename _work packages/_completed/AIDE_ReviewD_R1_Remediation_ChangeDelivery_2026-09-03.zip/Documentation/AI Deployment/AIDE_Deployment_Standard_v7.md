# AIDE AI Deployment — Standard

> **Identity:** `AIDE_Deployment@v7`
> **Common name:** AI Deployment
> **Version 7** (2026-09-03). Makes Set membership authority, Target-relative required presence and frozen-Tag consumption explicit.
>
> **Default weight:** Requirement

## Purpose

Make validated built deployable material available for intended AI runtime surfaces, reconcile desired composition and applicable required presence with observed target state, and verify actual usable deployment.

## Core contract

Deployment consumes validated **Deployable Packages** from the configured **Deployment Registry**.

A Deployable Package supplies, directly or through its PackageKind contract:

- Logical Package Identity, unique concrete PackageId and integrity evidence;
- authoritative/canonical source and Build provenance sufficient to identify the produced result;
- deployment-facing built outputs/members and Build-owned `CompositionPosture: MemberContribution | AssembledConsumptionArtefact` where applicable;
- applicable producer-owned dependency/Migration and other required downstream metadata; and
- package-kind-specific validation evidence and extensions needed for correct Deployment.

`Capability Package` is the first specialised Deployable Package kind. Deployment does not reopen producer Design, reconstruct canonical semantics, or treat Registry/deployed state as semantic production authority.

## Deployment Registry

The Deployment Registry is the authoritative source of validated built supply available to Deployment. Its physical implementation may be a folder, Git repository, package store, service or another configured mechanism that preserves the required contract.

Registry package instances are immutable under `PackageId`. A stable Logical Package Identity may have successive PackageIds; Registry-owned `Current Package` state identifies the instance normally selected by current/floating resolution.

Registry-owned lifecycle state is separate from immutable package content:

```text
Available   — normal resolution eligibility
Deprecated  — remains available but discouraged; warn/prefer suitable replacement
Withdrawn   — retained historically but excluded from ordinary new/current resolution
```

Physical purge is retention maintenance and is not an automatic v6 Deployment lifecycle action.

Use `AIDE_DeploymentRegistryTool` for Register, Release Batch and Registry lifecycle actions. Generic ordinary Build publication does not establish Registry state.

## Tags

Deployable Packages and individual built target/member outputs may carry `AIDE_Tags` values.

For Deployment selection, the effective Tags for a built target/member are the union of Package
Tags and that target/member's Tags. Use `AIDE_Tags` Boolean query semantics. For immutable Registry
supply, consume the snapshot-relative Tags and producer Build evidence frozen before Package
validation; Deployment does not regenerate producer-owned Tags from newer source state.

Tags are classification/selection only. They do not replace semantic Dependencies, Scope, Build-target compatibility, Migration posture or Deployment Policy.

## Release Batch and triggers

A Release Batch may stage several package registrations/lifecycle changes until an explicit Release operation validates and exposes them together.

Batch Release is an atomic **Registry visibility** boundary only; it does not claim an all-or-nothing transaction across heterogeneous runtime Targets.

Registry events may cause configured Deployment Triggers to re-evaluate affected Deployment Set
Definitions. For an automatic Registry trigger, unchanged exact resolution means no new release and
no delivery retry. Explicit/manual Reconcile may retry or re-verify incomplete Targets of the
existing Desired Release.

Detailed Set selectors/output definitions/Delivery Actions remain governed by the current Deployment Set configuration and may be refined independently of this Registry contract.

## Deployment Set and Target

A **Deployment Set** is named logical desired composition. For a fixed-composition Set, the
Definition owns an explicit required/desired member list and a separate supply selector resolves
eligible Registry instances for those members. Missing eligible supply blocks the candidate rather
than silently shrinking it. A deliberately dynamic Set may declare selector-defined variable
membership explicitly. Omission from any Set does not cancel semantic dependency/required-presence
requirements.

A **Deployment Target** is one concrete realisation of a Set and resolves:

- platform/family and runtime/surface;
- representation;
- distribution channel;
- destination/account/workspace reference where applicable;
- effective target-change policy/authority;
- refresh/session-pickup behaviour where relevant; and
- verification requirements.

Surface, representation, channel and target-change policy are independent facts.

## Deployment Set Release and Outputs

Resolve a candidate from exact eligible PackageIds/build outputs while preserving all applicable
required-presence facts. Mechanically assemble and validate every required Deployment Output before issuing
the next immutable `<Set>@vN`. A failed candidate consumes no version and leaves the last
`DesiredRelease` in place.

The immutable release records its Set/Output Definition revisions, exact resolved members, Output
identities/integrity and resolution digest. A new exact PackageId/output or changed final Output
content may create a new Set release even when upstream semantic releases are unchanged. Target
destination, credentials, adapter/policy and verification-state changes do not alone change Set
content.

There is no generic downstream Deployment Package. Registry inputs are Deployable Packages; final
set-level consumables are Deployment Outputs.

Every final Output includes a runtime-visible Set release marker, Output identity/type and resolved-
set digest. Plugin assembly may add a generated provenance-only status member without creating a
Capability or semantic release.

The immutable Set release carries applicable required-presence facts but does not claim they are
satisfied independently of a Target. Target reconciliation evaluates satisfaction against that
Target's observed state, including valid material already present outside Set membership.

## Delivery Actions and Target Adapters

A Delivery Action is an idempotent configured operation that moves one or more Outputs toward one
or more Targets. A Target Adapter owns platform/channel-specific publish, install/update, remove,
pickup and verification mechanics behind a Target. One Output may feed several independently
reconciled Targets. Actions/adapters do not own semantic content and are not part of the Set release.

## Deployment Policy

Before mutating a Target, resolve the effective environment/target policy that determines whether and under what conditions the change may be applied.

Policy may permit automatic action, require confirmation/external execution, or otherwise constrain install/update/remove/acquisition behaviour. The exact policy values are environment configuration; this Standard owns only the rule that Deployment must honour them.

Technical access, credentials, Registry availability or a reachable destination do not by themselves establish permission to modify the Target.

## Reconciliation

For each requested Set/Target:

1. resolve the applicable Deployment Set Definition, its fixed or explicitly dynamic membership
   mode, selected Registry supply and configured Targets/Policies;
2. resolve exact PackageId/member/build-output identity and verify package/member integrity/provenance;
3. reject ordinary selection of Withdrawn packages and surface Deprecated selection where no suitable non-deprecated result replaces it;
4. preserve applicable semantic required-presence facts for later per-Target evaluation;
5. validate Build-declared composition posture and required package-kind extensions/handlers;
6. resolve all required Output Definitions and mechanically assemble eligible `MemberContribution` outputs deterministically without semantically re-rendering them;
7. treat each `AssembledConsumptionArtefact` as atomic at its internal semantic/member-composition boundary; if that composition must change, require the corresponding replacement Build output;
8. fail visibly on missing posture-compatible Build output, unresolved mandatory extension, or incompatible ownership/path/identity/namespace/posture claims;
9. assemble/validate all required candidate Outputs and compare exact resolution with DesiredRelease;
10. if changed and valid, freeze the next Set release; if invalid, retain the last Desired Release;
11. read/resolve observed target state where possible;
12. compare desired composition and applicable required presence with observed deployed state for
    each Target, allowing a requirement to be satisfied by valid material already present outside
    Set membership;
13. surface missing required material as a mismatch/blocker rather than making Set omission redefine the requirement;
14. determine and execute only the minimum policy-permitted Delivery Actions;
15. run layered Output/publication/platform/runtime verification; and
16. persist per-Target State and return one invocation Result.

A required dependency may already be satisfied by material present outside the Set. Deployment does not silently expand Set membership merely to hide a missing requirement.

Mechanical assembly preserves member-level dependency/Migration/Scope/Tags and other required
downstream facts, directly or through deterministic provenance references. It does not flatten away
facts needed by target reconciliation or runtime use.

## Production and provenance boundary

Build/specialised producer Build is upstream of Deployment. It renders/transforms current authoritative semantics into concrete deployable outputs/packages and owns their source/build provenance, identity/integrity and composition posture.

Deployment Registry registration validates/preserves that output as supply; it does not make the Registry a semantic producer.

Deployment owns desired Set selection and target-state reconciliation. Any Deployment-time composition is mechanical assembly of eligible `MemberContribution` outputs required by the Target representation. An `AssembledConsumptionArtefact` remains atomic at its internal semantic/member-composition boundary.

Observed target content, an older package, a Registry lifecycle state or successful deployment status may be evidence for reconciliation but do not substitute for canonical/Build provenance.

## Package lifecycle versus runtime removal

Registry lifecycle and runtime lifecycle are separate.

- `Deprecated` does not itself remove deployed material.
- `Withdrawn` removes the package from ordinary new/current Registry resolution; any resulting change to desired Set composition is handled by normal Deployment reconciliation.
- runtime removal remains subject to Dependencies, composition posture, Target mechanics and Deployment Policy.

A Deployment-owned assembly of `MemberContribution` outputs may be reassembled without a no-longer-desired member. If removal changes the internal semantic/member composition of an `AssembledConsumptionArtefact`, Deployment requires the corresponding replacement Build output.

## Source and acquisition boundary

A Registry/source locator, trust in that source, package lifecycle, permission to acquire/change a Target and the deployment action itself are separate facts.

Generic acquisition of packages not already available through established Registry/environment mechanics remains outside this release. Missing required deployable supply is reported/blocked rather than silently fetched from an arbitrary location.

## Failure, resumption and atomicity

There is no generic all-or-nothing transaction across heterogeneous Deployment Targets.

- preserve previously verified target state when failure occurs before mutation where possible;
- record each Target independently;
- a multi-target deployment with mixed success is `Partial`;
- a policy-denied/manual action may return `Blocked` with the next action rather than mutating;
- re-running reconciles from observed state and avoids unnecessary redeployment; and
- platform rollback is used only where actually supported.

Release Batch atomicity applies only to visibility of coordinated Registry changes, not to later target mutations.

## Verification

UI presence, an enabled flag, Registry registration, repository publication or filesystem existence alone does not prove runtime availability.

Record desired release, publication release, installed/attached platform release and runtime-observed
release separately where exposed. Verification status is `Verified | Mismatch | Unverified`.
Assurance is `Enforced` when evidence is independent of model choice/compliance and `Advisory` when
the model materially selects, executes or reports the check.

Target-specific verification may include package/member integrity, publication/install acknowledgement, discovery, identity/version visibility, applicable required-presence checks, Migration/cheap metadata visibility, content probes, trigger behaviour and fresh-session pickup where relevant.

Producer-declared surface variation/degradation information informs what behaviour is expected on each surface; verification must not fail a surface merely for functionality explicitly declared irrelevant/unsupported there, but must fail when a required/full-conformance condition is not met.

## Artefact neutrality and manual channels

Bootstrap Profiles, Bootstrap Contributions, Standards, Tools and other built deployable artefacts use the same Registry/Deployment model when their producer supplies a conforming Deployable Package/output. Their semantic owner does not become the deployment owner.

A manually replaced project Bundle is a valid representation/channel implementation where the platform lacks automation. Later automated sync/install can replace that channel without changing the Registry or desired-composition semantics.

## Boundaries

- Producer/domain owns logical artefact semantics and PackageKind-specific Build/package content.
- `AIDE_Dependencies` owns dependency/required-presence semantics.
- `AIDE_Migration` owns consumer transition semantics.
- `AIDE_Tags` owns tag content/build/query semantics; Deployment consumes Tags for selection where configured.
- Build owns semantic rendering/transformation, source/build provenance, output/package identity/integrity and composition posture.
- AI Deployment owns the Deployment Registry contract/lifecycle, desired Set selection, posture-respecting mechanical assembly, policy-aware target reconciliation/delivery, mismatch reporting and verification.
- Environment/platform configuration owns physical Registry/Target facts, access references and actual policy/authority values.
- Bootstrap owns startup discovery/surfacing, not Registry registration, deployment action or verification.

```yaml
MigrationSummary:
  CurrentVersion: v7
  LatestRequiredVersion: none
  LatestOnUpdateVersion: none

Transition:
  Version: v1
  Posture: None

Transition:
  Version: v2
  Posture: None

Transition:
  Version: v3
  Posture: None

Transition:
  Version: v4
  Posture: None

Transition:
  Version: v5
  Posture: None

Transition:
  Version: v6
  Posture: None

Transition:
  Version: v7
  Posture: None
```

No persisted consumer-state transformation is required to adopt v7. Existing fixed-composition Set
Definitions must declare their required members before relying on v7 fixed-membership resolution.

---
Dependencies: !AIDE_DocumentationMethodology@v28, AIDeployment_Design_v7, AIDE_Build@v8, AIDE_Dependencies@v3, AIDE_Tags@v3
References: AIDeployment_Registry_Design_v2, AIDeployment_SetRelease_Design_v2, AIDeployment_TargetAdapter_Design_v1, AIDeployment_AIDECore_Reference_v2, AIDE_DeploymentRegistryTool@v2, AIDE_CapabilityBuild@v4
