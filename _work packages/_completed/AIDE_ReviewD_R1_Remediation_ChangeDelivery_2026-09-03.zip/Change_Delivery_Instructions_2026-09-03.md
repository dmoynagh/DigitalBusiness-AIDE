# AIDE Review D R1 Remediation — Change Delivery Instructions

> Transfer/application document. Not an authoritative corpus master.

## Target

- **Repository:** `dmoynagh/DigitalBusiness-AIDE`
- **Repository URL:** `https://github.com/dmoynagh/DigitalBusiness-AIDE`
- **Application root:** repository root
- **Authoritative repository-relative content root:** `Documentation/`
- **Current local checkout supplied by the work owner:** `C:\Users\david\dev\repos\DigitalBusiness-AIDE`

The local absolute path is convenience context only. Apply by repository-relative path. Do not rely
on a stale absolute path or an unspecified current working directory.

The ZIP preserves the target tree under `Documentation/`. Extract/copy from the repository root so
that each packaged `Documentation/...` file lands at the same repository-relative destination.

## Baseline guard

This delivery was reconciled against the current Binder state available for the pass, including the
newer `ProjectDesign_Binder_v5` / `AIDE_ProjectDesign@v6` orientation baseline discovered during
completion. GitHub `main` was known to lag the working corpus and is not the semantic baseline for
blind overwrite.

Before applying, if any destination has advanced beyond the **replace/supersede from** version below,
do not overwrite it mechanically; reconcile that newer local master first.

## Capabilities — `Documentation/Capabilities/`

Replace/supersede these current masters:

| New current | Replace/supersede from |
|---|---|
| `Capabilities_Index_v24.md` | `Capabilities_Index_v23.md` |
| `Capabilities_Brief_v14.md` | `Capabilities_Brief_v13.md` |
| `Capabilities_Overview_v20.md` | `Capabilities_Overview_v19.md` |
| `Capabilities_Design_v15.md` | `Capabilities_Design_v14.md` |
| `Capabilities_Decisions_v21.md` | `Capabilities_Decisions_v20.md` |
| `Capabilities_Capability_Design_v3.md` | `Capabilities_Capability_Design_v2.md` |
| `Capabilities_Capability_Decisions_v2.md` | `Capabilities_Capability_Decisions_v1.md` |
| `AIDE_Capability_Standard_v3.md` | `AIDE_Capability_Standard_v2.md` |
| `Capabilities_BuildTargetProfile_Design_v2.md` | `Capabilities_BuildTargetProfile_Design_v1.md` |
| `Capabilities_AIDECore_BuildTargetProfile_v2.md` | `Capabilities_AIDECore_BuildTargetProfile_v1.md` |
| `Capabilities_CapabilityBuild_Design_v4.md` | `Capabilities_CapabilityBuild_Design_v3.md` |
| `Capabilities_CapabilityBuild_Decisions_v4.md` | `Capabilities_CapabilityBuild_Decisions_v3.md` |
| `AIDE_CapabilityBuild_Standard_v4.md` | `AIDE_CapabilityBuild_Standard_v3.md` |
| `Capabilities_BuildCapability_Tool_Design_v6.md` | `Capabilities_BuildCapability_Tool_Design_v5.md` |
| `AIDE_BuildCapability_Tool_v6.md` | `AIDE_BuildCapability_Tool_v5.md` |
| `Capabilities_CapabilityBuilder_Tool_Design_v4.md` | `Capabilities_CapabilityBuilder_Tool_Design_v3.md` |
| `AIDE_CapabilityBuilder_Tool_v4.md` | `AIDE_CapabilityBuilder_Tool_v3.md` |
| `Capabilities_Tags_Definition_v3.md` | `Capabilities_Tags_Definition_v2.md` |
| `Capabilities_Tags_Design_v3.md` | `Capabilities_Tags_Design_v2.md` |
| `AIDE_Tags_Standard_v3.md` | `AIDE_Tags_Standard_v2.md` |
| `Capabilities_Scope_Definition_v3.md` | `Capabilities_Scope_Definition_v2.md` |
| `Capabilities_Scope_Design_v3.md` | `Capabilities_Scope_Design_v2.md` |
| `AIDE_Scope_Standard_v3.md` | `AIDE_Scope_Standard_v2.md` |
| `Capabilities_Dependencies_Definition_v3.md` | `Capabilities_Dependencies_Definition_v2.md` |
| `Capabilities_Migration_Definition_v4.md` | `Capabilities_Migration_Definition_v3.md` |
| `Capabilities_Review_Definition_v4.md` | `Capabilities_Review_Definition_v3.md` |
| `Capabilities_Messaging_Definition_v3.md` | `Capabilities_Messaging_Definition_v2.md` |
| `Capabilities_Standards_Definition_v4.md` | `Capabilities_Standards_Definition_v3.md` |
| `Capabilities_Tools_Definition_v5.md` | `Capabilities_Tools_Definition_v4.md` |
| `Capabilities_WIP_v20.md` | `Capabilities_WIP_v19.md` |
| `Capabilities_WorkRegister_v20.md` | `Capabilities_WorkRegister_v19.md` |

Replace generated consumption artefacts:

| New generated artefact | Supersede |
|---|---|
| `Capabilities_Binder_Core_v10.md` | `Capabilities_Binder_Core_v9.md` |
| `Capabilities_Binder_StandardsTools_v7.md` | `Capabilities_Binder_StandardsTools_v6.md` |
| `Capabilities_Binder_Runtime_v5.md` | `Capabilities_Binder_Runtime_v4.md` |
| `Capabilities_Binder_Review_v7.md` | `Capabilities_Binder_Review_v6.md` |
| `Capabilities_Binder_Messaging_v6.md` | `Capabilities_Binder_Messaging_v5.md` |
| `Capabilities_Binder_Set_Index_v5.md` | `Capabilities_Binder_Set_Index_v4.md` |
| `AIDE_Bundle_StandardsTools_v10.md` | `AIDE_Bundle_StandardsTools_v9.md` |

`Capabilities_OpenItems_v16.md` is unchanged/current and is not in this delivery.

## AI Deployment — `Documentation/AI Deployment/`

| New current | Replace/supersede from |
|---|---|
| `AIDeployment_Index_v7.md` | `AIDeployment_Index_v6.md` |
| `AIDeployment_Design_v7.md` | `AIDeployment_Design_v6.md` |
| `AIDeployment_Decisions_v7.md` | `AIDeployment_Decisions_v6.md` |
| `AIDeployment_SetRelease_Design_v2.md` | `AIDeployment_SetRelease_Design_v1.md` |
| `AIDeployment_AIDECore_Reference_v2.md` | `AIDeployment_AIDECore_Reference_v1.md` |
| `AIDE_Deployment_Standard_v7.md` | `AIDE_Deployment_Standard_v6.md` |
| `AIDE_Deployment_Tool_v7.md` | `AIDE_Deployment_Tool_v6.md` |
| `AIDE_DeploymentRegistry_Tool_v2.md` | `AIDE_DeploymentRegistry_Tool_v1.md` |
| `AIDeployment_Binder_v7.md` | `AIDeployment_Binder_v6.md` |

Leave `AIDeployment_Registry_Design_v2.md`, `AIDeployment_TargetAdapter_Design_v1.md`, and
`AIDeployment_OpenAI_Reference_v3.md` unchanged/current. The Review D findings are closed by the
newer owner documents without requiring replacement releases for those documents.

The AIDE Core deployment publication path remains the confirmed current location:
`C:\Users\david\dev\repos\DigitalBusiness-AIDE\Documentation\_deploymentPackages`, with old
outputs under `_deploymentPackages\_superseded`. This path is deployment configuration context,
not the placement rule for this Change Delivery package.

## Build — `Documentation/Build/`

| New current | Replace/supersede from |
|---|---|
| `Build_Index_v9.md` | `Build_Index_v8.md` |
| `Build_Design_v9.md` | `Build_Design_v8.md` |
| `Build_Decisions_v9.md` | `Build_Decisions_v8.md` |
| `Build_PostBuild_Design_v3.md` | `Build_PostBuild_Design_v2.md` |
| `AIDE_Build_Standard_v9.md` | `AIDE_Build_Standard_v8.md` |
| `Build_Binder_v9.md` | `Build_Binder_v8.md` |

`AIDE_WorkPackage_Standard_v3.md`, `Build_WorkPackage_Design_v3.md`, and
`AIDE_PublishBuildOutput_Tool_v1.md` remain unchanged/current. **Do not create WorkPackage v4.**
Build v9 is required because Build v8 contained a current executable Registry Tool v1 reference;
Registry registration is now aligned to `AIDE_DeploymentRegistryTool@v2` while the generic
WorkPackage and ordinary publication Tool remain unchanged.

## Project Design — `Documentation/Project Design/`

The authoritative baseline advanced after the original handoff was prepared. Apply this correction
on top of current `ProjectDesign_Binder_v5` / `AIDE_ProjectDesign@v6`, not the older Binder v4.

| New current | Replace/supersede from |
|---|---|
| `ProjectDesign_Index_v7.md` | `ProjectDesign_Index_v6.md` |
| `ProjectDesign_Design_v7.md` | `ProjectDesign_Design_v6.md` |
| `ProjectDesign_Binder_v6.md` | `ProjectDesign_Binder_v5.md` |

Leave `ProjectDesign_Decisions_v5.md` and `AIDE_ProjectDesign_Standard_v6.md` unchanged/current.
The Design v7 correction records the correct lineage: v4 was the WorkPackage preflight correction,
v5 added flexible Design contribution/hosting, and v6 added the Contents/Summary/Overview model.
No `AIDE_ProjectDesign@v7` is created.

## Working Practices — `Documentation/Working Practices/`

| New current | Replace/supersede from |
|---|---|
| `WorkingPractices_Index_v9.md` | `WorkingPractices_Index_v8.md` |
| `WorkingPractices_Design_v9.md` | `WorkingPractices_Design_v8.md` |
| `WorkingPractices_Decisions_v8.md` | `WorkingPractices_Decisions_v7.md` |
| `AIDE_WorkingPractices_Standard_v8.md` | `AIDE_WorkingPractices_Standard_v7.md` |
| `WorkingPractices_Binder_v6.md` | `WorkingPractices_Binder_v5.md` |

`WorkingPractices_Brief_v6.md` remains unchanged/current. The formal Standard identity remains
`AIDE_WorkingPractices@v2`; document version 8 strengthens WP1 application instructions without a
new semantic capability release.

## Physical lifecycle handling

For each replaced current file, keep the packaged new version in the active topic folder and move
the prior current version to that topic's `_superseded/` location under the repository's current
handling convention. Do not edit generated Binders directly.

For the generated Standards/Tools Bundle, make v10 current in `Documentation/Capabilities/` and move
v9 to `Documentation/Capabilities/_superseded/` if that is where the local current Bundle is held.

## Project/context refresh after application

1. Replace the loaded Capabilities Binder partitions with Core v10, StandardsTools v7, Runtime v5,
   Review v7, Messaging v6 and Binder Set Index v5.
2. Replace loaded AI Deployment with Binder v7.
3. Replace loaded Build with Binder v9.
4. Replace loaded Project Design with Binder v6.
5. Replace loaded Working Practices with Binder v6.
6. Replace the temporary Standards/Tools Bundle with v10 where that Bundle is used.
7. Keep `Capabilities_WIP_v20`, `Capabilities_WorkRegister_v20` and `Capabilities_OpenItems_v16`
   as the live Review D state set.

## Review continuation

After the package is applied and the current context is refreshed, use
`ReviewD_R2_Inspect_High_Full_Request_2026-09-03.md` from the root of this delivery as the next
Review request. It is transfer-only and should not be copied into the authoritative documentation
corpus unless deliberately adopted.
