# Documentation Methodology — Review B R1 Change Delivery Instructions — 2026-09-01

> Transfer/application artefact. Not an authoritative corpus master.

## Purpose

Apply the accepted Review B Round 1 Documentation Methodology remediation against the current
Review A R2 baseline (`DocumentationMethodology_Binder_v4` / v23 masters).

This package is deliberately limited to Documentation Methodology. It does **not** implement Review C
/ Dependencies policy and does not rebuild the common AIDE Standards & Tools Bundle.

## What you need to do

1. In `AIDE/Document Methodology/`, replace the six current files listed under **Replace Current**
   with the packaged replacements.
2. Move the six replaced current files listed under **Move to `_superseded/`** to that project's
   `_superseded/` folder under the normal Working Practices convention.
3. Replace the Documentation Methodology Binder loaded in ChatGPT/Claude project context with
   `DocumentationMethodology_Binder_v5.md`.
4. Do **not** edit the Binder directly and do **not** update `AIDE_Bundle_StandardsTools_v5.md` from
   this package. Rebuild the Bundle separately when the common bundle is next updated.

## Replace Current

Destination: `AIDE/Document Methodology/`

| Packaged file | Replaces current |
|---|---|
| `DocumentationMethodology_Index_v9.md` | `DocumentationMethodology_Index_v8.md` |
| `DocumentationMethodology_Design_v21.md` | `DocumentationMethodology_Design_v20.md` |
| `DocumentationMethodology_Decisions_v22.md` | `DocumentationMethodology_Decisions_v21.md` |
| `AIDE_DocumentationMethodology_Standard_v24.md` | `AIDE_DocumentationMethodology_Standard_v23.md` |
| `DocumentationMethodology_Guide_v24.md` | `DocumentationMethodology_Guide_v23.md` |
| `DocumentationMethodology_Binder_v5.md` | `DocumentationMethodology_Binder_v4.md` |

## Move to `_superseded/`

After the replacements are applied, move these replaced issues to
`AIDE/Document Methodology/_superseded/`:

- `DocumentationMethodology_Index_v8.md`
- `DocumentationMethodology_Design_v20.md`
- `DocumentationMethodology_Decisions_v21.md`
- `AIDE_DocumentationMethodology_Standard_v23.md`
- `DocumentationMethodology_Guide_v23.md`
- `DocumentationMethodology_Binder_v4.md`

## Findings implemented

- **RB-R1-F1 — WorkRegister admission semantics** — general rule is now confirmed work owed by the
  owning top-level topic and not yet fully delivered; Design consequences remain a mandatory
  producer subset.
- **RB-R1-F2 — WIP per-thread exit** — safely routed active threads leave the next WIP checkpoint;
  whole WIP withdrawal follows the last active continuation thread.
- **RB-R1-F3 — Working discoverability** — each newly issued Working series requires a
  version-agnostic locator in the topic Index `Live state`; later versions do not churn the Index.
- **RB-R1-F4 — DocMeth / Working Practices owner seam** — DocMeth owns work-state semantics,
  routing/authority/Binder treatment; Working Practices owns checkpoint timing, transfer/sync and
  physical repository/file handling.
- **RB-R1-F5 — returned but unreconciled WorkPackage state** — compact
  `Returned — reconciliation pending` marker required when reconciliation is not immediate.
- **RB-R1-F7 — returned result means compact reconciliation state** — WorkRegister references Outcome
  evidence rather than copying it.
- **RB-R1-F8 — split obligation entry depth** — required changes are independently identifiable and
  existing WorkPackage `Covers` mappings identify exact portions; no sub-obligation ID system.
- **RB-R1-F9 — OpenItem negative conclusion** — no tombstone; preserve a material reusable negative
  conclusion in Decisions/another proper durable owner only when justified.
- **RB-R1-F10 — concrete stale in-body references only** — current DocMeth masters were checked; no
  additional stale current-executable capability-version reference required correction. Historical
  version references in Decisions were preserved. No Review C policy was introduced.

## Cross-owner / Round 2 note

No blocking Documentation Methodology architecture issue remains from these accepted findings.
`AIDE_WorkPackage@v2` already requires each mapped WorkRegister item and the portion covered, so the
existing Build/WorkPackage seam is sufficient for F8 once the source WorkRegister obligation is made
independently identifiable.

Two **non-blocking cross-owner maintenance items** remain outside this package:

- the current Working Practices Standard still contains a concrete explanatory reference to
  `AIDE_DocumentationMethodology@v21`; its operating ownership model is already compatible with v24,
  but that stale version-pinned wording should be corrected in the next Working Practices pass; and
- `AIDE_Bundle_StandardsTools_v5.md` still packages an older Documentation Methodology Standard and
  must be rebuilt separately through the normal bundle/build route to consume v24.

These are distribution/current-reference follow-ups, not reasons to reopen the Review B R1 DocMeth
semantic decisions.

## Resulting current Binder

`DocumentationMethodology_Binder_v5.md`

Generated from exactly:

- `DocumentationMethodology_Index_v9.md` — sha256 `4ce7ab063603`
- `DocumentationMethodology_Design_v21.md` — sha256 `842392a30ccf`
- `DocumentationMethodology_Decisions_v22.md` — sha256 `91a27e8a9992`
- `AIDE_DocumentationMethodology_Standard_v24.md` — sha256 `129c0cd2b877`
- `DocumentationMethodology_Guide_v24.md` — sha256 `943a4193e980`

## Package contents

This ZIP contains only the six replacement deliverables above plus this instructions file. No
Review/Handoff source file is promoted into the authoritative corpus.
