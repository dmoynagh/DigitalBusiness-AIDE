# Project Design — Review B R1 Pre-Round-2 Preflight — Change Delivery Instructions

## Purpose

Apply the smallest Project Design correction required after coordinated Review B R1 issued `AIDE_WorkPackage@v3`.

The only substantive correction in the stable corpus is that current Project Design Build-handoff guidance now targets `AIDE_WorkPackage@v3`. All Review B R1 Project Design semantics remain unchanged.

## Apply to `AIDE/Project Design/`

### Replace current masters

- `ProjectDesign_Index_v4.md` replaces `ProjectDesign_Index_v3.md`.
- `ProjectDesign_Design_v4.md` replaces `ProjectDesign_Design_v3.md`.
- `AIDE_ProjectDesign_Standard_v4.md` replaces `AIDE_ProjectDesign_Standard_v3.md`.

Move the replaced v3 master files to `_superseded/` under the current repository convention.

### Keep unchanged

- `ProjectDesign_Decisions_v3.md` remains Current. Do **not** rewrite historical decision events that correctly record earlier v2 state.
- Footer `Dependencies:` / `References:` version tokens were deliberately not swept merely for currency. The general version-reference/conformance question remains reserved for Review C / Dependencies.

### Live state

- `ProjectDesign_WorkRegister_v2.md` replaces `ProjectDesign_WorkRegister_v1.md` as the separately loaded live WorkRegister checkpoint.
- The existing `PD-WR1` obligation is not new; its bundle-rebuild target is updated from `AIDE_ProjectDesign@v3` to the newly issued `AIDE_ProjectDesign@v4`.
- Keep WorkRegister outside the stable Binder.

### Binder

- `ProjectDesign_Binder_v3.md` replaces `ProjectDesign_Binder_v2.md`.
- Move Binder v2 to `_superseded/`.
- Replace the Project Design project-context Binder with Binder v3.

## Exact correction

The active handoff instruction in both Design and canonical Standard now uses:

```text
AIDE_WorkPackage@v3
```

This consumes the current v3 `Covers` clarification for deliberately split WorkRegister obligations without introducing a new Project Design mapping mechanism.

## Preserved semantics

- Project Design owns the mandatory Design→WorkRegister producer rule.
- Documentation Methodology owns general WorkRegister admission semantics.
- `Returned — reconciliation pending` remains the compact returned-but-unreconciled state.
- Build reports evidence but does not close WorkRegister.
- WorkRegister→WorkPackage mapping remains many-to-many.
- Deliberately split obligations use the current `AIDE_WorkPackage@v3` `Covers` rule.

## Not included

- No historical Decisions rewrite.
- No general footer dependency/reference version sweep.
- No general version-reference/conformance rule.
- No Bundle rebuild in this package; `PD-WR1` remains open for that existing downstream propagation.
