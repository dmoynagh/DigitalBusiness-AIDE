# Core Bootstrap — Decisions

> **Version 1** (2026-08-31). Records the confirmed Bootstrap/Profile architecture.
>
> Created: 2026-08-31 | Last modified: 2026-08-31

## D1 — Bootstrap remains a Core system primitive

**Decision.** Bootstrap belongs to Core.

**Reason.** It must operate before individual AIDE components can assume their detailed operating material is in context and is consumed across all participating environments.

## D2 — Persistent platform bootstrap is tiny and stable

**Decision.** The machine/platform-level bootstrap instruction contains only stable discovery and activation behaviour and changes rarely.

**Reason.** Hard-coding current AIDE components/releases into Custom Instructions, Claude instructions or global machine files would turn every AIDE change into platform configuration maintenance.

## D3 — Environment-specific startup posture is a Bootstrap Profile

**Decision.** A Bootstrap Profile defines the startup posture for one environment/context and identifies only `what`, `why`, and `where`.

**Consequence.** Detailed capability behaviour remains in its owning guidance/Standard/Tool.

## D4 — Bootstrap Contributions are thin and separate

**Decision.** Component startup contributions are separately deployable from the full Standard or other detailed operating material.

**Reason.** Early-session discovery should not require eager loading of large Standards.

## D5 — Lazy context is a first-class goal

**Decision.** Bootstrap establishes awareness, locators and genuinely early checks; full operating material is loaded only when relevant.

## D6 — One effective Profile by default

**Decision.** At most one effective Bootstrap Profile applies by default.

**Reason.** No demonstrated need currently justifies profile merge/precedence machinery.

**Consequence.** Competing profiles fail visibly until an explicit future composition model is designed.

## D7 — Startup-required presence uses Dependencies

**Decision.** Bootstrap does not introduce its own dependency grammar. Startup-required relationships use `AIDE_Dependencies`, including `!!identity`.

**Reason.** Dependencies already owns requirement identity and presence/version facts.

**Consequence.** Bootstrap supplies the startup opportunity and surfaces unresolved checks; it does not redefine dependency semantics or run blanket startup migrations.

## D8 — Bootstrap does not deploy

**Decision.** Missing required material is surfaced at runtime, not silently installed by Bootstrap.

**Reason.** Requirement, authority, source and deployment action are separate concerns.

## D9 — Deployment Authority controls installation permission

**Decision.** The person/process authorised to control the host environment is the Deployment Authority.

**Consequence.** AI Deployment may reconcile a missing requirement only when authorised by that environment's deployment policy/authority.

## D10 — Deployment Set does not define semantic requirement

**Decision.** A capability/Profile may require an item even when the current Deployment Set omitted it.

**Reason.** Otherwise a misconfigured Deployment Set would erase the requirement runtime checking is intended to detect.

## D11 — Bootstrap may be deployed but does not govern Deployment

**Decision.** Bootstrap/Profile artefacts may be members of a Deployment Set, while AI Deployment retains deployment semantics.

## D12 — Future trusted acquisition remains architecturally possible

**Decision.** Do not block future trusted-source/catalog resolution and authorised automatic acquisition.

**Consequence.** Source resolution and acquisition are deferred, and naming a source never grants installation authority.

## D13 — Generic startup-task orchestration is deferred

**Decision.** Do not create a generic startup-task framework in v1.

**Reason.** The demonstrated needs are Profile activation, thin bootstrap contributions and startup-required dependency presence checking.

## D14 — No Profile is a valid state

**Decision.** The persistent bootstrap instruction may exist on a platform where no AIDE Bootstrap Profile is available; the session continues normally.

**Reason.** This allows one stable machine-level instruction to serve full-AIDE, partial-AIDE and non-AIDE contexts safely.

---
Dependencies: !AIDE_DocumentationMethodology@v18, AIDE_Dependencies@v2, Core_Bootstrap_Design_v1
References: Core_System_Decisions_v3
