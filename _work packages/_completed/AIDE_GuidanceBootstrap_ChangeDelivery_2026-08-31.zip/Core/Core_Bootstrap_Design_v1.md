# Core Bootstrap — Design

> **Version 1** (2026-08-31). First focused design of the Core bootstrap primitive, Bootstrap Profiles and Bootstrap Contributions.
>
> Created: 2026-08-31 | Last modified: 2026-08-31

## Purpose

Bootstrap is the stable AIDE activation seam between an AI platform's persistent machine-level instructions and the deployable guidance, Standards, Tools and other AIDE material available to a particular environment.

Its purpose is to let the machine-level instruction remain **very small and rarely changed** while the effective startup posture can evolve through separately deployed Bootstrap Profiles and thin component Bootstrap Contributions.

Bootstrap belongs to **Core** because it is a system-wide activation primitive used before any particular AIDE component can assume that its full operating material is already in context.

## Level 1 model

```text
Persistent platform bootstrap
        ↓
Bootstrap Profile
        ↓
thin Bootstrap Contributions
        ↓
full Standards / Tools / guidance loaded when needed
```

### Persistent platform bootstrap

A tiny, stable instruction deployed through the strongest persistent mechanism available on the platform, for example ChatGPT Custom Instructions, Claude global/project instructions, Codex/global machine instructions, or another platform-equivalent persistent instruction surface.

Its job is only to:

1. discover an applicable Bootstrap Profile where available;
2. process the Profile before substantive work where the platform permits;
3. process applicable available Bootstrap Contributions;
4. continue normally where no AIDE Bootstrap Profile is available; and
5. process newly discovered applicable bootstrap material later if the environment exposes it only after session start.

It must not contain a hard-coded list of current AIDE releases or reproduce operational Standards.

### Bootstrap Profile

A Bootstrap Profile is an environment-specific startup map. It says only:

```text
WHAT  — what operating material/capability should be brought into play;
WHY   — why it matters in this environment / when it becomes relevant;
WHERE — where/how the environment can resolve or obtain the authoritative deployed material.
```

A Profile does not reproduce the referenced Standard, Tool or guidance.

Examples may include `AIDE Development`, `General Working`, `Documentation`, or a build-oriented environment.

A general non-development Profile may activate only Principles and Working Practices. A full AIDE development Profile may establish awareness of Core, Domain, Project Design, Build, Documentation Methodology and relevant Capabilities without loading their full detailed Standards eagerly.

### Bootstrap Contribution

A Bootstrap Contribution is a **thin, separately deployable early-session contribution** owned by the component or behaviour that requires it.

It is separate from the full Standard/Tool so the environment does not have to load a large operational contract merely to obtain a few startup instructions.

A contribution contains only enough information to perform or request its early bootstrap concern and to locate/load its owner when detailed behaviour is needed.

The contribution owner retains its semantics. Bootstrap supplies discovery/ordering only.

## Startup context should stay small

Bootstrap is not a universal eager include. A Profile establishes the minimum useful startup posture: what must be recognised now, what must be checked now, what must merely be discoverable for later use, and where the authoritative detailed material can be resolved.

Full Standards, Tools, migration histories, guides and other large material remain lazy and are loaded when the current work requires them. Context economy is a first-class bootstrap requirement.

## One effective Profile by default

An environment/context has at most one effective Bootstrap Profile by default.

Profile composition/merging is not designed in v1. If multiple competing Profiles are discovered without an explicit future composition rule, fail visibly rather than inventing precedence.

No Profile is also a valid state.

## Dependencies and startup-required presence

Bootstrap does not create a separate dependency language.

Where a Bootstrap Profile or its governed representation declares required material, it uses the normal `AIDE_Dependencies` contract. In particular:

```text
!!identity
```

means best-effort startup presence checking plus required thereafter.

Bootstrap supplies the early-session opportunity. Dependencies owns requirement identity, presence/version facts and dependency semantics.

A startup presence check does **not** imply a general startup migration/current-version scan.

Where full dependency processing is unavailable at the earliest instant of a session, Bootstrap should establish enough awareness to invoke the deployed Dependencies bootstrap contribution when available and surface inability to validate startup requirements rather than silently assuming success.

## Bootstrap does not deploy

Bootstrap can reveal that required operating material is missing. It does not install, update, remove or reconcile deployed material.

Keep these responsibilities separate:

```text
Requirement       → declaring artefact + Dependencies
Presence facts    → Dependencies / Environment
Startup surfacing → Bootstrap
Authority         → Deployment Authority
Deployment action → AI Deployment
Target/source facts → Environment
```

**Deployment Authority** means the person or controlling process authorised to decide what may be installed or changed in the host environment.

A Deployment Set describes desired deployment state. It does not become the semantic source of truth for whether another artefact requires a dependency.

This separation makes a missing required item visible as a deployment/configuration defect rather than allowing an incomplete Deployment Set to redefine the requirement away.

## Relationship to AI Deployment

Bootstrap may itself be deployed as part of an AI Deployment target/set. Bootstrap does not govern AI Deployment.

AI Deployment remains responsible for target-aware publication/install/update/remove reconciliation and verification. Environment remains responsible for factual platform/target/source/access configuration.

## Future acquisition is allowed, not designed

The architecture must not prevent a future flow such as:

```text
required identity missing
        ↓
trusted source/catalog resolution
        ↓
Deployment Authority policy permits acquisition
        ↓
AI Deployment obtains / installs / verifies
```

Source discovery, trust policy, package acquisition and automatic remediation are not designed in v1 because current environments do not yet provide a sufficiently general source/package infrastructure.

A Profile must never gain installation authority merely by naming a source.

## Bootstrap Contributions are exceptional

A Standard or behaviour gets a Bootstrap Contribution only when a demonstrated early-session need exists.

Ordinary capability existence is not by itself a reason to add bootstrap material.

## Session processing

Best-effort behaviour:

1. discover applicable Profile within the platform's available persistent/deployed context;
2. establish the Profile's startup map;
3. process available applicable Bootstrap Contributions;
4. surface unresolved startup-required presence conditions;
5. begin substantive work;
6. load full governing material only when relevant;
7. avoid re-running completed bootstrap work repeatedly during the same unchanged session; and
8. re-evaluate only when materially new bootstrap/profile/environment information becomes available.

Platform implementations must not claim stronger startup enforcement than the platform provides.

## Relationship to Principles and Working Practices

Bootstrap is the activation mechanism; it does not own the guidance.

A general Profile can identify `AIDE_Principles` as base reasoning guidance and `AIDE_WorkingPractices` as base collaboration guidance, including why each matters and where its authoritative deployed material can be resolved.

The same stable persistent bootstrap instruction can therefore support full AIDE development environments, Principles + Working Practices only, another future AIDE subset, or no AIDE Profile at all.

## Intended output

This Design is intended to support a small canonical Core bootstrap contract, provisionally:

```text
AIDE_Bootstrap@v1
```

and a deployable Bootstrap Profile representation.

Exact platform rendering and profile file/schema shape are build/deployment details and should be kept minimal.

## Deliberately deferred

- profile merging/composition;
- generic startup task orchestration;
- automatic package/source acquisition;
- trusted package catalogs;
- generic installer behaviour;
- broad startup migration scans;
- platform-specific enforcement beyond demonstrated capability; and
- putting full Standards/Tools into bootstrap contributions.

---
Dependencies: !AIDE_DocumentationMethodology@v18, AIDE_Dependencies@v2
References: Core_System_Design_v4
