# Working Practices — Index

> **Version 1** (2026-08-31). Establishes Working Practices as a top-level cross-cutting AIDE topic.
>
> Created: 2026-08-31 | Last modified: 2026-08-31

## Topic identity

**Topic:** Working Practices  
**Conceptual position:** top-level AIDE topic; independently deployable  
**Owner:** Alpha Publishing Ltd

## Document register

| Document | Version | Type | Status |
|---|---:|---|---|
| `WorkingPractices_Index` | v1 | Index | Current |
| `WorkingPractices_Design` | v1 | Design | Current |
| `WorkingPractices_Decisions` | v1 | Decisions | Current |
| `WorkingPractices_Brief` | v1 | Brief | Current |

## Outcome

Produce a canonical independently deployable base-guidance Standard:

```text
AIDE_WorkingPractices@v1
```

## Initial demonstrated practices

- material multi-file output uses a Change Delivery Package;
- coded references are glossed on first use;
- externally held/current facts are checked rather than plausibly invented;
- material state-changing actions are not silently assumed complete;
- architecture-shaping choices are surfaced explicitly; and
- durable handoff/continuation information is produced when work moves between sessions/projects.

## Next actions

1. Produce `AIDE_WorkingPractices@v1`.
2. Reconcile Core's top-level reference view.
3. Add Working Practices to appropriate Bootstrap Profiles.
4. Deploy it as base guidance where desired.
5. Regenerate the Working Practices Binder after master adoption.

---
Dependencies: !AIDE_DocumentationMethodology@v18
References: WorkingPractices_Design_v1, Principles_Design_v2
