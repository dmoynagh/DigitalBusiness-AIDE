# Working Practices — Brief

> **Version 1** (2026-08-31). First issuance.
>
> Created: 2026-08-31 | Last modified: 2026-08-31

## Purpose

Working Practices defines **how an AI and user practically work together** across chat, document, code, Work, repository and other AI-assisted surfaces.

It covers cross-cutting conventions that are too operational to be Principles and too general to belong to one work domain or output methodology.

## Position

Working Practices is a top-level AIDE topic, independently deployable, complementary to Principles, portable across software and non-software work, and base guidance that may be refined by applicable Guidance Profiles.

## Example

For material multi-file output, deliver one Change Delivery Package containing the created/changed files plus concise instructions explaining what to add, replace, supersede/archive, move, regenerate, update in project context, or treat as transfer-only.

Documentation Methodology still owns what document lifecycle terms mean. Working Practices owns the AI behaviour of telling the user what to do.

## Outcome

```text
AIDE_WorkingPractices@v1
```

---
Dependencies: !AIDE_DocumentationMethodology@v18
References: WorkingPractices_Design_v1, Principles_Brief_v2
