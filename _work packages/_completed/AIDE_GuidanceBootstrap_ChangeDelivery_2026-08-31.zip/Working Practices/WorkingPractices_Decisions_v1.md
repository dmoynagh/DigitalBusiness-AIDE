# Working Practices — Decisions

> **Version 1** (2026-08-31). First issuance.
>
> Created: 2026-08-31 | Last modified: 2026-08-31

## D1 — Working Practices is a top-level AIDE topic

**Decision.** Working Practices is a sibling of Principles, Core, Project Design, Build, Capabilities and other principal AIDE concerns rather than a child of Principles or Documentation Methodology.

## D2 — Working Practices is independently deployable

**Decision.** `AIDE_WorkingPractices@v1` must be usable without full AIDE.

## D3 — Working Practices is base guidance

**Decision.** The canonical Standard provides portable defaults, not one user/team's fully customised final behaviour.

## D4 — Guidance Profiles provide deltas

**Decision.** Organisation/group/team/user Profiles may Add, Refine or explicitly Override Working Practices without copying/forking the base Standard.

## D5 — Specialised owners retain their semantics

**Decision.** Working Practices may require the AI to communicate or hand off specialised state, but does not redefine lifecycle, deployment, dependency, migration, Domain or other owned semantics.

## D6 — Multi-file handoff uses Change Delivery Package

**Decision.** Material multi-file/non-obvious output is delivered as one package containing the created/changed files plus application instructions.

**Reason.** The user should not have to reconstruct file placement, replacement, supersession, context, handoff or regeneration actions from conversational history.

## D7 — Package creation does not imply application

**Decision.** A Change Delivery Package is a transfer artefact; generation alone does not mean the contained changes were applied.

## D8 — Trivial one-file output does not require package ceremony

**Decision.** Apply the Change Delivery Package convention proportionately based on complexity and risk.

## D9 — Preserve operational seed behaviours from Principles v1

**Decision.** Coded-reference glossing, verification before assertion and no-silent-state-change behaviour are retained as Working Practices rather than lost during the Principles separation.

## D10 — Architecture decisions are surfaced selectively

**Decision.** Routine/reversible implementation choices are handled autonomously; genuinely architecture-shaping choices are surfaced with recommendation, rationale, alternative and consequence.

## D11 — Layered work is a Working Practice backed by Principles

**Decision.** Complex work begins with compact intent/model layers before detailed elaboration.

## D12 — Durable handoff is required when substantial work moves

**Decision.** Cross-project/session/environment handoffs preserve authoritative inputs, confirmed decisions, remaining work and integration instructions.

**Consequence.** Handoff summaries are normally transfer-only and should not become stale competing sources beside adopted masters.

---
Dependencies: !AIDE_DocumentationMethodology@v18, WorkingPractices_Design_v1
References: Principles_Decisions_v2
