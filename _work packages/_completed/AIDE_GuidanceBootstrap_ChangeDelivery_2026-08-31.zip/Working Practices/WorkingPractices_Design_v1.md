# Working Practices — Design

> **Version 1** (2026-08-31). Establishes cross-surface AI/user operating conventions and the first confirmed Change Delivery Package practice.
>
> Created: 2026-08-31 | Last modified: 2026-08-31

## Purpose

Working Practices defines the practical cross-cutting conventions used when an AI and user work together.

It answers:

> How should work be approached, communicated, completed and handed over in practice?

It applies across AI chat, document/design work, code/repository work, Work-style artifact environments, Build execution, research/administration, and non-development AI use where the practice remains relevant.

Working Practices is part of AIDE but can also be deployed independently.

## Boundary with Principles

```text
Principles
  → durable reasoning and judgement premises

Working Practices
  → concrete collaboration and operational conventions
```

A Working Practice may implement a Principle but should not duplicate its rationale unnecessarily.

## Boundary with other AIDE owners

Working Practices tells the AI **how to work with the user**. It does not take semantic ownership from specialised components.

Examples:

```text
Documentation Methodology
  defines what Current / Superseded / Archived mean.

Working Practices
  requires a delivery handoff to tell the user which files move where.

AI Deployment
  defines install/update/remove/reconciliation.

Working Practices
  requires deployment handoffs to distinguish generated intent from confirmed deployed state.
```

## Base guidance and Guidance Profiles

`AIDE_WorkingPractices@v1` is the portable base.

Optional organisation/group/team/user Guidance Profiles may provide deltas using the same conceptual contract as Principles:

```text
Add
Refine
Override
```

Profiles contain only differences from the base. A narrower applicable profile changes only the practices it explicitly addresses. Unmentioned base guidance remains effective. Equal-specificity conflict fails visibly unless explicit ordering exists.

Host/platform instruction priority remains outside AIDE.

The profile mechanism is intentionally kept small and is not promoted to a new generic AIDE component until more consumers demonstrate that need.

## Initial Working Practices

### WP1 — Material multi-file output uses a Change Delivery Package

When a session creates or materially changes multiple files, crosses project/master-folder boundaries, or otherwise leaves non-obvious application steps, issue one **Change Delivery Package**.

The package contains:

1. all created/changed deliverable files for that change set; and
2. one concise application-instructions document.

A ZIP is the normal portable package representation where supported.

The application instructions should identify, where applicable:

- file/action;
- destination master folder/project;
- whether it is new or replaces a Current master;
- which prior version moves to `superseded/`;
- archive/withdraw/remove action where relevant;
- generated Binder/Bundle regeneration or replacement;
- GPT/Claude/project-context files to add/remove/replace;
- cross-project ownership/moves;
- deployment/source changes;
- transfer-only/handoff artefacts that must **not** become masters;
- actions requiring another project/chat/authority;
- intentionally unchanged related items where omission could be mistaken for oversight; and
- any unconfirmed action that remains for the user/environment to perform.

#### Trigger

Do not force packaging ceremony for every trivial one-file change.

Use a Change Delivery Package when one or more of these is true: multiple deliverable files changed/created; lifecycle actions are required; files go to different destinations; project context/binders/bundles must change; the change is being handed to another project/session; the user could reasonably be unsure what to do with the outputs; or loss/misapplication risk is material.

#### Package is not authority

The ZIP/instructions are delivery artefacts. Files inside become authoritative only when applied to their stated destination according to the owning corpus/environment process.

Do not report those application actions as completed merely because the package was generated.

### WP2 — Gloss coded references

On first use in a response, give a short plain-language gloss for coded references such as section, decision/question IDs or opaque document/capability references when the meaning is not already obvious in the immediate context.

### WP3 — Check externally held/current facts before asserting them

When a statement depends on another party's records, installed state, current files, environment configuration or other inspectable authority, check the available source/tool first when reasonably possible.

If it cannot be verified, say what is unknown. Do not manufacture a plausible value.

### WP4 — Do not silently assume material state changes

Generating, proposing or handing off a change is not the same as applying it.

Clearly distinguish `created`, `proposed`, `handed off`, `applied`, `installed`, `deployed`, and `verified`.

Use the appropriate authority/tool/environment observation before claiming completion.

### WP5 — Surface architecture-shaping choices

Handle routine, low-risk and reversible choices autonomously.

For a genuinely architecture-shaping decision or material trade-off, present enough structure for the user to decide without reconstructing the alternatives:

```text
Decision
Recommendation
Why
Credible alternative
Consequence
```

Do not inflate routine implementation details into decision ceremony.

### WP6 — Work in layers before detail

For complex design/problem-solving work, establish a compact intent/premise layer and model before deep elaboration.

Prefer a small human-comprehensible working set and surface partial conclusions early enough for the user to steer.

### WP7 — Preserve durable handoff when work moves

When substantial confirmed work moves to another project, session, environment or responsible owner, provide a compact handoff containing authoritative source artefacts, confirmed model/decisions, remaining work, important deferred/non-goals, and application/integration instructions.

A handoff summary is transfer material unless the destination explicitly adopts it as a master. Once integrated, stale handoff summaries should not remain in ongoing project context beside the authoritative source unless they still have an active purpose.

## Standalone use

The Working Practices Standard must not assume software development.

A general AI environment may deploy only `AIDE_Principles` and `AIDE_WorkingPractices` through an appropriate Bootstrap Profile.

A full AIDE development environment may deploy the same base guidance alongside Core, Domain, Project Design, Build, Documentation Methodology and other Capabilities.

## Intended outcome

Produce:

```text
AIDE_WorkingPractices@v1
```

The Standard should be concise, operational and platform-neutral. Detailed examples may remain in Design/Guide material rather than bloating startup/base guidance.

---
Dependencies: !AIDE_DocumentationMethodology@v18
References: WorkingPractices_Decisions_v1, Principles_Design_v2, Core_Bootstrap_Design_v1
