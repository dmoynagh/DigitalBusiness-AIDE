# Package file hashes

- `AIDE_GuidanceBootstrap_ChangeDelivery_Instructions_2026-08-31.md` — sha256 `1242ced50c00e30b1cbfa67f43377765ddbf4128196b8618c88e92bfae218f93`
- `Core/Core_Bootstrap_Decisions_v1.md` — sha256 `8e69d84d15498b017fc50c93e8dfb2e2df8c37e9a0774faa08d1d75d922d7b6a`
- `Core/Core_Bootstrap_Design_v1.md` — sha256 `7ddc8bdc66c054d5819eae4ad34fa7a3725641c997ba0c3c1aebb153cd6e747f`
- `Principles/Principles_Brief_v2.md` — sha256 `2bdbf287198b11a62b3f51f0604741bc86113d7323edbaa610c796a736968603`
- `Principles/Principles_Decisions_v2.md` — sha256 `954bce76c78e25b916a49344d006dab5479f7e79d49a8079b5317df9a604f229`
- `Principles/Principles_Design_v2.md` — sha256 `9564db380f4de70ceb5b66097e8656e9e609cb0953b93ebafb943348d74da5af`
- `Principles/Principles_Index_v2.md` — sha256 `ad8630ac25e348c339e5ee6443d1d5558579798a05001afae872f1aaa7b53960`
- `Working Practices/WorkingPractices_Brief_v1.md` — sha256 `5fb9a691bc496f7cbc3bf279ae8bc2598e495baa776a787052869481e837793f`
- `Working Practices/WorkingPractices_Decisions_v1.md` — sha256 `cd11dba52c61cbfcefcd4ef82a3fff82a7520c1e69be3c824577d72fd35f57cb`
- `Working Practices/WorkingPractices_Design_v1.md` — sha256 `eba9003a41ac597b2991a3ed824a7ca37fd837a16a268b746e11be60450b9e1d`
- `Working Practices/WorkingPractices_Index_v1.md` — sha256 `71790dc843804ef3cca04d89ffa1e64b903fe1c71d934f99bc1fb5d53c51e730`
