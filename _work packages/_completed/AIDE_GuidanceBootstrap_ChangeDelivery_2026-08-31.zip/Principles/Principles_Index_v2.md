# Principles — Index

> **Version 2** (2026-08-31). Reconciles the 2026-08-27 seed topic with the current AIDE model, separates operational Working Practices, and establishes Principles as independently deployable base guidance.
>
> Created: 2026-08-27 | Last modified: 2026-08-31

## Topic identity

**Topic:** Principles  
**Conceptual position:** top-level AIDE topic; independently deployable  
**Owner:** Alpha Publishing Ltd

## Document register

| Document | Version | Type | Status |
|---|---:|---|---|
| `Principles_Index` | v2 | Index | Current |
| `Principles_Design` | v2 | Design | Current |
| `Principles_Decisions` | v2 | Decisions | Current |
| `Principles_Brief` | v2 | Brief | Current |

Superseded: `Principles_Index_v1`, `Principles_Design_v1`, `Principles_Decisions_v1`, `Principles_Brief_v1`.

## Outcome

Produce a canonical, independently deployable base-guidance Standard:

```text
AIDE_Principles@v1
```

The Standard is usable as part of full AIDE, with `AIDE_WorkingPractices`, with a narrower Bootstrap Profile, or independently where only reasoning/design guidance is wanted.

## Relationship to Working Practices

Principles owns the durable reasoning premises used to judge approaches. Working Practices owns concrete cross-surface conventions for how an AI/user carries out and hands over work.

A principle may motivate a Working Practice without duplicating the operational rule.

## Next actions

1. Produce `AIDE_Principles@v1` from `Principles_Design_v2`.
2. Reconcile the Core top-level reference view to include Principles and Working Practices.
3. Add appropriate Bootstrap Profile entries when deployment profiles are built.
4. Regenerate the Principles Binder after master adoption.

---
Dependencies: !AIDE_DocumentationMethodology@v18
References: Principles_Design_v2, WorkingPractices_Design_v1
