# Principles — Brief

> **Version 2** (2026-08-31). Reconciled purpose after separation of Working Practices.
>
> Created: 2026-08-27 | Last modified: 2026-08-31

## Purpose

Principles defines the **base reasoning and problem-solving guidance** used when approaching work.

It answers:

> What durable premises should guide how we reason, design, challenge and choose an approach?

Its scope is cross-cutting: software, documents, design, research, administration, personal work and other AI-assisted activity.

## Position

Principles is a top-level AIDE topic, independently deployable, usable together with Working Practices, base guidance that may be refined by applicable Guidance Profiles, and intentionally small enough to remain cognitively useful.

## Not Principles

Concrete operating conventions such as output packaging, handoff formatting, coded-reference glossing or state-change confirmation belong to **Working Practices**.

## Outcome

```text
AIDE_Principles@v1
```

A portable base-guidance Standard.

---
Dependencies: !AIDE_DocumentationMethodology@v18
References: Principles_Design_v2, WorkingPractices_Brief_v1
