# Principles — Decisions

> **Version 2** (2026-08-31). Reconciles the v1 seed with the current AIDE architecture.
>
> Created: 2026-08-27 | Last modified: 2026-08-31

## D1 — Principles remains a top-level cross-cutting topic

**Decision.** Principles remains a top-level AIDE topic rather than belonging to Workflow, Capabilities, Core or a development Domain.

## D2 — Principles is independently deployable

**Decision.** `AIDE_Principles@v1` must work both as part of AIDE and on its own.

## D3 — Principles is base guidance

**Decision.** The canonical Standard defines the portable default rather than encoding one user/team's final customised behaviour.

## D4 — Guidance Profiles may add/refine/override the base

**Decision.** Organisation/group/team/user-specific Guidance Profiles may provide small deltas using Add, Refine and explicit Override semantics.

**Reason.** This preserves a stable common base without forking/copying the Standard for each context.

## D5 — Do not promote Guidance Profiles into another generic component yet

**Decision.** Principles and Working Practices use one common conceptual profile model but no new top-level profile subsystem is created yet.

## D6 — Principles and Working Practices are siblings

**Decision.** Working Practices is a separate top-level topic, not a child of Principles.

## D7 — Operational v1 rules move without loss

**Decision.** Concrete v1 rules such as coded-reference glossing, record verification behaviour and state-change confirmation are represented in Working Practices rather than duplicated in Principles.

## D8 — Replace declaration over inference with authoritative evidence

**Decision.** The v1 principle `Declaration over inference` is replaced by **Authoritative evidence over incidental inference**.

**Reason.** The old wording stated that Domains are declared, but the confirmed Core Domain model allows implicit Domains resolved from recognised authoritative structures. The deeper intent was to reject accidental/proximity inference, not all model-defined inference.

## D9 — Maintain a small cognitive working set

**Decision.** Principles continues to require layered, human-comprehensible modelling before detailed elaboration.

---
Dependencies: !AIDE_DocumentationMethodology@v18, Principles_Design_v2
References: WorkingPractices_Decisions_v1
