# Principles — Design

> **Version 2** (2026-08-31). Reviews the v1 seed, separates operational Working Practices, reconciles Domain reasoning, and establishes profile-capable independently deployable base guidance.
>
> Created: 2026-08-27 | Last modified: 2026-08-31

## Purpose

Principles defines durable reasoning and problem-solving premises for AI-assisted work regardless of subject or platform.

The Principles Standard supplies **base guidance**: absent more specific applicable guidance, reason and design this way.

It is part of AIDE but is also independently deployable.

## Separation from Working Practices

Use this test:

```text
Principle        → what underlying premise should guide judgement?
Working Practice → how should we practically work/communicate/hand over?
```

Operational rules from v1 are preserved through Working Practices rather than being lost or duplicated.

## Base guidance and Guidance Profiles

`AIDE_Principles@v1` is the portable base.

Optional organisation/group/team/user Guidance Profiles may provide deltas that:

```text
Add       additional compatible guidance
Refine    make the base more specific for the context
Override  deliberately replace a named base position
```

Profiles should contain only deltas, not copied forks of the base Standard.

Within the AIDE guidance model, more specifically applicable guidance may refine broader guidance. Equal-specificity contradictions fail visibly unless an explicit ordering exists.

Platform/system instruction priority remains outside AIDE and always governs where stronger. A direct current instruction may provide the most specific AIDE-level guidance where permitted by the host platform and governing constraints.

The exact shared Guidance Profile schema is deliberately not promoted into a new generic AIDE component yet. Principles and Working Practices are the first two demonstrated consumers and should use the same conceptual composition contract.

## Confirmed principles

### Value over compliance

Everything in the system exists to create value for the person doing the work. Rules are justified when they protect something important, preserve integrity, or enable a capability. Rules for their own sake create friction.

**Test:** what does this enable, and what does compliance cost?

Persistent routing around a rule is evidence that the rule/model should be re-examined.

### Purpose before mechanism

Ask what something is for before deciding how it works. A mechanism with unclear purpose cannot be evaluated properly. Purpose settles whether a thing should exist; mechanism settles how.

**Failure mode:** structural/model problems being answered by adding mechanism.

### Model before elaboration

State the model before building detailed machinery on it. Elaboration should be checked against a visible model rather than gradually replacing it.

**Failure mode:** detailed mechanisms make an average or misunderstood premise look settled merely because later work depends on it.

### Keep the working set human-comprehensible

The active conceptual working set should remain small enough for the human owner to hold and challenge at once.

Large detail dumps too early do not merely slow design; they remove the human from meaningful participation.

Use layered progression: intent/premises, then model, then detail.

### Authoritative evidence over incidental inference

Prefer explicit declarations and authoritative structural relationships over conclusions drawn from mere presence, proximity or naming coincidence.

Inference is acceptable where the governing model explicitly defines what authoritative evidence supports that inference.

Examples: a solution's member-project relationship is authoritative evidence; a Domain may be implicit from recognised authoritative structures under the Domain Standard; files merely sharing a folder do not become one Domain by proximity.

This replaces the v1 wording "Domains are declared, not detected", which no longer matches the confirmed implicit-Domain model.

### Information holder decides the boundary

When deciding which component/project/domain should answer a boundary question, prefer the owner that holds the information required to decide correctly rather than territorial ownership.

### Observation over prediction

Design mechanisms against demonstrated problems and repeated failure modes before adding enforcement for hypothetical ones.

Leave room for foreseeable future capability without building unused machinery prematurely.

### Loud failure over quiet absorption

When authoritative completion is not possible, stop or surface the unresolved condition clearly.

Do not turn uncertainty, missing information or contradictory authority into output that merely looks complete. Failure messages should guide remediation.

### Verified truth over plausible assertion

Where a fact depends on records, environment state or another authority, verify it when reasonably available. If it cannot be verified, identify the uncertainty rather than manufacture a plausible value.

### Confirmed state over assumed state

Actions that materially change corpus/environment state must not be silently treated as completed when they were only proposed, generated or handed off.

State changes should be confirmed by the authority/tool/environment that can actually perform or observe them.

## Operational material moved to Working Practices

The following v1 material remains valuable but is operational rather than a root reasoning principle and is therefore carried into `WorkingPractices_Design_v1`:

- gloss coded references;
- ask/check before asserting externally held facts;
- zero silent assumptions for material state-changing actions; and
- concrete handoff/delivery conventions.

The higher-level premises behind those practices remain represented above.

## Intended outcome

Produce:

```text
AIDE_Principles@v1
```

The Standard should remain short, portable, platform-neutral and independently deployable. It may be activated through a Bootstrap Profile but does not require full AIDE.

---
Dependencies: !AIDE_DocumentationMethodology@v18
References: Principles_Decisions_v2, WorkingPractices_Design_v1, Core_Bootstrap_Design_v1
