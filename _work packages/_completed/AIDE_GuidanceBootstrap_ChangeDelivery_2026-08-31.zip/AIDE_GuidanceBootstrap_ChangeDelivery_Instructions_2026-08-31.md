# AIDE Guidance + Bootstrap — Change Delivery Instructions

> Change Delivery Package issued 2026-08-31.
>
> This document is a **transfer/application artefact**, not an enduring AIDE master.

## What this package contains

This change set captures three confirmed pieces of work:

1. the focused Core Bootstrap/Profile design;
2. reconciliation of the existing Principles seed corpus; and
3. creation of Working Practices as a new top-level AIDE topic, including the Change Delivery Package convention used for this package itself.

No canonical runtime Standards are built in this package. The next production step is to build `AIDE_Principles@v1`, `AIDE_WorkingPractices@v1` and the appropriate Core Bootstrap contract/profile representation after the source documents are adopted into their owning projects.

## Application manifest

| File | Action | Destination | Replaces / supersedes | Project context |
|---|---|---|---|---|
| `Core/Core_Bootstrap_Design_v1.md` | Add | `AIDE/Core/` | New | Add to Core project context for integration |
| `Core/Core_Bootstrap_Decisions_v1.md` | Add | `AIDE/Core/` | New | Add to Core project context for integration |
| `Principles/Principles_Index_v2.md` | Replace Current | `AIDE/Principles/` | `Principles_Index_v1.md` → `superseded/` | Use refreshed Principles Binder/context after adoption |
| `Principles/Principles_Design_v2.md` | Replace Current | `AIDE/Principles/` | `Principles_Design_v1.md` → `superseded/` | Use refreshed Principles Binder/context after adoption |
| `Principles/Principles_Decisions_v2.md` | Replace Current | `AIDE/Principles/` | `Principles_Decisions_v1.md` → `superseded/` | Use refreshed Principles Binder/context after adoption |
| `Principles/Principles_Brief_v2.md` | Replace Current | `AIDE/Principles/` | `Principles_Brief_v1.md` → `superseded/` | Use refreshed Principles Binder/context after adoption |
| `Working Practices/WorkingPractices_Index_v1.md` | Add | `AIDE/Working Practices/` | New | Establish new project/context |
| `Working Practices/WorkingPractices_Design_v1.md` | Add | `AIDE/Working Practices/` | New | Establish new project/context |
| `Working Practices/WorkingPractices_Decisions_v1.md` | Add | `AIDE/Working Practices/` | New | Establish new project/context |
| `Working Practices/WorkingPractices_Brief_v1.md` | Add | `AIDE/Working Practices/` | New | Establish new project/context |

## Principles actions

1. Create/use `AIDE/Principles/`.
2. Move the four current v1 files into `AIDE/Principles/superseded/`.
3. Copy the four v2 files from this package into the Principles master-folder root.
4. Regenerate the Principles Binder from the v2 masters.
5. Refresh the Principles AI project context with the regenerated Binder/current operating material. Do not leave v1 masters beside v2 in active context.

### Important reconciliation

The v1 wording `Domains are declared, not detected` is intentionally not retained.

It is replaced by **Authoritative evidence over incidental inference**, which supports the new Core Domain model where Domains may be implicit from recognised authoritative structures while still rejecting mere proximity/presence inference.

Concrete v1 behaviours such as coded-reference glossing and verification/state-change conventions are preserved under Working Practices rather than discarded.

## Working Practices actions

1. Create a new top-level master folder/project: `AIDE/Working Practices/`.
2. Copy all four Working Practices v1 master files into it.
3. Establish a dedicated Working Practices AI project when convenient, or temporarily add the masters to a suitable design project until the dedicated project exists.
4. Generate a Working Practices Binder after the masters are adopted.
5. Build the canonical runtime Standard later through the normal capability/Standards Production path: `AIDE_WorkingPractices@v1`.
6. When deployed, this Standard may be used as part of full AIDE or independently.

## Core Bootstrap actions

Copy `Core_Bootstrap_Design_v1.md` and `Core_Bootstrap_Decisions_v1.md` into `AIDE/Core/`.

These are confirmed Core design inputs, but the current `Core_Index`, `Core_System_Design` and `Core_System_Decisions` still need reconciliation in the Core project.

### Recommended Core integration pass

If the earlier Domain integration has **not** yet been completed, perform Domain + Bootstrap + top-level Principles/Working Practices reconciliation in the same Core pass.

The Core integration should:

1. read current Core Binder/current Core masters;
2. read `Core_Domain_Design_v1` + `Core_Domain_Decisions_v1` if still pending;
3. read the two new Bootstrap masters;
4. read the current Principles/Working Practices design summaries;
5. register Domain and Bootstrap Core subtopic/source documents in the Core Index as appropriate;
6. update the Core system reference view to include top-level Principles and Working Practices;
7. retain development/product Domains as external consumers of AIDE;
8. replace the old minimal bootstrap wording with the confirmed Profile/Contribution model without duplicating the full Bootstrap Design;
9. regenerate the Core Binder; and
10. move superseded Core System/Index versions according to normal Documentation Methodology lifecycle.

Do not edit the generated Core Binder directly.

## Bootstrap model being handed to Core

```text
persistent platform bootstrap
        ↓
Bootstrap Profile (what / why / where)
        ↓
thin separate Bootstrap Contributions
        ↓
full guidance / Standards / Tools loaded when needed
```

Key boundaries:

- Profile content stays thin.
- Component bootstrap contributions stay thin and separate from full Standards.
- Startup-required dependencies use normal Dependencies semantics (`!!`).
- Bootstrap detects/surfaces; it does not deploy.
- Deployment Authority decides what may be installed.
- AI Deployment performs authorised reconciliation.
- Environment supplies target/source/access facts.
- Future trusted automatic acquisition is allowed architecturally but not designed now.
- Generic startup-task orchestration is deferred.
- One effective Bootstrap Profile by default; no-profile is valid.

## Principles + Working Practices model being handed to Core

Both are top-level AIDE concerns and both produce independently deployable base guidance:

```text
AIDE_Principles@v1
AIDE_WorkingPractices@v1
```

Both may be customised through small Guidance Profile deltas: `Add`, `Refine`, `Override`.

Do not fork/copy the base Standard to make user/team variants.

The generic Guidance Profile mechanism should not yet be promoted into another top-level AIDE component; Principles and Working Practices are the demonstrated consumers.

## Deployment/context consequences

No runtime deployment is changed merely by applying these source documents.

After canonical Standards/Bootstrap artefacts are built, AI Deployment should add them to desired deployment sets/targets; appropriate Bootstrap Profiles should identify them using what/why/where; a general profile may load only Principles + Working Practices; an AIDE development profile may additionally establish Core/Domain/Project Design/Build/DocMeth and relevant capability awareness; and the persistent machine-level bootstrap instruction should remain small and should not need release-by-release editing.

## Transfer-only artefacts

This instructions document and the enclosing ZIP are transfer/application artefacts. Do **not** add either to the long-term Principles, Working Practices or Core master corpus.

They may be deleted after the changes are successfully adopted, or retained in a non-master delivery/archive location if a handoff record is useful.

## Not done by this package

The following are intentionally **not claimed complete**:

- Core Index/System reconciliation;
- Core Binder regeneration;
- Principles Binder regeneration;
- Working Practices Binder generation;
- canonical Standard production;
- Bootstrap Profile schema/platform rendering;
- runtime deployment;
- Custom Instructions / Claude Instructions changes; or
- automatic package acquisition/source resolution.

Those require their owning project/process/authority.

---
References: Core_Bootstrap_Design_v1, Principles_Design_v2, WorkingPractices_Design_v1
