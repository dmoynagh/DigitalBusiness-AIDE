# AIDE Foundation — Change Delivery Instructions — 2026-08-31

## Purpose

Apply the coordinated Foundation consolidation confirmed on 2026-08-31:

- Core-owned generic Index / Item Type framework;
- Domain-approved Domain recognition plus propagation-stop semantics;
- top-level-topic semantic anchoring distinct from chat-project/master-folder containers;
- Documentation Methodology v21 WIP / Working / OpenItems / WorkRegister model;
- Design → WorkRegister → WorkPackage → Outcome reconciliation;
- Project Design physical-path correction;
- stable Binder versus separately loaded live-state convention; and
- first repository-level `Documentation_Index` using the generic Index model.

Apply this as one coordinated release. The files intentionally reference each other's new current
versions; do not treat a partially applied subset as the final state.

## Release identities

| Concern | New current identity/state |
|---|---|
| Generic Index | `AIDE_Index@v1` |
| Domain | `AIDE_Domain@v2` |
| Documentation Methodology | `AIDE_DocumentationMethodology@v21` |
| Working Practices | formal identity remains `AIDE_WorkingPractices@v1`; Standard document issue v4 |
| Project Design | `AIDE_ProjectDesign@v2` |
| Build | `AIDE_Build@v4` |
| WorkPackage | `AIDE_WorkPackage@v2` |
| AI Deployment | unchanged at `AIDE_Deployment@v4` / `AIDE_DeploymentTool@v4` |

## Recommended application order

1. Core.
2. Documentation Methodology.
3. Working Practices.
4. Project Design.
5. Build.
6. Capabilities live/current-state reconciliation.
7. Repository-root `Documentation_Index_v1.md`.
8. Common Standards/Tools Bundle v5 and project-context Binder replacement.

---

## 1 — Core — `Documentation/AIDE/Core/`

### Add

- `Core_Index_Design_v1.md`
- `Core_Index_Decisions_v1.md`
- `AIDE_Index_Standard_v1.md`

### Replace Current

- `Core_Index_v3.md` → `Core_Index_v4.md`
- `Core_System_Design_v6.md` → `Core_System_Design_v7.md`
- `Core_System_Decisions_v5.md` → `Core_System_Decisions_v6.md`
- `Core_Domain_Design_v1.md` → `Core_Domain_Design_v2.md`
- `Core_Domain_Decisions_v1.md` → `Core_Domain_Decisions_v2.md`
- `AIDE_Domain_Standard_v1.md` → `AIDE_Domain_Standard_v2.md`

### Binder

- Add `Core_Binder_v1.md` as the first independently versioned current Core Binder.
- Replace the previously current unversioned `Core_Binder.md`/equivalent loaded Binder with
  `Core_Binder_v1.md`.

### Move to superseded

Move/retain the replaced issued masters and prior Binder under the current Core `_superseded/`
convention where historical retention is required/useful.

### Intentionally unchanged

- `Core_Bootstrap_Design_v2.md`
- `Core_Bootstrap_Decisions_v2.md`
- `AIDE_Bootstrap_Standard_v1.md`

The new Binder includes these unchanged current sources.

---

## 2 — Documentation Methodology — `Documentation/AIDE/Document Methodology/`

### Replace Current

- `DocumentationMethodology_Index_v5.md` → `DocumentationMethodology_Index_v6.md`
- `DocumentationMethodology_Design_v17.md` → `DocumentationMethodology_Design_v18.md`
- `DocumentationMethodology_Decisions_v18.md` → `DocumentationMethodology_Decisions_v19.md`
- `AIDE_DocumentationMethodology_Standard_v20.md` → `AIDE_DocumentationMethodology_Standard_v21.md`
- `DocumentationMethodology_Guide_v20.md` → `DocumentationMethodology_Guide_v21.md`
- `DocumentationMethodology_Binder_v1.md` → `DocumentationMethodology_Binder_v2.md`

### Move to superseded

Move/retain the replaced issued v20/v17-v18 masters and Binder v1 under the current
`_superseded/` convention.

### Important semantic changes

- Generic Index ownership moves to Core/`AIDE_Index@v1`; DocMeth retains documentation-specific
  Index extensions and defines `DocumentationTopic`.
- Container/project and top-level-topic are explicitly separate; standing registers anchor to the
  top-level topic by default.
- New `WIP` DocType is the high-churn current-context checkpoint.
- `Working` remains a distinct longer-lived substantial exploratory/formative DocType.
- `OpenItems` and `WorkRegister` are live-only; resolved/completed entries are removed rather than
  retained as tombstone history.
- WorkRegister is the undelivered-confirmed-consequence ledger and records enough implementation/
  outcome detail to reconcile committed Design with delivered reality.
- Normal stable Binders exclude WIP, Working, OpenItems and WorkRegister by default.

Migration posture for v21 is `None`; do not mass-rewrite unrelated existing documents merely to
adopt the new terminology.

---

## 3 — Working Practices — `Documentation/AIDE/Working Practices/`

### Replace Current

- `WorkingPractices_Index_v4.md` → `WorkingPractices_Index_v5.md`
- `WorkingPractices_Brief_v3.md` → `WorkingPractices_Brief_v4.md`
- `WorkingPractices_Design_v4.md` → `WorkingPractices_Design_v5.md`
- `WorkingPractices_Decisions_v4.md` → `WorkingPractices_Decisions_v5.md`
- `AIDE_WorkingPractices_Standard_v3.md` → `AIDE_WorkingPractices_Standard_v4.md`
- `WorkingPractices_Binder_v1.md` → `WorkingPractices_Binder_v2.md`

Formal capability identity remains `AIDE_WorkingPractices@v1` because this is still the
pre-distribution consolidated v1 capability; the Standard document issue becomes v4.

### Move to superseded

Move/retain the replaced issued masters and Binder v1 under `_superseded/`.

### Important practice changes

- persist active work before context loss would be materially costly;
- use WIP as the least-heavy physical current-context checkpoint;
- use visible WIP filename versioning as a cross-chat/platform currency signal; and
- keep normal Binders stable while loading live/high-churn state separately.

---

## 4 — Project Design — `Documentation/AIDE/Project Design/`

### Replace Current

- `ProjectDesign_Index_v1.md` → `ProjectDesign_Index_v2.md`
- `ProjectDesign_Design_v1.md` → `ProjectDesign_Design_v2.md`
- `ProjectDesign_Decisions_v1.md` → `ProjectDesign_Decisions_v2.md`
- `AIDE_ProjectDesign_Standard_v1.md` → `AIDE_ProjectDesign_Standard_v2.md`

### Binder

- Add `ProjectDesign_Binder_v1.md` as the first independently versioned current Binder.
- Replace the previously current unversioned Project Design Binder/equivalent context source.

### Move to superseded

Move/retain replaced v1 masters and prior Binder under `_superseded/`.

### Naming/path correction

The correct and historical physical master folder is:

```text
Documentation/AIDE/Project Design/
```

`AIDE/Design Project/` was an erroneous documentation/configuration reference, not a historical
folder name. Do **not** rename the physical folder.

### Behavioural change

Every confirmed Design change must identify downstream consequences. Any consequence not fully
delivered in the same pass is recorded in the owning top-level topic's WorkRegister. WorkPackages
may select manageable portions of those obligations and their Outcomes are reconciled back to the
register.

---

## 5 — Build — `Documentation/AIDE/Build/`

### Replace Current

- `Build_Index_v3.md` → `Build_Index_v4.md`
- `Build_Design_v3.md` → `Build_Design_v4.md`
- `Build_Decisions_v3.md` → `Build_Decisions_v4.md`
- `Build_WorkPackage_Design_v1.md` → `Build_WorkPackage_Design_v2.md`
- `AIDE_Build_Standard_v3.md` → `AIDE_Build_Standard_v4.md`
- `AIDE_WorkPackage_Standard_v1.md` → `AIDE_WorkPackage_Standard_v2.md`
- `Build_Binder_v3.md` → `Build_Binder_v4.md`

### Move to superseded

Move/retain all replaced issued masters and Binder v3 under `_superseded/`.

### Behavioural change

WorkPackage can map some/all of one or more WorkRegister obligations. Outcome returns per-mapped
obligation/portion result, evidence and remaining work where applicable. Build does not close the
WorkRegister; the owning/directing process reconciles it.

The Build v3 → Deployment v4 provenance/integrity/composition-posture boundary is preserved.

---

## 6 — Capabilities — `Documentation/AIDE/Capabilities/`

This Foundation pass does **not** perform the Messaging Design/Decisions/Standard/Tool work. It
only reconciles the current Capabilities structural/live state so that Messaging can be the next
clean work unit.

### Replace Current

- `Capabilities_Index_v14.md` → `Capabilities_Index_v15.md`
- `Capabilities_WorkRegister_v12.md` → `Capabilities_WorkRegister_v13.md`
- `Capabilities_OpenItems_v14.md` → `Capabilities_OpenItems_v15.md`

### Add

- `Capabilities_Messaging_WIP_v1.md` — current non-authoritative continuation checkpoint for the
  next Messaging pass.
- `Capabilities_Binder_Core_v1.md` — first independently versioned Core split-Binder.

### Binder/context handling

- Replace the current `Capabilities_Binder_Core.md` loaded context source with
  `Capabilities_Binder_Core_v1.md`.
- `Capabilities_Binder_Work.md` should no longer be the normal live-work context source under v21.
  Move/retain it as Superseded where useful and remove it from normal loaded project context.
- When actively working on Capabilities work state, load the current files directly:
  - `Capabilities_WorkRegister_v13.md`
  - `Capabilities_OpenItems_v15.md`
  - relevant WIP, currently `Capabilities_Messaging_WIP_v1.md`
- Existing other split Binders (`Runtime`, `Review`, `StandardsTools`) are unchanged by this
  Foundation pass.

### Important boundary

`WR16` records the confirmed direction to reconcile Messaging as an AIDE Capability. The current
Capabilities Design/Decisions are deliberately **not** rewritten in this package; that authoritative
Messaging integration/review is the next substantive work unit.

### Move to superseded

Move/retain the replaced Index/register versions and the old Core/Work Binder consumption artefacts
according to the current `_superseded/` convention.

---

## 7 — Repository root — `Documentation/`

### Add

- `Documentation_Index_v1.md` at the Documentation repository root.

This is the replacement for the earlier separate ProjectRegister idea. It is a generic Core Index,
not a new ProjectRegister DocType. It catalogues significant repository items and delegates at
self-describing DocumentationTopic boundaries. `Dev/` detailed migration is deliberately deferred.

No existing root file is replaced by this addition.

---

## 8 — Common Standards/Tools Bundle — `Documentation/_bundles/`

### Replace generated current Bundle

- `AIDE_Bundle_StandardsTools_v4.md` → `AIDE_Bundle_StandardsTools_v5.md`

The Bundle is generated/non-authoritative. v5 incorporates the new Foundation Standards and keeps
unchanged current Standards/Tools, including AI Deployment v4.

Move/retain Bundle v4 under the applicable `_bundles/_superseded/` or equivalent current generated-
artefact convention.

If the Bundle is loaded into ChatGPT project context, replace v4 with v5 after applying the masters.

---

## 9 — AI Deployment

No AI Deployment master is changed by this Foundation package.

Current baseline remains:

```text
AIDE_Deployment@v4
AIDE_DeploymentTool@v4
```

Its Build v3-facing wording is already compatible with the v4 Build release because Build v4
preserves the deployment-facing v3 contract and adds WorkRegister traceability upstream of that
boundary.

---

## 10 — Context refresh after application

After applying the files:

1. Replace loaded project Binders with the new Binder versions for Core, Documentation Methodology,
   Working Practices, Project Design, Build and Capabilities Core.
2. Remove the old Binder versions from normal project context.
3. For Capabilities active work, load the live WorkRegister/OpenItems/Messaging WIP separately.
4. Replace the common Standards/Tools Bundle v4 with v5 wherever the temporary Bundle is the current
   runtime/context source.
5. Do not claim deployment/runtime adoption merely because files were applied to the Documentation
   repository; deployment/verification remains a later AI Deployment step.

## 11 — Next work unit

After this package is applied, start Messaging in a fresh Capabilities chat using:

- current `Capabilities_Binder_Core_v1` plus the unchanged relevant Capabilities split Binders;
- `Capabilities_WorkRegister_v13`;
- `Capabilities_OpenItems_v15`;
- `Capabilities_Messaging_WIP_v1`; and
- the existing Workflow Messaging brief/source corpus.

The Messaging pass should reconcile and peer-review the existing successful AI-MESSAGE system,
not redesign it from scratch.
