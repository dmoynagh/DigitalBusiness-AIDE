# Documentation — Index

> **Version 1** (2026-08-31). First repository-level Index using `AIDE_Index@v1`; catalogues
> significant repository containers and delegates AIDE topic internals to their self-describing
> topic Indexes.
>
> Created: 2026-08-31 | Last modified: 2026-08-31

Repository Index for the Documentation corpus.

`{scope: "."}`

## Contents

- **AIDE/** — AIDE system design, standards, methods and operating model.  
  `Folder`

  - **AI Deployment/** — Deployment reconciliation, delivery and runtime verification.  
    `DocumentationTopic`  
    `{container: "AI Deployment"}`

  - **Build/** — Objective-driven execution and WorkPackage behaviour.  
    `DocumentationTopic`  
    `{container: "Build"}`

  - **Capabilities/** — Reusable capability infrastructure and capability-owned Standards/Tools.  
    `DocumentationTopic`  
    `{project: "AIDE Capabilities"}`

  - **Core/** — AIDE system foundations including Index, Domain and Bootstrap.  
    `DocumentationTopic`  
    `{container: "Core"}`

  - **Document Methodology/** — Governed document/corpus methodology and documentation-specific
    Index extensions.  
    `DocumentationTopic`  
    `{container: "Document Methodology"}`

  - **Deployment/** — Existing deployment-related repository material not registered in this
    Index as a current top-level DocumentationTopic.  
    `Folder`

  - **Principles/** — Portable reasoning/problem-solving premises.  
    `DocumentationTopic`  
    `{container: "Principles"}`

  - **Project Design/** — Generic methodology for determining substantial work before execution.  
    `DocumentationTopic`  
    `{container: "Project Design"}`

  - **Working Practices/** — Portable AI/user collaboration and operating conventions.  
    `DocumentationTopic`  
    `{container: "Working Practices"}`

- **Dev/** — Development/product documentation.  
  `Folder`  
  `{migration: "Index migration deferred until the current AIDE foundation/capability work is complete"}`

- **Orchard/**  
  `Folder`

- **Working/**  
  `Folder`

- **_bundles/** — Generated consumption bundles.  
  `Folder`

- **_changeDeliveryPackages/** — Change Delivery staging/completion workflow.  
  `Folder`

- **_archived/** — Repository-management holding for material already determined Archived.  
  `Folder`

- **_superseded/** — Repository-management holding for material already determined Superseded.  
  `Folder`

## Index notes

- This Index is authoritative for the repository registrations/properties it owns, not for the
  internals of the registered topics.
- Each `DocumentationTopic` resolves its own governing Index/Document Register after selection.
- The current AIDE layout is largely one top-level topic per folder, but that is not a requirement;
  a future container may host several distinct top-level topics.
- `Dev/` descendants are intentionally not migrated/catalogued in detail in this pass.

---
Dependencies: !AIDE_DocumentationMethodology@v21, AIDE_Index@v1
References: Core_Index_Design_v1, DocumentationMethodology_Design_v18
