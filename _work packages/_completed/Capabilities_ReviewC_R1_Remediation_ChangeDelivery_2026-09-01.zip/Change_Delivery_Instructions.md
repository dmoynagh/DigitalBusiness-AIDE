# Change Delivery Instructions — Review C R1 Remediation

Date: 2026-09-01
Scope: AIDE Capabilities — Review C R1 accepted remediation only

## Purpose

Apply the GPT Lead-dispositioned Review C R1 changes as one coherent Capabilities pass, regenerate
the affected Binders, and prepare the focused High R2 verification. Do not broaden into Review D or
Review E.

## Apply

1. In the Capabilities master folder, add the new current masters and replace/supersede the prior
   current versions with the correspondingly named newer versions supplied in this package.
2. Add the new canonical outcome `AIDE_ToolsProduction_Standard_v1.md`.
3. Replace the current generated Capabilities Binders with the five regenerated Binders supplied:
   - `Capabilities_Binder_Core_v3.md`
   - `Capabilities_Binder_StandardsTools_v1.md`
   - `Capabilities_Binder_Runtime_v1.md`
   - `Capabilities_Binder_Review_v3.md`
   - `Capabilities_Binder_Messaging_v2.md`
4. For StandardsTools and Runtime, the previous current Binder filenames were unversioned. Treat
   these new `v1` files as the first versioned issues under the current Binder-versioning convention;
   move the former unversioned Binder files to `_superseded` rather than retaining two current
   Binders.
5. Replace `Capabilities_WIP_v12.md` with `Capabilities_WIP_v13.md` after the master/Binder changes
   are applied. v13 records `R1 remediation applied — R2 prepared`.
6. Leave `Capabilities_WorkRegister_v16.md` and `Capabilities_OpenItems_v15.md` unchanged. WR17
   remains in progress; no OpenItem changes are created by this remediation.
7. Leave untouched legacy-form Capabilities masters untouched. Documentation Methodology v18 is
   OnUpdate; only substantively changed files in this package were migrated to the current
   Dependencies/References footer form/checkpoint.
8. Do not update/rebuild the temporary `AIDE_Bundle_StandardsTools_v5` for semantic authority. It
   remains a non-authoritative temporary consumption artefact and can be rebuilt later if separately
   needed for temporary runtime consumption.

## Replacement map

Apply these current-master replacements:

```text
Capabilities_Index_v16.md                         -> Capabilities_Index_v17.md
Capabilities_Brief_v8.md                          -> Capabilities_Brief_v9.md
Capabilities_Overview_v14.md                      -> Capabilities_Overview_v15.md
Capabilities_Design_v9.md                         -> Capabilities_Design_v10.md
Capabilities_Decisions_v15.md                     -> Capabilities_Decisions_v16.md
Capabilities_Standards_Design_v4.md               -> Capabilities_Standards_Design_v5.md
AIDE_StandardsProduction_Standard_v1.md           -> AIDE_StandardsProduction_Standard_v2.md
Capabilities_Tools_Brief_v2.md                    -> Capabilities_Tools_Brief_v3.md
Capabilities_Tools_Design_v2.md                   -> Capabilities_Tools_Design_v3.md
Capabilities_BuildCapability_Tool_Design_v1.md    -> Capabilities_BuildCapability_Tool_Design_v2.md
AIDE_BuildCapability_Tool_v1.md                   -> AIDE_BuildCapability_Tool_v2.md
Capabilities_Tags_Design_v1.md                    -> Capabilities_Tags_Design_v2.md
AIDE_Tags_Standard_v1.md                          -> AIDE_Tags_Standard_v2.md
Capabilities_Scope_Design_v1.md                   -> Capabilities_Scope_Design_v2.md
AIDE_Scope_Standard_v1.md                         -> AIDE_Scope_Standard_v2.md
Capabilities_Dependencies_Design_v2.md            -> Capabilities_Dependencies_Design_v3.md
AIDE_Dependencies_Standard_v2.md                  -> AIDE_Dependencies_Standard_v3.md
Capabilities_Migration_Brief_v1.md                -> Capabilities_Migration_Brief_v2.md
Capabilities_Migration_Design_v1.md               -> Capabilities_Migration_Design_v2.md
AIDE_Migration_Standard_v1.md                     -> AIDE_Migration_Standard_v2.md
Capabilities_Migration_Tool_Design_v1.md          -> Capabilities_Migration_Tool_Design_v2.md
AIDE_Migration_Tool_v1.md                         -> AIDE_Migration_Tool_v2.md
Capabilities_Review_Design_v2.md                  -> Capabilities_Review_Design_v3.md
Capabilities_Review_Decisions_v2.md               -> Capabilities_Review_Decisions_v3.md
AIDE_Review_Standard_v2.md                        -> AIDE_Review_Standard_v3.md
AIDE_ReviewProfiles_Standard_v1.md                -> AIDE_ReviewProfiles_Standard_v2.md
Capabilities_Review_Tool_Design_v2.md             -> Capabilities_Review_Tool_Design_v3.md
AIDE_Review_Tool_v2.md                            -> AIDE_Review_Tool_v3.md
Capabilities_Messaging_Brief_v1.md                -> Capabilities_Messaging_Brief_v2.md
Capabilities_Messaging_Design_v1.md               -> Capabilities_Messaging_Design_v2.md
Capabilities_Messaging_Decisions_v1.md            -> Capabilities_Messaging_Decisions_v2.md
AIDE_Messaging_Standard_v1.md                     -> AIDE_Messaging_Standard_v2.md
Capabilities_WIP_v12.md                           -> Capabilities_WIP_v13.md
```

Add as a new current master:

```text
AIDE_ToolsProduction_Standard_v1.md
```

Leave current/unchanged:

```text
Capabilities_Standards_Brief_v2.md
AIDE_StandardsUsage_Standard_v1.md
Capabilities_Messaging_Tool_Design_v1.md
AIDE_Messaging_Tool_v1.md
Capabilities_WorkRegister_v16.md
Capabilities_OpenItems_v15.md
```

## Supersede, do not rewrite history

Move prior versions of every replaced master/Binder to the normal `_superseded` location. Do not
rewrite historical Decisions or completed Review A/B records.

## After application — Review C R2

Use the existing Claude Review C chat. Supply only the five regenerated Binders listed above and
paste `ReviewC_R2_Claude_Request.md` exactly. Use Claude Opus 5 if available.

Do not send WIP, OpenItems, WorkRegister, the temporary Standards/Tools Bundle, or the completed
Review A/B records as R2 attachments; the R1 thread already contains the necessary review history.

Do not mark R2 Awaiting Response until the request is actually relayed.

## Review D carry

Review D must test concrete platform/build realisation of generated-tag freshness and related
production/build sequencing. Review C defines only the semantic requirement.

## Review E carry

The possible OpenItems + WorkRegister merge remains deferred to Review E.
