# Review C R1 Remediation — Delivery Manifest

## Replacements

- `Capabilities_Index_v16.md` → `Capabilities_Index_v17.md`
- `Capabilities_Brief_v8.md` → `Capabilities_Brief_v9.md`
- `Capabilities_Overview_v14.md` → `Capabilities_Overview_v15.md`
- `Capabilities_Design_v9.md` → `Capabilities_Design_v10.md`
- `Capabilities_Decisions_v15.md` → `Capabilities_Decisions_v16.md`
- `Capabilities_Standards_Design_v4.md` → `Capabilities_Standards_Design_v5.md`
- `AIDE_StandardsProduction_Standard_v1.md` → `AIDE_StandardsProduction_Standard_v2.md`
- `Capabilities_Tools_Brief_v2.md` → `Capabilities_Tools_Brief_v3.md`
- `Capabilities_Tools_Design_v2.md` → `Capabilities_Tools_Design_v3.md`
- `Capabilities_BuildCapability_Tool_Design_v1.md` → `Capabilities_BuildCapability_Tool_Design_v2.md`
- `AIDE_BuildCapability_Tool_v1.md` → `AIDE_BuildCapability_Tool_v2.md`
- `Capabilities_Tags_Design_v1.md` → `Capabilities_Tags_Design_v2.md`
- `AIDE_Tags_Standard_v1.md` → `AIDE_Tags_Standard_v2.md`
- `Capabilities_Scope_Design_v1.md` → `Capabilities_Scope_Design_v2.md`
- `AIDE_Scope_Standard_v1.md` → `AIDE_Scope_Standard_v2.md`
- `Capabilities_Dependencies_Design_v2.md` → `Capabilities_Dependencies_Design_v3.md`
- `AIDE_Dependencies_Standard_v2.md` → `AIDE_Dependencies_Standard_v3.md`
- `Capabilities_Migration_Brief_v1.md` → `Capabilities_Migration_Brief_v2.md`
- `Capabilities_Migration_Design_v1.md` → `Capabilities_Migration_Design_v2.md`
- `AIDE_Migration_Standard_v1.md` → `AIDE_Migration_Standard_v2.md`
- `Capabilities_Migration_Tool_Design_v1.md` → `Capabilities_Migration_Tool_Design_v2.md`
- `AIDE_Migration_Tool_v1.md` → `AIDE_Migration_Tool_v2.md`
- `Capabilities_Review_Design_v2.md` → `Capabilities_Review_Design_v3.md`
- `Capabilities_Review_Decisions_v2.md` → `Capabilities_Review_Decisions_v3.md`
- `AIDE_Review_Standard_v2.md` → `AIDE_Review_Standard_v3.md`
- `AIDE_ReviewProfiles_Standard_v1.md` → `AIDE_ReviewProfiles_Standard_v2.md`
- `Capabilities_Review_Tool_Design_v2.md` → `Capabilities_Review_Tool_Design_v3.md`
- `AIDE_Review_Tool_v2.md` → `AIDE_Review_Tool_v3.md`
- `Capabilities_Messaging_Brief_v1.md` → `Capabilities_Messaging_Brief_v2.md`
- `Capabilities_Messaging_Design_v1.md` → `Capabilities_Messaging_Design_v2.md`
- `Capabilities_Messaging_Decisions_v1.md` → `Capabilities_Messaging_Decisions_v2.md`
- `AIDE_Messaging_Standard_v1.md` → `AIDE_Messaging_Standard_v2.md`
- `Capabilities_WIP_v12.md` → `Capabilities_WIP_v13.md`

## New master

- `AIDE_ToolsProduction_Standard_v1.md`

## Regenerated Binders

- `Capabilities_Binder_Core_v3.md`
- `Capabilities_Binder_StandardsTools_v1.md`
- `Capabilities_Binder_Runtime_v1.md`
- `Capabilities_Binder_Review_v3.md`
- `Capabilities_Binder_Messaging_v2.md`

## Package file integrity

- `AIDE_BuildCapability_Tool_v2.md` — sha256 `923989b429ce8509b37b001391708fefe12bfda69d475966a97ef7f73a294dfd`
- `AIDE_Dependencies_Standard_v3.md` — sha256 `87e82ecc74740a2084c3ea3f85ffbb67f5a0d99e68a1485d6917396aad87f8e0`
- `AIDE_Messaging_Standard_v2.md` — sha256 `83dcdba381b2bc4e364836635cd8c7ebf42ac29f9c704e2916e9360f48132977`
- `AIDE_Migration_Standard_v2.md` — sha256 `3b7e6bfd2bfee8d793730c6f0cda481d14e166571e690fea278c9fea98951ebd`
- `AIDE_Migration_Tool_v2.md` — sha256 `2d1a31518b2485d8927ab46f3236cabec65d54ec4e0649055cc43a88ea2f4539`
- `AIDE_ReviewProfiles_Standard_v2.md` — sha256 `c319a69f77fb717d1b378ec4d8cdacd8aa38a5a98c88df474039227dc4ce2396`
- `AIDE_Review_Standard_v3.md` — sha256 `47dfc228e0881743b6082d7eb55deafd13bcc7c8732d3f5bbe6b61c53b222234`
- `AIDE_Review_Tool_v3.md` — sha256 `07d08b5a97d62c2f833214e603d2d0998213bf0d286d6cd6981c2d3b842ceff9`
- `AIDE_Scope_Standard_v2.md` — sha256 `5de007fa5a559a81fb8420a3df94d7aa57aa44959483b384b7b3f96606c1f3cb`
- `AIDE_StandardsProduction_Standard_v2.md` — sha256 `2d179e8f6eddc9da0a1ce73f13f85bbb46c69b9154ea7d655eb028a1fa78162b`
- `AIDE_Tags_Standard_v2.md` — sha256 `881e15326d8e07c4452c113ac23b07a7eacf7f58c2559af196f5503e04aa86bf`
- `AIDE_ToolsProduction_Standard_v1.md` — sha256 `c77ee2e1a330ff7ee257688dc822ff6757c9659b6a9b4dfeee38eb504f88c98f`
- `Capabilities_Binder_Core_v3.md` — sha256 `f9ee0e504f494997b11b2ee2cad4456f2f3dc0c18846b5b8d8ac270a80ee7f23`
- `Capabilities_Binder_Messaging_v2.md` — sha256 `37da00069248fdc92a85ae1458fca8f3c8cfbcc644e855fbee2a3c9a1138dff3`
- `Capabilities_Binder_Review_v3.md` — sha256 `f98fa08ff7e5aee15e7cea518783fb3dcb0b09be864cc51fe90e37bab49ecc8f`
- `Capabilities_Binder_Runtime_v1.md` — sha256 `9c434830d968c3f054830de225903fd760d5c6f578929ce06ff5cf79ed7ad70b`
- `Capabilities_Binder_StandardsTools_v1.md` — sha256 `10fac094284fc3f490f755130f70dcb54010226b5f3513a7a0e2369e9ba33847`
- `Capabilities_Brief_v9.md` — sha256 `139e3180ac8698326f3da76f71989bf2ad07f476ccc9835051222731d1e57609`
- `Capabilities_BuildCapability_Tool_Design_v2.md` — sha256 `e0beef1d5f8708c44479f44fd0ff3daa32e8b9ea7108c00fb1758afa6e8e7a6e`
- `Capabilities_Decisions_v16.md` — sha256 `a7ddd1589663a1d5392660543a89db9362daf691c29069471185216fe5a59007`
- `Capabilities_Dependencies_Design_v3.md` — sha256 `ee8326b631bef30c82dd7d218e24dd1fdda0a877610064b24c1ea989d8bced11`
- `Capabilities_Design_v10.md` — sha256 `518256e27efe2917d6a0b9610005543029e38ec45dbf46da14279c6cb2a398f3`
- `Capabilities_Index_v17.md` — sha256 `46ccc301b7f0676a5b1faf2e0651415bf9d4bb0b00484eb2dd3370902866a72e`
- `Capabilities_Messaging_Brief_v2.md` — sha256 `e638b6e3290f51644816aa5da4859c37e373b3fb1ab0258e8db9267c36f0dc0c`
- `Capabilities_Messaging_Decisions_v2.md` — sha256 `648d08621b13743aa80ea75968d7b88b4c4a80f8e8e4f8940059c14998614770`
- `Capabilities_Messaging_Design_v2.md` — sha256 `8d1b9744ec3806a5f559ac257c4f5fa76e4f54d25ee2efc8b8b1cd16b6d7d7ab`
- `Capabilities_Migration_Brief_v2.md` — sha256 `a6dcb9d1e8f0a293b76f178bd06a78ab3b1c0179c96b67bc09576dc99510ae90`
- `Capabilities_Migration_Design_v2.md` — sha256 `0092b28f02f58d7685f13a9c83c5413c57dd338e0c6b64131d9c0d51cffe14f4`
- `Capabilities_Migration_Tool_Design_v2.md` — sha256 `e2b78fb444c4aa7b787bf83e1ebbe53c3779aa718388d56b8db8c9fa3b2da9fb`
- `Capabilities_Overview_v15.md` — sha256 `9aee9b8facde46cdc741355a83c415e3ca85c71c165b5e34ca92000374ad661e`
- `Capabilities_Review_Decisions_v3.md` — sha256 `16e7812122c235962d05a5747853e28eb33193ba5fe9a466949b2cc1abc5cb10`
- `Capabilities_Review_Design_v3.md` — sha256 `20c14f8b3da3451cea833b5411fa93f7c965a112496e54580292b3544650c3e8`
- `Capabilities_Review_Tool_Design_v3.md` — sha256 `9606d87841a2b518ed60f41279d2bfb0cb51750037cd15194d8b284c7d2be289`
- `Capabilities_Scope_Design_v2.md` — sha256 `fc8746013c2151418401898b553ddb6feefd154fa5d1c71edd6a9156ed32c2a4`
- `Capabilities_Standards_Design_v5.md` — sha256 `ce0a69b19e0bbaf2009f0ed85fd390842ce66af5f256c92a5402aba87a9a2bc3`
- `Capabilities_Tags_Design_v2.md` — sha256 `6a1908a757415dda8a46cc1e5ee9d6f2bf097bb93e41e2235758dd677736d1f6`
- `Capabilities_Tools_Brief_v3.md` — sha256 `45bb3d87b105d33065daa4ba54fcbb3e6f371d7c3e347fa74b64e25a5d7a749c`
- `Capabilities_Tools_Design_v3.md` — sha256 `b0659fcc867d53c52efbe927327803553a800ebca490ef2fed798ec87e97bd4e`
- `Capabilities_WIP_v13.md` — sha256 `b16142053ea643a816a24ef121be653de370c52723258b90b21b11b90a853b2e`
- `Change_Delivery_Instructions.md` — sha256 `c3bef59b96591677f5dfb0fc206124375df4ef7a2f7f82b462085ff686f1a2a3`
- `ReviewC_R2_Claude_Request.md` — sha256 `1ec4260555613048c20f9437c310463e2eeef08be82c0c9ee03c905cdeff05a0`
