# Documentation Methodology — Change Delivery Instructions

> **Transfer/application artefact — not a master document.**
> **Date:** 2026-09-01
> **Scope:** Review B R2 closing correction only.

## What you need to do

1. In the `AIDE/Document Methodology/` current/master folder, add the five replacement masters listed below.
2. Move each replaced current predecessor to the project's `_superseded/` location.
3. Replace the current generated `DocumentationMethodology_Binder_v6.md` (or the locally named v6 copy) with `DocumentationMethodology_Binder_v7.md`; move the replaced Binder to `_superseded/` under the normal Working Practices convention.
4. Update the Documentation Methodology ChatGPT/Claude project sources so the current five masters and Binder resolve to the new versions.
5. Do **not** update `AIDE_Bundle_StandardsTools_v5.md` as part of this package. Bundle regeneration/deployment is a separate work item.
6. Do **not** perform any extra footer `Dependencies:` / `References:` currency sweep or historical Decisions rewrite while applying this package.

## Replace Current / move predecessor to `_superseded/`

| Add as Current | Replaces Current |
|---|---|
| `DocumentationMethodology_Index_v11.md` | `DocumentationMethodology_Index_v10.md` |
| `DocumentationMethodology_Design_v23.md` | `DocumentationMethodology_Design_v22.md` |
| `DocumentationMethodology_Decisions_v24.md` | `DocumentationMethodology_Decisions_v23.md` |
| `AIDE_DocumentationMethodology_Standard_v26.md` | `AIDE_DocumentationMethodology_Standard_v25.md` |
| `DocumentationMethodology_Guide_v26.md` | `DocumentationMethodology_Guide_v25.md` |
| `DocumentationMethodology_Binder_v7.md` | `DocumentationMethodology_Binder_v6.md` |

## Correction applied

- The current Standard's WorkPackage integration now names `AIDE_Build@v5`.
- The current Standard's Review document integration now names `AIDE_Review@v2`.
- Historical D41 is preserved unchanged.
- New D42 explicitly refines D41: R1 corrected the current references directly identified/affected by the coordinated remediation, but D41 overstated that as a complete five-master sweep; Round 2 found and closed the two additional active references.
- `AIDE_DocumentationMethodology@v26` / Guide v26 has migration posture `None`.
- No general rule for versioned in-body references, dependency checkpoints, or footer currency was introduced.

## No other lifecycle action

No archive/withdraw/rename/ownership change is required by this package beyond normal supersession of the replaced current issues.
