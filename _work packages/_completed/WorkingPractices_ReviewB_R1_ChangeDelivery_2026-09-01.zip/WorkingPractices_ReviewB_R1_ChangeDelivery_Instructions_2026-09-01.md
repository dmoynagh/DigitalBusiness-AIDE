# Working Practices — Review B R1 Change Delivery Instructions — 2026-09-01

## Purpose

Apply the accepted Review B Round 1 Working Practices remediation against the current Working
Practices v2 Binder/current masters.

This delivery implements:

- **RB-R1-F4** — removes duplicated normative ownership of Documentation Methodology live-state /
  Binder semantics while preserving Working Practices ownership of operational persistence,
  checkpointing, transfer, synchronisation, verification and physical handling; and
- **RB-R1-F6** — gives a received Project Handoff one existing OpenItem as a temporary live holder
  only when destination reconciliation is deferred beyond the current pass/context.

No Project Handoff DocType, Handoff register/archive, separate obligations ledger or standalone
Deployment/Dependency redesign is introduced.

## Apply to `AIDE/Working Practices/`

### Replace Current masters

Add these files to the active Working Practices master folder and replace the corresponding current
versions:

- `WorkingPractices_Index_v6.md` replaces `WorkingPractices_Index_v5.md`.
- `WorkingPractices_Brief_v5.md` replaces `WorkingPractices_Brief_v4.md`.
- `WorkingPractices_Design_v6.md` replaces `WorkingPractices_Design_v5.md`.
- `WorkingPractices_Decisions_v6.md` replaces `WorkingPractices_Decisions_v5.md`.
- `AIDE_WorkingPractices_Standard_v5.md` replaces `AIDE_WorkingPractices_Standard_v4.md`.

Move the replaced issued masters to `_superseded/` under the normal repository convention.

### Replace generated Binder

- Add `WorkingPractices_Binder_v3.md` to the active/master folder.
- Replace the loaded/current `WorkingPractices_Binder_v2.md` with `WorkingPractices_Binder_v3.md`.
- Treat `WorkingPractices_Binder_v2.md` as Superseded and move it to `_superseded/` where retained.
- Replace the Working Practices Binder in AI project/context sources with v3 where applicable.

### Project Handoff cleanup

This Review B R1 Handoff was reconciled in the same pass, so **do not create an OpenItem for it**.
After the delivery is applied/checked, remove `ProjectHandoff_ReviewB_R1_to_WorkingPractices.md`
from active project/context sources. Retain it only as transfer/history if another governing process
requires that; it is not an authoritative Working Practices master.

### Generated Standards/Tools Bundle consequence

`AIDE_Bundle_StandardsTools_v5.md` contains `AIDE_WorkingPractices_Standard_v4.md` and is therefore
stale with respect to this Working Practices pass. Do not edit the Bundle directly. Rebuild the
current generated Standards/Tools Bundle through its owning Build/AI Deployment flow so it consumes
`AIDE_WorkingPractices_Standard_v5.md` before that Bundle is used as current Review B Round 2
runtime evidence.

## Resulting current set

- `WorkingPractices_Index_v6.md`
- `WorkingPractices_Brief_v5.md`
- `WorkingPractices_Design_v6.md`
- `WorkingPractices_Decisions_v6.md`
- `AIDE_WorkingPractices_Standard_v5.md` — capability identity remains `AIDE_WorkingPractices@v1`
- `WorkingPractices_Binder_v3.md`

## Review B Round 2 cross-owner dependency

Before Round 2, confirm the paired Review B R1 Documentation Methodology remediation has been
applied to its own current masters/Binder, so both owners express the same semantic/operational
split. Also ensure any generated runtime Bundle supplied to the Reviewer has been rebuilt from the
new Working Practices Standard rather than the superseded v4 member.
