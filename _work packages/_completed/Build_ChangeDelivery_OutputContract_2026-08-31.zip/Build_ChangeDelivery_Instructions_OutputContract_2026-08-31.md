# Build — Change Delivery Instructions — Output Contract — 2026-08-31

## Purpose

Apply the AI Deployment → Build interface reconciliation with the smallest Build-owned change set.

The current Build v2 model already established canonical provenance and the Build/AI Deployment production boundary. This pass adds only the missing deployment-facing contract facts:

- authoritative/canonical source identity/version provenance;
- concrete Build-output/package identity and integrity evidence; and
- explicit composition posture: `MemberContribution` or `AssembledConsumptionArtefact`.

No universal Build manifest, new Build Tool or new packaging subsystem is introduced.

## Apply to `AIDE/Build/` masters

### Replace Current

Add these files to the current Build master folder and replace the corresponding v2 masters:

- `Build_Index_v3.md` — replaces `Build_Index_v2.md`.
- `Build_Design_v3.md` — replaces `Build_Design_v2.md`.
- `Build_Decisions_v3.md` — replaces `Build_Decisions_v2.md`.
- `AIDE_Build_Standard_v3.md` — replaces `AIDE_Build_Standard_v2.md`; canonical identity becomes `AIDE_Build@v3`.

### Move to `_superseded`

Move these replaced issued files to `AIDE/Build/_superseded/`:

- `Build_Index_v2.md`
- `Build_Design_v2.md`
- `Build_Decisions_v2.md`
- `AIDE_Build_Standard_v2.md`

### Leave Current unchanged

Do not replace or reissue:

- `Build_WorkPackage_Design_v1.md`
- `AIDE_WorkPackage_Standard_v1.md`

The incoming Handoff does not require a WorkPackage semantic change.

## Binder change

Use `Build_Binder_v3.md` as the new generated Build Binder/project-context Binder.

Replace `Build_Binder_v2.md` in active project context. Retain/move the older generated Binder according to the normal generated-artefact lifecycle; do not edit either Binder directly.

## AI Deployment Project Handoff

`Project_Handoff_Build_to_AI_Deployment_OutputContract_2026-08-31.md` is a transfer artefact, not a Build master.

Pass it to the AI Deployment project as the response/interface confirmation. It states that Build now guarantees source provenance, concrete Build-output identity/integrity and composition posture while leaving Deployment Set ownership, target reconciliation, target mutation and runtime verification in AI Deployment.

## Common Standards/Tools Bundle

Do **not** patch `AIDE_Bundle_StandardsTools_v3.md` directly from this package.

The existing Bundle is already stale with respect to Build and should be regenerated from current project Binders/canonical Standards/Tools in the planned cross-project Bundle build. When that regeneration occurs, select `AIDE_Build@v3` from `Build_Binder_v3.md` and record its source identity/version in the Bundle provenance.

## Capability/version consequence

`AIDE_Build@v3` declares `Transition: v3 / Posture: None`.

The change tightens the downstream handoff contract but does not prescribe migration of existing consumer state merely because v3 is available. Normal dependency/migration/save rules determine checkpoint advancement.

## Project-context changes

After applying the master changes:

1. replace the Build project-context Binder with `Build_Binder_v3.md`;
2. do not add this Change Delivery Instructions file as authoritative project context;
3. do not treat the Project Handoff as a Build master; and
4. later regenerate/replace the common Standards/Tools Bundle from all current canonical sources rather than patching the old Bundle.

## Package contents

```text
Build_ChangeDelivery_OutputContract_2026-08-31.zip
├── Build_Index_v3.md
├── Build_Design_v3.md
├── Build_Decisions_v3.md
├── AIDE_Build_Standard_v3.md
├── Build_Binder_v3.md
├── Project_Handoff_Build_to_AI_Deployment_OutputContract_2026-08-31.md
└── Build_ChangeDelivery_Instructions_OutputContract_2026-08-31.md
```
