# Project Handoff — Build → AI Deployment — Output Contract Reconciliation

> Transfer/reconciliation artefact. Not an authoritative corpus master.

## Reason for the Handoff

Build has reconciled the AI Deployment → Build interface request against the current Build v2 baseline.

The existing Build model already established canonical source provenance and the semantic-production/Deployment boundary, but it did not make two downstream facts contractual: concrete Build-output identity/integrity and whether the output is a mechanically assemblable member/contribution or an already assembled Build-owned consumption artefact.

Build has therefore tightened the interface without introducing a new packaging subsystem.

## Build-owned result

`AIDE_Build@v3` now requires deployment-facing Build output to expose, directly or through the applicable representation/package contract:

```text
source provenance
+ concrete Build-output identity/integrity
+ composition posture
```

The composition posture is:

```text
MemberContribution
```

for a target-compatible built member whose semantics are already produced by Build and which Deployment may mechanically include/arrange/assemble with other built members; or:

```text
AssembledConsumptionArtefact
```

for an authorised Build output whose semantic/member composition is already assembled by Build.

For an `AssembledConsumptionArtefact`, Deployment may deliver/reconcile the supplied artefact but does not use its payload as authority to semantically rebuild or change its member composition. A semantic/member-composition change requires another Build output.

## Manifest/interface mechanism

Build has **not** introduced one universal package-manifest schema.

The three required interface facts may be carried by the applicable platform/package contract. Where no such contract supplies them, the Build Outcome or equivalent handoff evidence carries them explicitly.

This keeps the generic Build contract stable while allowing platform-specific identity/integrity mechanisms.

## Deployment boundary retained

No Deployment-owned responsibility moves into Build:

- Deployment Set ownership remains in AI Deployment.
- Target reconciliation remains in AI Deployment.
- Target mutation/install/update/remove policy remains in AI Deployment.
- Runtime verification remains in AI Deployment.
- Deployment-time deterministic composition remains valid where it is mechanical assembly of Build outputs declared `MemberContribution`.

This Handoff is interface confirmation only. Reconcile it against current AI Deployment masters if any local wording/reference should acknowledge the now-explicit Build contract.
