
# Unresolved Seams

## Awaiting AI Deployment

The following are deliberately not implemented as final contracts:

- final Deployment Registry name/contract;
- AI-Deployment-owned package publish/register Tool;
- final Capability Package → Registry interface and downstream metadata;
- final target/configuration mechanics; and
- any Deployment-owned dependency/migration satisfaction or installed-state rules.

The package includes a bounded Project Handoff requesting these decisions. Review D remains on hold.

## Later platform work

- additional OpenAI/other-platform deployment routes require controlled empirical tests;
- platform security, local filesystem confinement, permissions/rights and authority require a
  separate architecture discussion; and
- exact Platform Profile schema remains evidence-led and intentionally unfrozen.

These seams do not block application of the implemented Core, Documentation Methodology, Working
Practices, Project Design, Build and Capabilities producer architecture.
