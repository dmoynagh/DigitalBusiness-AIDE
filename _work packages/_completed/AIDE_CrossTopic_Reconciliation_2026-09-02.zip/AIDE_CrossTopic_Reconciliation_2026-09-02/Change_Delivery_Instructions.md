
# Change Delivery Instructions — AIDE Cross-Topic Reconciliation — 2026-09-02

Apply this package as one substantive cross-Topic pass. Do not partially activate the new
Capabilities Tool identities while retaining the old current Design path.

## Core

**Replace/supersede:**

- `Core_Index_v6` → `Core_Index_v7`
- `Core_System_Design_v9` → `Core_System_Design_v10`
- `Core_System_Decisions_v7` → `Core_System_Decisions_v8`
- `Core_Binder_v3` → `Core_Binder_v4`

**Add:** `Core_Platform_Design_v1`, `Core_Platform_Decisions_v1`, `Core_Knowledge_v1`.

**Unchanged but reviewed:** current Core Index, Domain and Bootstrap child Design/Decisions/Standards.

## Documentation Methodology

**Replace/supersede:** Index v11→v12, Design v23→v24, Decisions v24→v25,
`AIDE_DocumentationMethodology_Standard` v26→v27, Guide v26→v27, Binder v7→v8.

No empty Knowledge document is required for Topics without Knowledge content.

## Working Practices

**Replace/supersede:** Index v7→v8, Brief v5→v6, Design v7→v8, Decisions v6→v7,
Standard document v6→v7 (`AIDE_WorkingPractices@v2`), Binder v4→v5.

## Project Design

**Replace/supersede:** Index v4→v5, Design v4→v5, Decisions v3→v4,
Standard v4→v5 (`AIDE_ProjectDesign@v5`), Binder v3→v4.

## Build

**Replace/supersede:** Index v5→v6, Design v5→v6, Decisions v5→v6,
`AIDE_Build_Standard` v5→v6, Binder v5→v6.

**Add:** `Build_PostBuild_Design_v1`, `AIDE_PublishBuildOutput_Tool_v1`.

**Unchanged but reviewed:** `Build_WorkPackage_Design_v3` and `AIDE_WorkPackage_Standard_v3`.

## Capabilities — parent/core

**Replace/supersede:** Index v19→v20, Brief v10→v11, Overview v16→v17, Design v11→v12,
Decisions v16→v17, Core Binder v5→v6.

**Add:** Capability Model Design/Decisions, `AIDE_Capability_Standard_v1`, Capability Build
Design/Decisions and `AIDE_CapabilityBuild_Standard_v1`.

## Capabilities — Standards/Tools

**Replace/supersede:** Standards Brief v2→v3, Standards Design v6→v7,
`AIDE_StandardsProduction_Standard` v2→v3, Tools Brief v3→v4, Tools Design v3→v4,
`AIDE_ToolsProduction_Standard` v1→v2, StandardsTools Binder v2→v3.

**Breaking Tool transition:**

- supersede `Capabilities_BuildCapability_Tool_Design_v2` with v3;
- supersede `AIDE_BuildCapability_Tool_v2` with v3;
- do not reinterpret v2 calls as v3;
- migrate v2 canonical-production calls to new `AIDE_UpdateCapabilityElements_Tool_v1`;
- use v3 only for Build request/readiness/WorkPackage orchestration.

**Add:** Standards and Tools Capability Definitions, Update Capability Elements Design/Tool,
Capability Builder Design/Tool.

**Unchanged but reviewed:** `AIDE_StandardsUsage_Standard_v2`.

## Capabilities — Runtime, Review and Messaging

**Add:** Tags, Scope, Dependencies, Migration, Review and Messaging Capability Definitions.

**Replace generated Binders only:** Runtime v1→v2, Review v3→v4, Messaging v3→v4.
All pre-existing child Design/Decisions/Standards/Tools in those three Binders are unchanged but
reviewed; the new Definitions baseline their current canonical outcomes without claiming new
semantic releases.

## Capabilities — Binder set and live state

**Add/replace generated set map:** `Capabilities_Binder_Set_Index_v1`.

**Replace/supersede live series:** WorkRegister v17→v18, WIP v17→v18, OpenItems v15→v16.

After all masters/Binders above are applied, remove the live locator for
`Capabilities_Working_CapabilityArchitectureRedesign`; move its current v2 to `_superseded` (or the
current equivalent) because its confirmed content is reconciled. Do not delete it as though it had
never existed.

## AI Deployment transfer

Send `ProjectHandoff_CrossTopicReconciliation_to_AIDeployment_2026-09-02` to the active AI
Deployment working context. It is transfer material, not a master. Obtain the requested return
handoff before final seam changes.

## Final verification

1. Confirm current indexes resolve the listed replacement masters and Binder boundaries.
2. Confirm no current invocation still uses Build Capability v2 without explicit migration.
3. Confirm Review D remains on hold in current WIP/WorkRegister.
4. Add the replacement Binders to the relevant project contexts and remove superseded Binder versions.
5. Move this applied ZIP to `Documentation/_changeDeliveryPackages/_completed/` under current Working Practices.
