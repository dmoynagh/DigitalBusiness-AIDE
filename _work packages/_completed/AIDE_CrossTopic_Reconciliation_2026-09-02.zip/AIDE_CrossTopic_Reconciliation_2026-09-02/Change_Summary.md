
# Change Summary — AIDE Cross-Topic Reconciliation — 2026-09-02

## Implemented

- Core Working Surface facts, multi-route support/evidence separation and Topic Knowledge.
- Documentation Methodology section-first hosting, Knowledge, Documentation-Topic Binder boundaries,
  Index-led navigation and preserved broad Decisions meaning.
- Working Practices capability-led context selection, source/governing-capability readiness, genuine
  transfer-only Handoff, mandatory completion reconciliation and preferred transactional corpus editing.
- Project Design flexible many-to-many contributions, direct authoritative authorship and semantic-section hosting.
- Build generic/domain-specialised boundary, explicit post-Build Tool model and ordinary publication Tool.
- Capability Definition/Element/production/release model; Current Migration; designer-owned Build Platforms.
- `Update Capability Elements`, breaking `Build Capability@v3` transition, `Capability Builder`,
  `AIDE_CapabilityBuild@v1` and complete externally/incremental internally Capability Packages.
- Required baseline Capability Definitions for all eight current peer areas.
- Capabilities live-state closeout and a genuine AI Deployment Project Handoff.

## Deliberately not implemented

The active AI Deployment-owned Registry/interface/tool/target mechanics, untested platform routes,
and platform security/filesystem-authority model remain open. Review D remains on hold.
