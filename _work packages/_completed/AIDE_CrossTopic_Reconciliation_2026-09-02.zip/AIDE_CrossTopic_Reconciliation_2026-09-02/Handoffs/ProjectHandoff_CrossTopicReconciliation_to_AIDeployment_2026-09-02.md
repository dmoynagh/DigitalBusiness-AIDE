
# Project Handoff — Capability producer seam to AI Deployment

> **Transfer material — 2026-09-02.** Reconcile against active AI Deployment WIP; do not treat this
> Handoff as an AI Deployment master.

## Why this Handoff exists

The producer-side Capability architecture is now confirmed/reconciled, while AI Deployment has
overlapping active WIP and owns the remaining destination interface.

## Confirmed producer position

- Capability Builder produces a complete Capability Package for each successful build.
- Internal incremental/cache/reuse implementation is allowed; selected platform output areas are
  complete externally.
- Package identity is a Build identity and does not increment Element/Capability semantic releases.
- Package carries Capability release/composition, Element releases, selected platforms, provenance,
  integrity, dependencies/migrations required downstream, Build evidence and post-Build request/result.
- Post-Build is an explicit Tool. Build owns ordinary publication; AI Deployment is expected to own
  Registry publication/registration.
- Capabilities ends after successful Package production/validation and the nominated post-Build handoff.
- AI Deployment must not reopen Capability Design or reconstruct semantic intent from payload shape.

## Return decisions required from AI Deployment

1. final Registry term and authoritative contract;
2. identity/contract of the AI-Deployment-owned publish/register Tool;
3. minimal Package → Registry interface and any downstream metadata genuinely required;
4. how dependencies/migrations are represented/consumed at that boundary;
5. package acceptance/replacement/retention semantics relevant to the producer; and
6. any producer facts required by final target/configuration/deployment mechanics.

## Constraints

Do not require false semantic release increments, reopen canonical Capability meaning, or reintroduce
the superseded fixed Deployment Manifest schema without demonstrated need. Return only concrete seam
changes that the producer must own.

## Expected return

A concise Project Handoff identifying confirmed AI Deployment decisions, exact producer changes (if
any), unresolved items and the current authoritative AI Deployment sources. Review D remains on hold
until that return is reconciled.
