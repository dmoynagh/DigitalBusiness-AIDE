# Working Practices — Change Delivery Instructions — 2026-08-31-3

> Transfer/application artefact. Not an authoritative corpus master.

## Purpose

Final pre-distribution Working Practices pass adding checkpoint-based batching of file/document
output so the upcoming Standards/Tools Bundle can carry the behaviour immediately.

No Working Practices capability has yet been distributed. This pass therefore finalises the
existing document issues in place without incrementing their document version numbers.

Formal capability identity remains:

```text
AIDE_WorkingPractices@v1
```

## Destination

Apply to:

```text
AIDE/Working Practices/
```

## Replace Current in place

Replace the current contents of these files with the package copies, retaining the same filenames
and document versions:

- `WorkingPractices_Index_v4.md`
- `WorkingPractices_Brief_v3.md`
- `WorkingPractices_Design_v4.md`
- `WorkingPractices_Decisions_v4.md`
- `AIDE_WorkingPractices_Standard_v3.md`

Do not move the replaced pre-distribution copies to `_superseded/`; this is finalisation of the
same undistributed document issues, not a later issued replacement.

## Generated Binder

Replace `WorkingPractices_Binder_v1.md` in place with the package copy.

Binder v1 remains appropriate because the first Binder has not yet been distributed. Its manifest
contains the corrected hashes for:

```text
Index v4
Brief v3
Design v4
Decisions v4
AIDE_WorkingPractices Standard document v3
```

Remove/re-add the corrected Binder in project context if an earlier Binder v1 is loaded.

## New operational rule

The Standard now makes checkpoint-based output the default:

- confirmed changes are accumulated/queued during active work;
- masters/Binders/Change Delivery Packages are normally emitted in one consolidated pass at the end
  of a significant work unit, work session or meaningful completion/integration checkpoint;
- explicit commands such as `output updates`, `update docs`, `run the pass`, or `build change
  package` trigger that pass;
- before autonomous package/file output, ask whether other pending work should be included;
- an explicit user output request already counts as confirmation;
- Project Handoff exchanges normally queue resulting document changes while a reply/further round
  is reasonably expected; and
- loss/significant-impact risk overrides batching: at-risk confirmed state is preserved promptly
  using the least-churn appropriate durable mechanism.

## Standards/Tools Bundle consequence

For the Bundle update immediately following this work, use:

```text
AIDE_WorkingPractices_Standard_v3.md
Identity: AIDE_WorkingPractices@v1
```

from this package/current master folder.

Do not use an earlier copy of Standard v3, because this pre-distribution issue now contains WP11
(checkpoint-based file/document output batching).

## Change Delivery Package handling

Stage this ZIP in:

```text
Documentation/_changeDeliveryPackages/
```

After the master, Binder and project-context replacements are complete, move it to:

```text
Documentation/_changeDeliveryPackages/_completed/
```

## Verification

After application:

1. the Current master set remains Index v4 / Brief v3 / Design v4 / Decisions v4 / Standard v3;
2. formal capability identity remains `AIDE_WorkingPractices@v1`;
3. Standard v3 contains WP11;
4. Design v4 contains the fuller batching workflow and loss-risk override;
5. Decisions v4 contains D27;
6. Binder v1 hashes match the five Current masters; and
7. the upcoming Standards/Tools Bundle uses this corrected Standard v3.
