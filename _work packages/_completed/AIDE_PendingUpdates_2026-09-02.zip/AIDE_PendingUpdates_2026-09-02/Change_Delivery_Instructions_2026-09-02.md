# AIDE Pending Updates — Change Delivery Instructions

> **Date:** 2026-09-02  
> **Scope:** Aggregate/domain-wide Migration and Update; document Contents/Summary/Overview model.

## Outcome

This package applies the confirmed pending changes as one coordinated pass:

- adds `AIDE_UpdateTool@v1` as the aggregate target-resolution/orchestration/reporting layer;
- keeps `AIDE_Migration`/`AIDE_MigrationTool` responsible for every artefact's transition and
  dependency-checkpoint truth;
- distinguishes aggregate Required Migration from aggregate Update;
- restricts mutation to the selected authoritative corpus and reports consuming/external-owner artefacts;
- rejects a synthetic universal `AIDE_Doc` dependency in favour of genuine declared dependencies,
  including `AIDE_DocumentationMethodology` for governed documents;
- defines conditional, dual-audience Contents and Summary sections;
- gives each DocType ownership of applicability, role, scope and depth;
- defines the Design Summary/Overview relationship; and
- uses Review Result as the Summary-equivalent surface for substantial durable Review documents.

## 1. Add new masters

Add these files to the Capabilities current master corpus:

- `Capabilities_Update_Tool_Design_v1.md`
- `AIDE_Update_Tool_v1.md`

## 2. Replace current masters

Copy the files from `masters/` into their owning current master folders. Supersede the listed
predecessor after each replacement is verified.

### Documentation Methodology

| Supersede | Replace with |
|---|---|
| `DocumentationMethodology_Index_v12.md` | `DocumentationMethodology_Index_v13.md` |
| `DocumentationMethodology_Design_v24.md` | `DocumentationMethodology_Design_v25.md` |
| `DocumentationMethodology_Decisions_v25.md` | `DocumentationMethodology_Decisions_v26.md` |
| `AIDE_DocumentationMethodology_Standard_v27.md` | `AIDE_DocumentationMethodology_Standard_v28.md` |
| `DocumentationMethodology_Guide_v27.md` | `DocumentationMethodology_Guide_v28.md` |

### Project Design

| Supersede | Replace with |
|---|---|
| `ProjectDesign_Index_v5.md` | `ProjectDesign_Index_v6.md` |
| `ProjectDesign_Design_v5.md` | `ProjectDesign_Design_v6.md` |
| `ProjectDesign_Decisions_v4.md` | `ProjectDesign_Decisions_v5.md` |
| `AIDE_ProjectDesign_Standard_v5.md` | `AIDE_ProjectDesign_Standard_v6.md` |

### Capabilities — parent

| Supersede | Replace with |
|---|---|
| `Capabilities_Index_v22.md` | `Capabilities_Index_v23.md` |
| `Capabilities_Decisions_v19.md` | `Capabilities_Decisions_v20.md` |

### Capabilities — Standards and Tools

| Supersede | Replace with |
|---|---|
| `Capabilities_Standards_Definition_v2.md` | `Capabilities_Standards_Definition_v3.md` |
| `Capabilities_Standards_Brief_v3.md` | `Capabilities_Standards_Brief_v4.md` |
| `Capabilities_Standards_Design_v7.md` | `Capabilities_Standards_Design_v8.md` |
| `AIDE_StandardsProduction_Standard_v3.md` | `AIDE_StandardsProduction_Standard_v4.md` |
| `Capabilities_Tools_Definition_v3.md` | `Capabilities_Tools_Definition_v4.md` |
| `Capabilities_Tools_Brief_v6.md` | `Capabilities_Tools_Brief_v7.md` |
| `Capabilities_Tools_Design_v6.md` | `Capabilities_Tools_Design_v7.md` |
| `AIDE_ToolsProduction_Standard_v2.md` | `AIDE_ToolsProduction_Standard_v3.md` |

### Capabilities — Migration/Update

| Supersede | Replace with |
|---|---|
| `Capabilities_Migration_Definition_v2.md` | `Capabilities_Migration_Definition_v3.md` |
| `Capabilities_Migration_Brief_v2.md` | `Capabilities_Migration_Brief_v3.md` |
| `Capabilities_Migration_Design_v2.md` | `Capabilities_Migration_Design_v3.md` |
| `AIDE_Migration_Standard_v2.md` | `AIDE_Migration_Standard_v3.md` |
| `Capabilities_Migration_Tool_Design_v2.md` | `Capabilities_Migration_Tool_Design_v3.md` |
| `AIDE_Migration_Tool_v2.md` | `AIDE_Migration_Tool_v3.md` |

### Capabilities — Review

| Supersede | Replace with |
|---|---|
| `Capabilities_Review_Definition_v2.md` | `Capabilities_Review_Definition_v3.md` |
| `Capabilities_Review_Design_v3.md` | `Capabilities_Review_Design_v4.md` |
| `Capabilities_Review_Decisions_v3.md` | `Capabilities_Review_Decisions_v4.md` |
| `AIDE_Review_Standard_v3.md` | `AIDE_Review_Standard_v4.md` |

## 3. Replace live Capabilities state

Copy from `live/`, then supersede the predecessors:

| Supersede | Replace with |
|---|---|
| `Capabilities_WIP_v18.md` | `Capabilities_WIP_v19.md` |
| `Capabilities_WorkRegister_v18.md` | `Capabilities_WorkRegister_v19.md` |

Retain `Capabilities_OpenItems_v16.md` unchanged.

## 4. Replace generated Binders

Copy the files from `binders/` into the appropriate current master folders and move the predecessors
to `_superseded` under the normal Working Practices convention.

| Supersede | Replace with |
|---|---|
| `DocumentationMethodology_Binder_v8.md` | `DocumentationMethodology_Binder_v9.md` |
| `ProjectDesign_Binder_v4.md` | `ProjectDesign_Binder_v5.md` |
| `Capabilities_Binder_Core_v8.md` | `Capabilities_Binder_Core_v9.md` |
| `Capabilities_Binder_StandardsTools_v5.md` | `Capabilities_Binder_StandardsTools_v6.md` |
| `Capabilities_Binder_Runtime_v3.md` | `Capabilities_Binder_Runtime_v4.md` |
| `Capabilities_Binder_Review_v5.md` | `Capabilities_Binder_Review_v6.md` |
| `Capabilities_Binder_Set_Index_v3.md` | `Capabilities_Binder_Set_Index_v4.md` |

Retain `Capabilities_Binder_Messaging_v5.md` unchanged.

## 5. Replace the temporary Standards/Tools Bundle

Replace `AIDE_Bundle_StandardsTools_v8.md` with `AIDE_Bundle_StandardsTools_v9.md` and move v8 to
`_superseded` under the normal bundle lifecycle convention.

## 6. Refresh Review D input

Before continuing the active fresh Review D programme, replace its Capabilities source baseline
with Binder Set Index v4 plus the current Binder partitions it requires. Do not count this
documentation implementation pass as a Review Round and do not revive the pre-AI-Deployment Review
D findings.

## Unchanged topics

No master changes are required in AI Deployment, Build, Core, Working Practices or Capabilities
Messaging from this pass. Their supplied Binders were used only to preserve current seams and
versions.
