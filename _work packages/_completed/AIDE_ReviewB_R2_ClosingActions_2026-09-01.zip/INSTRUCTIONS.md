# Review B R2 Closing Actions — Instructions

This package contains the Lead disposition, two Project Handoffs and the next Capabilities WIP
checkpoint. It is not itself an authoritative master-file Change Delivery Package.

## Files

- `ReviewB_R2_LeadDisposition_gpt-004.md`
- `ProjectHandoff_ReviewB_R2_to_DocumentationMethodology.md`
- `ProjectHandoff_ReviewB_R2_to_WorkingPractices.md`
- `Capabilities_WIP_v10.md`

## What to do

1. In the **existing Claude Review B chat**, paste
   `ReviewB_R2_LeadDisposition_gpt-004.md` if you want the Lead disposition preserved in the same
   Messaging thread. Claude does not need to perform another Review Round.

2. Replace current `Capabilities_WIP_v9` with `Capabilities_WIP_v10`.

3. In the **Documentation Methodology** project, paste
   `ProjectHandoff_ReviewB_R2_to_DocumentationMethodology.md`.
   Have that project reconcile it against its current Binder/current masters and return the normal
   Change Delivery Package.

4. In the **Working Practices** project, paste
   `ProjectHandoff_ReviewB_R2_to_WorkingPractices.md`.
   Have that project reconcile it against its current Binder/current masters and return the normal
   Change Delivery Package.

5. Apply both returned packages and regenerate/replace the current Binders.

6. Bring the two resulting current Binders back to the Capabilities Review B Lead chat.

7. The Lead will verify only the accepted closing corrections, then:
   - mark Review B Complete at High;
   - create the durable Review B record;
   - update WR17;
   - remove the completed Review B thread from WIP;
   - prepare Review C.

## Do not do

- Do not run Review B Round 3.
- Do not start Review C before the closing corrections are applied and Review B is formally closed.
- Do not sweep footer dependency/reference versions as part of these closing actions.
