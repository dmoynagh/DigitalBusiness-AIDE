# Core — Change Delivery Instructions — 2026-08-31

> **Transfer/application artefact — not an authoritative master document.**
>
> This package applies the completed blank-sheet AIDE Domain design to the Core corpus and delivers
> the first canonical `AIDE_Domain@v1` Standard. Apply the master changes first; treat the Binder as
> generated output and replace/regenerate it only after the masters are in their final state.

## Application manifest

| File | Action | Destination | Replaces / supersedes | Context / action |
|---|---|---|---|---|
| `Core_Domain_Design_v1.md` | **Add / ownership transfer** | `AIDE/Core/` | None | Becomes the authoritative Core Domain Design. Include through the regenerated Core Binder; do not retain a second authoritative Capabilities-owned copy. |
| `Core_Domain_Decisions_v1.md` | **Add / ownership transfer** | `AIDE/Core/` | None | Becomes the authoritative Core Domain Decisions history. Include through the regenerated Core Binder. |
| `Core_Index_v2.md` | **Replace Current** | `AIDE/Core/` | `Core_Index_v1.md` → `AIDE/Core/superseded/` | Registers Domain, its Design/Decisions, and `AIDE_Domain_Standard_v1`. |
| `Core_System_Design_v5.md` | **Replace Current** | `AIDE/Core/` | `Core_System_Design_v4.md` → `AIDE/Core/superseded/` | Adds Domain under Core without duplicating detailed Domain semantics. |
| `Core_System_Decisions_v4.md` | **Replace Current** | `AIDE/Core/` | `Core_System_Decisions_v3.md` → `AIDE/Core/superseded/` | Clarifies D5 as development/product Domain workflow ownership and records Core ownership of the shared Domain contract. |
| `AIDE_Domain_Standard_v1.md` | **Add** | `AIDE/Core/` | None | New canonical deployable Standard, identity `AIDE_Domain@v1`. No Domain Tool is created. |
| `Core_Binder.md` | **Replace generated Binder** | Core generated-Binder location / Core project context | Existing `Core_Binder.md` | Apply all masters first, then regenerate/replace the Binder. Do not edit the Binder directly. |
| `Core_ChangeDelivery_Instructions_2026-08-31.md` | **Transfer only** | Delivery package only | None | Do not add to the Core master corpus or normal Core project context. |

## Apply to the Core master folder

Use this order so the generated Binder never becomes the source of truth.

1. Add `Core_Domain_Design_v1.md` to `AIDE/Core/`.
2. Add `Core_Domain_Decisions_v1.md` to `AIDE/Core/`.
3. Move the currently issued `Core_Index_v1.md` to `AIDE/Core/superseded/`, then place
   `Core_Index_v2.md` in `AIDE/Core/`.
4. Move `Core_System_Design_v4.md` to `AIDE/Core/superseded/`, then place
   `Core_System_Design_v5.md` in `AIDE/Core/`.
5. Move `Core_System_Decisions_v3.md` to `AIDE/Core/superseded/`, then place
   `Core_System_Decisions_v4.md` in `AIDE/Core/`.
6. Add `AIDE_Domain_Standard_v1.md` to `AIDE/Core/` as the canonical Domain Standard.
7. Regenerate the Core Binder from the resulting current masters. The packaged `Core_Binder.md`
   is the regenerated output from this exact final set and may replace the existing generated
   Binder after the masters have been applied. Do not edit either old or new Binder content by hand.

The expected current Core source set represented by the Binder is:

```text
Core_Index_v2.md
Core_System_Design_v5.md
Core_System_Decisions_v4.md
Core_Domain_Design_v1.md
Core_Domain_Decisions_v1.md
AIDE_Domain_Standard_v1.md
```

Expected Binder manifest hash prefixes:

```text
Core_Index_v2.md                 c516e06379c3
Core_System_Design_v5.md         ce52e0a6c298
Core_System_Decisions_v4.md      2c426f4ec869
Core_Domain_Design_v1.md         a2a4b700400b
Core_Domain_Decisions_v1.md      f4590f0937dc
AIDE_Domain_Standard_v1.md       271e2c561c96
```

## Ownership and transfer treatment

`Core_Domain_Design_v1.md` and `Core_Domain_Decisions_v1.md` were produced during the Capabilities
workstream but the confirmed architecture assigns them to **Core**. Their content is intentionally
unchanged in this delivery; the change is their authoritative ownership/placement and registration
inside the Core corpus.

If temporary copies were placed in a Capabilities master folder solely for transfer, move/remove
those staging copies after the Core copies are established rather than maintaining two authoritative
masters. If they existed only in the Capabilities conversation/project context, there is no
Capabilities master-file move to perform.

`Core_Domain_Handoff_2026-08-31.md` is **transfer-only source material**. It is not included as a
Core master and must not be registered in `Core_Index`. Once this delivery is applied, remove it
from active Core project context if it was temporarily added for the handoff. Retention of the
handoff note outside the authoritative corpus is optional according to normal transfer-history
practice.

Earlier 27–28 August 2026 `AIDE_Domain_*` design/decision material has no compatibility, migration,
or architectural standing for this implementation. Do not import it into Core and do not use it to
modify `AIDE_Domain@v1`. If such files are present in active Core context, remove them from active
context; historical source copies may remain in their original historical location.

## Core project-context changes

The normal Binder-based Core context should be refreshed after the master-folder changes:

- remove/replace the previous `Core_Binder.md` from the Core GPT/Claude project context;
- add the regenerated `Core_Binder.md` from this delivery;
- do not separately add the individual Core masters when the Binder is the normal context
  representation, unless the project deliberately uses both;
- remove the temporary `Core_Domain_Handoff_2026-08-31.md` from active Core context; and
- remove any earlier obsolete `AIDE_Domain_*` material from active Core context if present.

These are **application actions still to be performed**. Generation of this package does not prove
that any project context has been changed.

## Cross-project and Bundle consequences

### Capabilities

No Capabilities Design/Decisions/Index master change is required by this delivery. The existing
Build Capability and Standards Production contracts were used as production rules; they are not
modified here.

If the Domain Design/Decisions are still present in the Capabilities project context only as
handoff material, remove them after Core context has been refreshed so Core is the clear owning
context.

### `bundles`

`AIDE_Bundle_StandardsTools_v3.md` is intentionally **unchanged and not included** in this package.
It predates `AIDE_Domain@v1` and therefore becomes incomplete as the common canonical
Standards/Tools consumption bundle once this Core change is adopted.

Run the normal Bundle/package production process after this delivery is applied. Do **not** edit
v3 in place. Under the current issued-output version rule, the next changed common
Standards/Tools Bundle should be issued as the next version (normally
`AIDE_Bundle_StandardsTools_v4.md`) and include `AIDE_Domain_Standard_v1.md` alongside the existing
canonical Standards/Tools.

Any generated Binder/Bundle is a consumption artefact, not the source master.

### AI Deployment / deployment sets

`AIDE_Domain@v1` is a deployable canonical Standard. This package **does not deploy it**.

After the updated common bundle/package is produced, use the normal AI Deployment path to
reconcile the deployment set(s)/targets that consume the common AIDE Standards/Tools material.
Do not infer a new Domain-specific deployment mechanism or Tool. Verification should establish
that the updated target representation actually exposes the new Standard according to the normal
deployment contract.

No AI Deployment architecture/master change is required merely because this new Standard exists.

### Documentation Methodology, Project Design and Build

No source/master change is required in these projects for this integration. They may consume
Domain context through `AIDE_Domain@v1`; Domain does not transfer their semantics into Core.

## Supersession / archive summary

Move these issued Core masters to `AIDE/Core/superseded/`:

```text
Core_Index_v1.md
Core_System_Design_v4.md
Core_System_Decisions_v3.md
```

Do not move the previous generated `Core_Binder.md` to `superseded/` as though it were an
authoritative master. Replace/regenerate it according to the Binder workflow unless a separate
local retention policy says otherwise.

No archive/terminal-lifecycle action is required for the new Domain documents or Standard.

## Intentionally unchanged / deliberately absent

The change set is intentionally limited:

- `Core_Domain_Design_v1.md` — content unchanged; ownership/registration changes.
- `Core_Domain_Decisions_v1.md` — content unchanged; ownership/registration changes.
- No Domain Tool is created.
- No child-Domain inheritance or generic child-Domain semantics are introduced.
- No generic settings precedence/inheritance mechanism is introduced.
- Repository/worktree remains a discovery boundary, not an implicit Domain type.
- Development/product Domains remain outside the AIDE system tree and continue to consume AIDE.
- `AIDE_Bundle_StandardsTools_v3.md` is not edited in this package; bundle regeneration is a
  downstream action.
- No deployment is claimed or performed by this package.

## Unconfirmed actions

The files in this package are generated/final outputs. The following state changes still require
application by you or the appropriate project/process:

- copying/placing the new Core masters;
- moving the three replaced Core versions to `superseded/`;
- removing any temporary Capabilities/Core handoff-context copies;
- replacing/regenerating the Core Binder in its normal location;
- refreshing GPT/Claude project context;
- producing the next common Standards/Tools Bundle; and
- reconciling that updated deployable representation through AI Deployment.

Do not treat presence of a file in this ZIP as evidence that any of those actions have already
occurred.
