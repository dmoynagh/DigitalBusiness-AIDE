# Documentation Methodology — Change Delivery Instructions

> **Transfer/application artefact — not a corpus master.**
> Package: `DocumentationMethodology_ChangeDelivery_2026-08-31.zip`
> Prepared: 2026-08-31

## Purpose and review conclusion

This package corrects the Documentation Methodology Decisions-recording contract after review of the current v18 Design, Guide, Standard, Decisions history, and the canonical Standard-production rules.

The review concluded that the established Decisions concept remains sound and proportionate, but `AIDE_DocumentationMethodology@v18` does not carry enough of it to reproduce the intended behaviour reliably when the Standard is the only runtime representation. The defect is upstream as well as downstream: the current confirmed Design under-specifies the Decisions contract, so Standards Production cannot legitimately recover the missing semantics from the Guide or Decisions history during Standard generation.

The correction therefore issues Documentation Methodology **v19**, makes the full Decisions behaviour authoritative in Design, reproduces it compactly in the canonical Standard, aligns the Guide, and records the reasoning additively in Decisions. v19 has migration posture **None**: existing v18-conformant documents and historical Decisions entries do not require rewriting merely because of this correction.

## Application manifest

| File | Action | Destination | Replaces / supersedes | Context / action |
|---|---|---|---|---|
| `DocumentationMethodology_Index_v4.md` | Replace Current | `AIDE/Document Methodology/` | `DocumentationMethodology_Index_v3.md` | Install as current Index; then move v3 to `superseded/`. |
| `DocumentationMethodology_Design_v16.md` | Replace Current | `AIDE/Document Methodology/` | `DocumentationMethodology_Design_v15.md` | Install as current confirmed Design; then move v15 to `superseded/`. |
| `DocumentationMethodology_Decisions_v17.md` | Replace Current | `AIDE/Document Methodology/` | `DocumentationMethodology_Decisions_v16.md` | Install as current Decisions; then move v16 to `superseded/`. Do not rewrite older historical entries. |
| `AIDE_DocumentationMethodology_Standard_v19.md` | Replace Current | `AIDE/Document Methodology/` | `AIDE_DocumentationMethodology_Standard_v18.md` | Install as current canonical runtime Standard; then move v18 to `superseded/`. This is the deployable source changed by this work. |
| `DocumentationMethodology_Guide_v19.md` | Replace Current | `AIDE/Document Methodology/` | `DocumentationMethodology_Guide_v18.md` | Install as current human/explanatory Guide; then move v18 to `superseded/`. |
| `DocumentationMethodology_Binder.md` | Replace generated Binder | Generated Binder location for `AIDE/Document Methodology/` | current `DocumentationMethodology_Binder.md` | Generated from the five v19/current masters above. Do not edit directly. Replace the Binder used in the Documentation Methodology GPT/Claude project context. |
| `AIDE_Bundle_StandardsTools_v4.md` | Replace generated Bundle | Existing common AIDE Standards/Tools Bundle generated-output location (the location currently holding `AIDE_Bundle_StandardsTools_v3.md`) | `AIDE_Bundle_StandardsTools_v3.md` | Replace v3 wherever the common bundle is stored/loaded. The supplied corpus does not establish a more specific physical folder path, so do not invent one. v4 changes only the Documentation Methodology member; all other members are retained unchanged. |
| `DocumentationMethodology_ChangeDelivery_Instructions_2026-08-31.md` | Transfer only | Keep with this delivery package only | none | Do not add to the Documentation Methodology master corpus or project context. |

## Master-file actions

Apply the five master replacements in `AIDE/Document Methodology/` first. After each new file is safely present as current, move the superseded issued predecessor to that project's `superseded/` folder:

- `DocumentationMethodology_Index_v3.md`
- `DocumentationMethodology_Design_v15.md`
- `DocumentationMethodology_Decisions_v16.md`
- `AIDE_DocumentationMethodology_Standard_v18.md`
- `DocumentationMethodology_Guide_v18.md`

Do **not** archive these files: they have been superseded by later issued versions rather than reaching a terminal lifecycle event. Do not delete or rewrite historical Decisions material.

## Binder and project-context changes

`DocumentationMethodology_Binder.md` in this package is already regenerated from the corrected current masters. It is a generated consumption artefact, not a master.

After the master replacements are applied:

1. replace the existing Documentation Methodology Binder with the supplied `DocumentationMethodology_Binder.md` in the project's generated Binder location;
2. in the Documentation Methodology GPT/Claude project context, remove the old Binder and add the supplied regenerated Binder;
3. if the project context also carries individual current masters, replace the old v18/v15/v16/v3 files with the new current versions rather than keeping both current and superseded versions in active context.

No direct edit of the old Binder is required or permitted.

## Common Bundle and deployment consequences

`AIDE_Bundle_StandardsTools_v4.md` is regenerated from the supplied current `AIDE_Bundle_StandardsTools_v3.md` plus `AIDE_DocumentationMethodology_Standard_v19.md`. The only bundle member changed is Documentation Methodology; the other 16 Standards/Tools members are carried forward byte-for-byte.

Apply the bundle change as follows. The supplied corpus establishes the logical common Bundle but not a more specific physical filesystem path; use the existing v3 location rather than creating a new location.

1. replace `AIDE_Bundle_StandardsTools_v3.md` with `AIDE_Bundle_StandardsTools_v4.md` in the common generated Bundle location;
2. replace v3 with v4 in every GPT/Claude/AIDE project context that consumes the common Standards/Tools Bundle;
3. route v4 through the normal AI Deployment process for any deployment set/target that distributes this common bundle or its Documentation Methodology Standard contribution;
4. verify the deployed/runtime representation exposes `AIDE_DocumentationMethodology@v19` before treating deployment as complete.

This package **does not claim deployment, copying, context replacement, or target verification has occurred**. Those remain application/deployment actions.

## Cross-project consequences

### Capabilities and other AIDE design projects

No Capabilities source/master file is changed by this package.

The corrected rule applies prospectively: where a child topic has an independently expanded Design, substantive future reasoning should normally be recorded at the same child Decisions scope (or in a Decisions section for a condensed topic). Existing parent-level historical Decisions are not to be relocated or rewritten merely to conform retrospectively. New child Decisions may cite older parent decisions where useful.

Any AIDE project that uses the common Standards/Tools Bundle should replace v3 with v4 in active project context. This is a runtime/context consequence, not a source-master change to those projects.

### Standards Production

`AIDE_StandardsProduction@v1` is intentionally unchanged. Its existing rule already requires canonical Standards to contain complete confirmed meaning from authoritative Design and forbids repairing Design gaps by invention. This review applies that rule; it does not change it.

## What v19 changes

The v19 correction makes the following behaviour explicit and canonical:

- Decisions records synthesized reasoning/history for a future Design reader, not just the final outcome.
- As applicable and proportionate, preserve the trigger/requirement, problem, genuine alternatives, key distinctions/reasoning, decision, and important consequences/trade-offs.
- A Decisions event is owed for a change to the confirmed substantive Design position, a requirement established or materially revised, or a rejected alternative a future reader could reasonably re-derive.
- Editorial, formatting, metadata, migration, mechanical maintenance, and application of an already-recorded decision do not by themselves create a new Decisions event.
- Non-trivial rejected alternatives remain visible; proportionality controls depth. Genuinely trivial alternatives may be omitted.
- Preserve enough reasoning to reconstruct why the decision was reached; do not preserve discussion merely because it occurred.
- Substantive Design changes and their Decisions record are produced in the same pass while the reasoning is available.
- Existing Decisions history remains additive and is not retroactively rewritten.
- Independently expanded child Design normally keeps substantive Decisions reasoning at the same scope.
- Decisions does not feed downstream outcomes. If reasoning is needed for correct use or implementation, it must first be represented in current Design/authoritative downstream input.
- Split Decisions history for retrieval quality, preferably by closure/state, not simply because it is long.

This preserves the useful `Decision + Reason` form for genuinely simple decisions, but it is no longer an implied sufficient template for work that actually involved meaningful alternatives, evolution, distinctions, or accepted trade-offs.

## Migration / release treatment

- `AIDE_DocumentationMethodology@v18` remains the issued predecessor and its v17→v18 `OnUpdate` transition remains retained history.
- `AIDE_DocumentationMethodology@v19` is the new current release.
- v19 transition posture is `None` because the correction changes the operating contract for future documentation work but does not require structural or textual migration of existing v18-conformant artefacts.
- On a later qualifying save, normal Dependencies/Migration processing may advance a v18 checkpoint through the v19 `None` transition after any earlier applicable work is satisfied.
- Do not mass-rewrite documents or Decisions history solely to make them appear v19.

## Intentionally unchanged related items

- No dedicated Documentation Methodology Tool is introduced.
- `AIDE_StandardsProduction@v1`, `AIDE_StandardsUsage@v1`, `AIDE_Migration@v1`, and the other common Standards/Tools are unchanged.
- Existing v18-conformant project documents are not rewritten by this package.
- Existing project Decisions history is not backfilled, moved, or rewritten.
- The Capabilities corpus is not restructured by this package; same-granularity correction is prospective.
- The v18 legacy `Methodology: v17` bridge remains intact as part of retained transition history.

## Unconfirmed actions checklist

The package generation is complete. The following are **not** claimed as completed until you perform or verify them:

- copying the five new masters into `AIDE/Document Methodology/`;
- moving the five superseded predecessors into `superseded/`;
- replacing the generated Binder in storage/project context;
- replacing common Bundle v3 with v4 in storage/project contexts;
- deploying/reconciling v19 to runtime targets;
- verifying runtime availability of `AIDE_DocumentationMethodology@v19`.

## Package contents

- `DocumentationMethodology_Index_v4.md`
- `DocumentationMethodology_Design_v16.md`
- `DocumentationMethodology_Decisions_v17.md`
- `AIDE_DocumentationMethodology_Standard_v19.md`
- `DocumentationMethodology_Guide_v19.md`
- `DocumentationMethodology_Binder.md`
- `AIDE_Bundle_StandardsTools_v4.md`
- `DocumentationMethodology_ChangeDelivery_Instructions_2026-08-31.md`
