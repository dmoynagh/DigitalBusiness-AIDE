# Build — Review B R1 Change Delivery Instructions — 2026-09-01

## Purpose

Apply the accepted Review B R1 WorkPackage mapping clarification with the smallest coherent Build/WorkPackage release. The change makes deliberately split WorkRegister obligations deterministic enough to map and reconcile without introducing sub-obligation identifiers or moving WorkRegister authority into Build.

## Replace current masters in `AIDE/Build/`

Add these files to the current Build master folder and replace the corresponding current masters:

- `Build_Index_v5.md` — replaces `Build_Index_v4.md`.
- `Build_Design_v5.md` — replaces `Build_Design_v4.md`.
- `Build_Decisions_v5.md` — replaces `Build_Decisions_v4.md`.
- `Build_WorkPackage_Design_v3.md` — replaces `Build_WorkPackage_Design_v2.md`.
- `AIDE_Build_Standard_v5.md` — replaces `AIDE_Build_Standard_v4.md`.
- `AIDE_WorkPackage_Standard_v3.md` — replaces `AIDE_WorkPackage_Standard_v2.md`.

The replaced masters become **Superseded** and should be physically handled under the current `_superseded/` convention.

## Replace generated Binder

- Add `Build_Binder_v5.md` as the current generated Build Binder.
- `Build_Binder_v4.md` becomes Superseded and should move to `_superseded/` under the current repository convention.
- Replace the Build project-context Binder with `Build_Binder_v5.md` where the Binder is loaded as project context.

## What changed

When one WorkRegister obligation is deliberately split across multiple WorkPackages:

1. the source obligation's required changes must be independently identifiable, normally as an owner-supplied enumerated/bulleted set;
2. each WorkPackage `Covers` must identify the exact required changes/portion it claims;
3. equivalent clear prose is valid when unambiguous; and
4. structured sub-obligation identifiers are not introduced unless later evidence establishes a real need.

The existing many-to-many mapping, self-contained WorkPackage contract, per-mapped-obligation Outcome result/evidence/remaining-work return, and owner-side WorkRegister reconciliation are unchanged.

## Downstream generated artefact

`AIDE_Bundle_StandardsTools_v5.md` currently contains `AIDE_Build@v4` and `AIDE_WorkPackage@v2`, so it becomes stale as a generated consumption artefact after this package is applied. Do **not** edit that Bundle directly. Regenerate/replace it through its normal owning Bundle/Build process when the common runtime Bundle is next refreshed.

## Intentionally unchanged

- No Project Design/WorkRegister master is changed by this package.
- No detailed Outcome evidence is moved into WorkRegister.
- Build still cannot close the source WorkRegister.
- WorkRegister references still cannot substitute for WorkPackage Objective/Scope/Inputs/Outputs/Acceptance.
- Outcome remains an independent live return record.

## Resulting current versions

- Build capability: `AIDE_Build@v5`
- WorkPackage capability: `AIDE_WorkPackage@v3`
- Build Binder: `Build_Binder_v5.md`

Migration posture for the new releases is `None`; historical WorkPackages/Outcomes do not require rewriting.
