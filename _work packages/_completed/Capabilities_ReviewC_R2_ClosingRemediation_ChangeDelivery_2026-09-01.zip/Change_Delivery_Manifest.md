# Change Delivery Manifest

Review C R2 closing remediation — 2026-09-01

- `AIDE_Messaging_Tool_v2.md` — sha256 `4a137b4aeb28e8d22729457d5e9b7f79e786613152ca0b0b283da97b47c435af`
- `AIDE_StandardsUsage_Standard_v2.md` — sha256 `4573304f05cf645bfa4db2d8063696242a51b951cf4d1dd99d7a8e6b63553e0a`
- `Capabilities_Binder_Core_v4.md` — sha256 `cbe056f787949866fd2820e43c66c83647f316a790088acbeb9eeb7b112aeb60`
- `Capabilities_Binder_Messaging_v3.md` — sha256 `7e6769902db7207a7fefdeb24b662f4edb516d07b465d4a177559212e6d244ee`
- `Capabilities_Binder_StandardsTools_v2.md` — sha256 `541d1d89efcf059a9e87a2e3caaeedb68328649d869bca78543f510e7694b7c7`
- `Capabilities_Brief_v10.md` — sha256 `f962bc921142038463b144a887c4731cd4ddd8feba2ae22857947ae3b9a7b06b`
- `Capabilities_Design_v11.md` — sha256 `3f5e366f22eaaf7b5f7a9c7217b16e09a8147d766b446a8f42f8547afad79da2`
- `Capabilities_Index_v18.md` — sha256 `2f5fc2b687eb2869a16f8fed164b3b8219423d5ec53642f0602baf97af1a778d`
- `Capabilities_Messaging_Brief_v3.md` — sha256 `b4d39658f6d2e93789fc96f3526719bbe2109d886b12ba728b01e68652f270e4`
- `Capabilities_Messaging_Design_v3.md` — sha256 `202e5bfb9dbc7433c7eab7af7a43bf39f72d6d2cac5cd10ca1d33a778d502af4`
- `Capabilities_Messaging_Tool_Design_v2.md` — sha256 `45885bb7b4d47b03791d7bab4875a4ba1bebaa19846cb272768d1fa795161db7`
- `Capabilities_Overview_v16.md` — sha256 `09c728f840a2b76b74f98ce4d181de371192e0addd78a2d48d85f44028f9d6f2`
- `Capabilities_Standards_Design_v6.md` — sha256 `3bcf1be6e3dff697b89296ed6f9c43f7b7b8def95d5aea925945041c08c5b5d8`
- `Capabilities_WIP_v14.md` — sha256 `6650a0c7bb24bde7d7b86b4db72bf5152f5a12dca2cafc02f768d5a3cd432fbe`
- `Change_Delivery_Instructions.md` — sha256 `fa383e11954528ef05a370cddff9639334f125d9ef949e1e2853b4131cb0e429`
- `ReviewC_R2_LeadDisposition_gpt-004.md` — sha256 `d9166fccdcd90e123710502bdbbf2bd1c072d52195216e221cd4704c4ec68570`
- `ReviewC_R3_Claude_Request_gpt-005.md` — sha256 `37c2b39c58ca99aecf09cf4f1e27dd582cddce304929036cbe85b2ebcec2bc2b`
