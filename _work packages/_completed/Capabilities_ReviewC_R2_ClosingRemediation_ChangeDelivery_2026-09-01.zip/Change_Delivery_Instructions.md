# Review C R2 Closing Remediation — Change Delivery Instructions

## Purpose

Apply the four accepted Review C R2 Findings as one bounded closing pass. This package does not redesign Capabilities and does not begin Review D.

## Replace current masters

Move the replaced current files to `_superseded` under the normal project convention, then install these replacements in the Capabilities master folder:

- `Capabilities_Index_v17.md` → `Capabilities_Index_v18.md`
- `Capabilities_Brief_v9.md` → `Capabilities_Brief_v10.md`
- `Capabilities_Overview_v15.md` → `Capabilities_Overview_v16.md`
- `Capabilities_Design_v10.md` → `Capabilities_Design_v11.md`
- `Capabilities_Standards_Design_v5.md` → `Capabilities_Standards_Design_v6.md`
- `AIDE_StandardsUsage_Standard_v1.md` → `AIDE_StandardsUsage_Standard_v2.md`
- `Capabilities_Messaging_Brief_v2.md` → `Capabilities_Messaging_Brief_v3.md`
- `Capabilities_Messaging_Design_v2.md` → `Capabilities_Messaging_Design_v3.md`
- `Capabilities_Messaging_Tool_Design_v1.md` → `Capabilities_Messaging_Tool_Design_v2.md`
- `AIDE_Messaging_Tool_v1.md` → `AIDE_Messaging_Tool_v2.md`

No new standalone master is added in this closing pass.

## Replace generated Binders

- `Capabilities_Binder_Core_v3.md` → `Capabilities_Binder_Core_v4.md`
- `Capabilities_Binder_StandardsTools_v1.md` → `Capabilities_Binder_StandardsTools_v2.md`
- `Capabilities_Binder_Messaging_v2.md` → `Capabilities_Binder_Messaging_v3.md`

Do not replace/regenerate:

- `Capabilities_Binder_Runtime_v1.md`
- `Capabilities_Binder_Review_v3.md`

They are unchanged from the state Claude verified in R2.

## WIP

After the replacements are applied, replace:

- `Capabilities_WIP_v13.md` → `Capabilities_WIP_v14.md`

WIP v14 records R2 disposition/remediation and R3 as prepared, not yet relayed.

## Review messages

1. In the existing Claude Review C chat, relay `ReviewC_R2_LeadDisposition_gpt-004.md`.
2. Then give Claude only these three files:
   - `Capabilities_Binder_Core_v4.md`
   - `Capabilities_Binder_StandardsTools_v2.md`
   - `Capabilities_Binder_Messaging_v3.md`
3. Relay `ReviewC_R3_Claude_Request_gpt-005.md`.
4. Return Claude's complete R3 AI-MESSAGE response to GPT.

## Deliberately unchanged

Do not change WorkRegister/OpenItems yet. Review C is not complete until R3 returns.
Do not update the temporary `AIDE_Bundle_StandardsTools` during this closing pass; it remains generated/non-authoritative and should not churn before Review C closure.
Do not begin Review D.
