# Capabilities Binder StandardsTools

> **Generated Binder — do not edit directly.** Edit the individual master documents and regenerate the Binder.
> **Binder Version 4** (2026-09-02). Reconciles capability production/build Tools and Definitions to the current Deployment Registry seam.

This Binder is a current-context consumption artefact; authoritative masters remain individual files.

## Binder manifest

- `Capabilities_Standards_Definition_v2.md` — sha256 `72ef8630e12a`
- `Capabilities_Standards_Brief_v3.md` — sha256 `b4859720a8b1`
- `Capabilities_Standards_Design_v7.md` — sha256 `783d3e1d43d0`
- `AIDE_StandardsProduction_Standard_v3.md` — sha256 `a0cc11ee62bc`
- `AIDE_StandardsUsage_Standard_v2.md` — sha256 `4573304f05cf`
- `Capabilities_Tools_Definition_v2.md` — sha256 `0c316ff3517f`
- `Capabilities_Tools_Brief_v5.md` — sha256 `93ec38d0d788`
- `Capabilities_Tools_Design_v5.md` — sha256 `629eeaea239a`
- `AIDE_ToolsProduction_Standard_v2.md` — sha256 `541c56f4d3b2`
- `Capabilities_UpdateCapabilityElements_Tool_Design_v1.md` — sha256 `1ee00be549f5`
- `AIDE_UpdateCapabilityElements_Tool_v1.md` — sha256 `fd2e2edcc350`
- `Capabilities_BuildCapability_Tool_Design_v4.md` — sha256 `4005cff9a729`
- `AIDE_BuildCapability_Tool_v4.md` — sha256 `8cddc9200922`
- `Capabilities_CapabilityBuilder_Tool_Design_v2.md` — sha256 `2023666db30d`
- `AIDE_CapabilityBuilder_Tool_v2.md` — sha256 `5d75f1241d7c`

---

<!-- BEGIN SOURCE: Capabilities_Standards_Definition_v2.md -->
# Standards — Capability Definition

> **Version 2** (2026-09-02). Reconciles post-Build Registry intent to the current AI Deployment Registry contract without changing Element semantics.

## Identity, purpose and boundary

**Capability:** `Standards@v1`

Defines canonical Standard production and runtime usage contracts.

This Definition controls Capability-level composition and production state. Detailed Element
semantics remain in the canonical outcomes identified below.

## Capability Elements

| Element | Type | Canonical outcome | Element release |
|---|---|---|---:|
| `Standards.Production` | Standard | `AIDE_StandardsProduction@v3` | v1 |
| `Standards.Usage` | Standard | `AIDE_StandardsUsage@v2` | v1 |

## Capability Release History

```text
Standards@v1
  Standards.Production@v1 -> AIDE_StandardsProduction@v3
  Standards.Usage@v1 -> AIDE_StandardsUsage@v2
```

This baseline adopts already-current canonical outcomes into the new Capability/Element release
model; it does not pretend those outcomes were newly changed on 2026-09-02.

## Element Release History

- `Standards.Production@v1` — baseline adoption of `AIDE_StandardsProduction@v3`; no new semantic change asserted.
- `Standards.Usage@v1` — baseline adoption of `AIDE_StandardsUsage@v2`; no new semantic change asserted.

## Element Production

| Element | Production inputs | LastEvaluated |
|---|---|---|
| `Standards.Production` | Current sources/contracts identified by Definition references | 2026-09-02 baseline |
| `Standards.Usage` | Current sources/contracts identified by Definition references | 2026-09-02 baseline |

Update the mutable checkpoint when sources/contracts are reassessed. An input-version change does
not by itself increment an Element release; immutable release-source snapshots stay in history when
later releases are produced.

## Current Migration

None. Authoritative existing outcome migrations remain under `AIDE_Migration`. A future Element
change carries Current Migration until release confirmation.

## Platform Definition and Build Platforms

The Capability is platform-neutral. Current generic Working Surface evidence must be resolved before
a Capability Build request. Newly supported platforms are surfaced and retain designer selection
`Build: null` until explicitly decided; unsupported plus `Build:true` is blocking.

## Post-Build intent

No Registry publication is inferred automatically. A Capability Build request may nominate `AIDE_DeploymentRegistryTool@v1` action `Register` with the configured Registry and optional open Release Batch, or nominate another applicable post-Build Tool/explicit none. Actual post-Build result remains external to the immutable validated package and is reported through Registry state/WorkPackage Outcome. This Definition update does not by itself change the Capability or Element semantic release.

---
Dependencies: !AIDE_DocumentationMethodology@v27, AIDE_Capability@v1, AIDE_Dependencies@v3, AIDE_Migration@v2
References: Capabilities_Standards_Design_v7, AIDE_StandardsProduction@v3, AIDE_StandardsUsage@v2, AIDE_DeploymentRegistryTool@v1
<!-- END SOURCE: Capabilities_Standards_Definition_v2.md -->

---

<!-- BEGIN SOURCE: Capabilities_Standards_Brief_v3.md -->
# Capabilities Standards — Brief

> **Version 3** (2026-09-02). Adds the Standards Capability Definition and Element-release production boundary.
>
> Created: 2026-08-27 | Last modified: 2026-09-02

---

## Purpose

Standards owns the reusable model for what an AI-facing Standard is, how its rules are structured
and weighted, how a canonical Standard is produced from confirmed design, and how sessions operate
under applicable Standards.

Individual domains own the substance of the Standards they produce.

## Outputs

Standards defines and ultimately publishes two generic outcomes:

- **Standards Production Standard** — authoring/structure/weight/canonical-production rules.
- **Standards Usage Standard** — discovery, interpretation, conflict/deviation, and operation under
  applicable Standards.

A domain may also produce an optional human Guide from the same design where useful.

## Required relationships

A canonical Standard:

- declares applicability through `AIDE_Scope`;
- declares dependencies through `AIDE_Dependencies`;
- declares version transition intent under `AIDE_Migration`;
- may contribute Tag/Dependency Builders where it owns the source semantics;
- uses Review where independent assessment adds value; and
- carries only capability-specific platform addenda. Generic platform implementation belongs Build
  side.

## Boundaries

Standards does not own Tags, Scope, Dependencies, Migration, Deployment, Review, WorkPackage, or
platform skill/plugin/bundle mechanics.

A Standard may describe a procedure but does not define a named invokable action; that is a Tool.

## Success signals

- A Standard author can produce one clear canonical Standard without inventing shared mechanisms.
- An extracted/chunked rule still carries its obligation weight and enough context to be used
  correctly.
- Platform builders can realise the same canonical Standard without reopening Capability Design.
- Runtime consumers can combine applicable Standards and surface genuine conflict/deviation rather
  than silently resolving it.


## Current Definition

`Capabilities_Standards_Definition_v1` is the required capability-level control document; production uses `AIDE_StandardsProduction@v3`.

---

**Depends on:** `Capabilities_Design_v12`, `Capabilities_Standards_Design_v7`.

**References:** `Capabilities_Brief_v11`, `AIDE_Scope@v2`, `AIDE_Dependencies@v3`,
`AIDE_Migration@v2`.

**Methodology:** v27
<!-- END SOURCE: Capabilities_Standards_Brief_v3.md -->

---

<!-- BEGIN SOURCE: Capabilities_Standards_Design_v7.md -->
# Capabilities Standards — Design

> **Version 7** (2026-09-02). Aligns Standard production with Capability Definition and Element release/checkpoint semantics.

---

## §1 — Scope

Standards defines the Standard capability kind: role, rule/weight structure, canonical production,
and generic usage behaviour. It does not own individual domain Standards or shared mechanisms that
now have peer components.

## §2 — Role and purpose

A Standard provides guides, rules, advice and support focused on adding value and facilitating
effective work. Enforcement may be one of its roles but is never its primary lens; requirements are
framed through the consequence/value of meeting them.

A Standard shapes decisions and behaviour over a context. A named invokable action is a Tool.

## §3 — Weight system

Four weights remain:

- **Requirement** — must be met for the stated outcome/consumer to work; not open to ordinary
  judgment.
- **Expectation** — default position; departure is allowed but must be declared visibly.
- **Guidance** — default/best practice; departure is allowed and its consequences are owned.
- **Context** — information/reasoning with no obligation.

Every weighted unit states enough reason/consequence to preserve facilitation rather than bare
authority.

## §4 — Weight attachment and chunkability

Weight is a semantic property of addressable/chunkable Standard content.

- optional document default;
- every addressable section/unit carries its effective weight;
- statement-level override only where genuinely different.

Nearest declaration wins. Platform builders may render the semantic weight differently where the
target retrieval/chunking model needs another representation, but must not change its meaning.

## §5 — Outputs and audiences

Standards produces:

1. **Standards Production Standard** — for authors/builders of Standards.
2. **Standards Usage Standard** — for AI sessions operating under Standards.
3. Optional human **Guide** outcomes declared by individual capability designs.

The Standard is terse and complete; a Guide is explanatory. Both derive from the same Design and
may not disagree about substance.

## §6 — Canonical Standard contract

A canonical Standard contains only the capability meaning needed by consumers and Build, including
where applicable:

- formal identity/common name/release version;
- purpose and rules with effective weights;
- `AIDE_Scope` declarations;
- `AIDE_Dependencies` declarations;
- `AIDE_Migration` summary/transition declarations;
- owner-defined Tag/Dependency Builder definitions;
- Review expectations/profiles where the capability requires them; and
- capability-specific platform addenda.

Generic platform skill/plugin/bundle metadata does not belong in the canonical design contract.

## §7 — Production

```text
Capability Definition + documented production inputs
      ↓
Update Capability Elements
      ↓
canonical Standard Element + evaluated-input checkpoint
```

Update Capability Elements applies `AIDE_StandardsProduction@v3`. If reassessment finds unchanged
meaning, only `LastEvaluated` advances. If meaning changes, the canonical Standard is validated and
the next Element release/history is confirmed. Capability Build/package/Deployment remain later.

## §7a — Capability-reference validation

Canonical production distinguishes saved dependency checkpoints and reader References from current
executable capability instructions. Executable capability references are versionless by default. A
specific release is used only where the instruction deliberately depends on or targets that release;
production validates that the specificity is intentional and correct rather than mechanically
advancing it to the newest available release.

`References:` carries no currency or conformance obligation. Dependency checkpoint advancement
remains owned by `AIDE_Dependencies`/`AIDE_Migration`.

## §8 — Scope, Tags, and Dependencies

Standards consumes `AIDE_Scope`; it does not define another applicability language.

Standards may embed `AIDE_TagBuilder` or `AIDE_DependencyBuilder` blocks where that Standard owns the
semantics from which generated tags/dependencies are derived. Tags/Dependencies own builder
execution/storage/query contracts.

## §9 — Migration and release

Standards may change existing consumers. Each changed Standard Element release follows `AIDE_Migration` and declares Required, OnUpdate, or None. Element release is distinct from source document version, containing Capability release/composition, Package identity and deployment state.

## §10 — Review

Standards uses `AIDE_Review` rather than defining a local review mechanism. Production may select an
appropriate Review Profile for substantive integrity, weight justification, conflict, or other
capability-specific concerns.

Tone/facilitation quality is assessed through Review/judgment, not a mechanical publishing gate.

## §11 — Usage, conflict, and deviation

The Standards Usage outcome defines generic runtime behaviour. Before a Machine Scope result is
relied upon, the consumer honours the current-tag precondition supplied by `AIDE_Scope`/`AIDE_Tags`.
A dependency conformance checkpoint behind the available capability release is expected steady state
and is not by itself stale, missing, or an update trigger; applicable Required Migration remains the
affected-use gate.

The retained resolution principles are:

1. combine compatible Standards;
2. where genuine opposition exists, higher weight governs the point;
3. equal-weight genuine conflict is surfaced/escalated rather than silently resolved; and
4. direct human instruction may override a Standard, but the displaced Requirement/Expectation and
   consequence are surfaced/recorded as appropriate.

Scope determines whether the Standard is applicable before conflict resolution is considered.

## §12 — Ownership boundary

Standards owns Standard meaning, weight structure, canonical Standard production requirements, and
generic usage behaviour.

Peers own:

- Tags — classifications/builders/query;
- Scope — applicability;
- Dependencies — dependency/version state/order;
- Migration — transition semantics/execution;
- Review — independent assessment;
- Build — platform realisation/WorkPackage;
- Deployment — set-aware distribution/publication.


## §13 — Capability Element production

Standards are Capability Elements. Production resolves the current Capability Definition and
Element Production state, separates document revision from semantic Element release, and advances
`LastEvaluated` without a release when reassessment finds unchanged meaning. The current published
contract is `AIDE_StandardsProduction@v3`.

---
Dependencies: !AIDE_DocumentationMethodology@v27, Capabilities_Design_v12, Capabilities_Decisions_v17
References: Capabilities_Standards_Brief, Capabilities_Tools_Design, AIDE_Scope, AIDE_Dependencies, AIDE_Migration, AIDE_Review
<!-- END SOURCE: Capabilities_Standards_Design_v7.md -->

---

<!-- BEGIN SOURCE: AIDE_StandardsProduction_Standard_v3.md -->

# AIDE Standards Production — Standard

> **Identity:** `AIDE_StandardsProduction@v3`
> **Common name:** Standards Production
> **Version 3** (2026-09-02). Aligns Standard Element production with Capability Definition, Element releases and LastEvaluated checkpoints.

## Purpose and inputs

Produce or validate one canonical Standard Element from the current Capability Definition,
documented production inputs and applicable Scope/Dependencies/Migration contracts without inventing
meaning. Resolve Element identity/release, canonical outcome identity, prior release/history, Current
Migration and current production inputs.

## Rule

An input/document version change makes the Element potentially stale. Reassess it. If canonical
meaning is unchanged, advance only the Element Production `LastEvaluated` checkpoint. If meaning
changes, produce/validate the outcome, convert Current Migration into the immutable release entry and
confirm the next Element release. Document version and Element release are not the same.

Keep capability-reference roles distinct: Dependencies are conformance checkpoints, References are
reader/evidence pointers, and executable body references are versionless by default unless a specific
contract release is intentional.

## Output

Return the canonical Standard outcome plus production result, evaluated-input checkpoint and any
confirmed Element-release/history update. Do not perform platform Build/package/Deployment.

```yaml
MigrationSummary:
  CurrentVersion: v3
  LatestRequiredVersion: none
  LatestOnUpdateVersion: none

Transition:
  Version: v3
  Posture: None
```

---
Dependencies: !AIDE_DocumentationMethodology@v27, AIDE_Capability@v1, AIDE_Scope@v2, AIDE_Dependencies@v3, AIDE_Migration@v2
References: Capabilities_Standards_Design_v7, AIDE_UpdateCapabilityElementsTool@v1
<!-- END SOURCE: AIDE_StandardsProduction_Standard_v3.md -->

---

<!-- BEGIN SOURCE: AIDE_StandardsUsage_Standard_v2.md -->
# AIDE Standards Usage — Standard

> **Identity:** `AIDE_StandardsUsage@v2`
> **Common name:** Standards Usage
> **Version 2** (2026-09-01). Carries current Machine Scope tag-freshness and expected dependency-checkpoint lag into the runtime Standards consumer contract.
>
> **Default weight:** Requirement

---

## Purpose

Operate under applicable AI-facing Standards consistently while preserving declared weights,
Scope, dependencies, migration requirements, human authority, and visible handling of genuine
conflict or deviation.

## Applicability

Apply whenever an AI session relies on one or more governed Standards to perform, assess, or advise
work.

```yaml
Scope:
  Context: >
    Apply when governed Standards are available and relevant to the current work or action.
```

## Establish the applicable set

1. Discover the Standards available to the current execution context.
2. Resolve their formal identities and dependency state where relevant.
3. Before affected use, honour any applicable Required Migration under `AIDE_Migration`.
4. Before relying on Machine Scope, satisfy the current-tag freshness precondition owned by `AIDE_Scope`/`AIDE_Tags`; then evaluate `AIDE_Scope`. An item that is not applicable contributes no rule to the current work.
5. Use only the material needed for the current work while preserving each retrieved unit's
   effective weight and necessary context.

Do not treat installation/presence alone as applicability.

## Interpret weights

- `Requirement` — satisfy it for the stated outcome/consumer; if it cannot be satisfied, surface
  the consequence and do not silently claim conformance.
- `Expectation` — follow by default; if departing, make the departure visible.
- `Guidance` — follow where it adds value; departure is allowed and the resulting consequences are
  owned.
- `Context` — use as information/reasoning; it creates no obligation by itself.

A lower-weight statement does not silently cancel a higher-weight statement on the same point.

## Combine Standards

Compatible applicable Standards stack. Do not choose one merely because several apply.

When two applicable statements genuinely oppose each other on the same point:

1. higher weight governs;
2. equal-weight conflict is surfaced/escalated rather than silently resolved; and
3. the conflict record identifies the competing Standards/statements and the work affected.

Do not manufacture conflict from different concerns that can both be satisfied.

## Human instruction and deviation

Direct human/work-owner instruction may override a Standard within that person's authority.
When it displaces a Requirement or Expectation:

- state the Standard position and material consequence;
- make the departure visible in the appropriate work record where durability matters; and
- continue under the authorised instruction unless another non-overridable external constraint
  applies.

Guidance may be departed from without approval, but material consequences remain the responsibility
of the work owner/Lead.

## Missing, stale, or unresolved Standard state

- Missing required dependency → surface under `AIDE_Dependencies` and follow the governing
  operation's blocking posture.
- A dependency conformance checkpoint behind the available release is expected steady state and is not by itself stale, missing, or an update trigger; applicable Required Migration before affected use remains the gate.
- Required Migration outstanding → reconcile before affected use.
- Unsupported migration baseline or ambiguous transition → stop affected use and escalate.
- Unresolvable Standard identity/version → do not guess which contract governs.
- Genuine equal-weight conflict → escalate rather than select silently.

## Runtime economy

Prefer cheap applicability/version checks before loading detailed Standard material. Use
`MigrationSummary`, Scope machine filters, Tags, and platform discovery metadata where available,
then load only the detailed content needed for the work.

Performance optimisation must not change Standard meaning or hide an applicable Requirement.

## Reporting

Normal operation need not narrate every Standard consulted. Surface what materially affects the
work: blocking requirements, meaningful expectations/deviations, conflicts, migration state, or a
Standard-driven consequence the user/work owner needs to know.

```yaml
MigrationSummary:
  CurrentVersion: v2
  LatestRequiredVersion: none
  LatestOnUpdateVersion: none

Transition:
  Version: v1
  Posture: None

Transition:
  Version: v2
  Posture: None
```

---
Dependencies: !AIDE_DocumentationMethodology@v26, Capabilities_Standards_Design_v6, AIDE_Scope@v2, AIDE_Dependencies@v3, AIDE_Migration@v2
References: AIDE_StandardsProduction
<!-- END SOURCE: AIDE_StandardsUsage_Standard_v2.md -->

---

<!-- BEGIN SOURCE: Capabilities_Tools_Definition_v2.md -->
# Tools — Capability Definition

> **Version 2** (2026-09-02). Advances the Build Capability and Capability Builder Elements for the current Registry seam while preserving other Tool Elements.

## Identity, purpose and boundary

**Capability:** `Tools@v2`

Defines canonical Tool production plus the current Capability production/build Tools.

This Definition controls Capability-level composition and production state. Detailed Element
semantics remain in the canonical outcomes identified below.

## Capability Elements

| Element | Type | Canonical outcome | Element release |
|---|---|---|---:|
| `Tools.Production` | Standard | `AIDE_ToolsProduction@v2` | v1 |
| `Tools.UpdateCapabilityElements` | Tool | `AIDE_UpdateCapabilityElementsTool@v1` | v1 |
| `Tools.BuildCapability` | Tool | `AIDE_BuildCapabilityTool@v4` | v2 |
| `Tools.CapabilityBuilder` | Tool | `AIDE_CapabilityBuilderTool@v2` | v2 |

## Capability Release History

```text
Tools@v1
  Tools.Production@v1 -> AIDE_ToolsProduction@v2
  Tools.UpdateCapabilityElements@v1 -> AIDE_UpdateCapabilityElementsTool@v1
  Tools.BuildCapability@v1 -> AIDE_BuildCapabilityTool@v3
  Tools.CapabilityBuilder@v1 -> AIDE_CapabilityBuilderTool@v1

Tools@v2
  Tools.Production@v1 -> AIDE_ToolsProduction@v2
  Tools.UpdateCapabilityElements@v1 -> AIDE_UpdateCapabilityElementsTool@v1
  Tools.BuildCapability@v2 -> AIDE_BuildCapabilityTool@v4
  Tools.CapabilityBuilder@v2 -> AIDE_CapabilityBuilderTool@v2
```

This baseline adopts already-current canonical outcomes into the new Capability/Element release
model; it does not pretend those outcomes were newly changed on 2026-09-02.

## Element Release History

- `Tools.Production@v1` — baseline adoption of `AIDE_ToolsProduction@v2`; no new semantic change asserted.
- `Tools.UpdateCapabilityElements@v1` — baseline adoption of `AIDE_UpdateCapabilityElementsTool@v1`; no new semantic change asserted.
- `Tools.BuildCapability@v1` — baseline adoption of `AIDE_BuildCapabilityTool@v3`; no new semantic change asserted.
- `Tools.CapabilityBuilder@v1` — baseline adoption of `AIDE_CapabilityBuilderTool@v1`; no new semantic change asserted.
- `Tools.BuildCapability@v2` — resolves Registry publication to `AIDE_DeploymentRegistryTool@v1` and current `AIDE_CapabilityBuild@v2`.
- `Tools.CapabilityBuilder@v2` — emits the current immutable Capability Package Registry envelope and keeps post-Build result external.

## Element Production

| Element | Production inputs | LastEvaluated |
|---|---|---|
| `Tools.Production` | Current sources/contracts identified by Definition references | 2026-09-02 baseline |
| `Tools.UpdateCapabilityElements` | Current sources/contracts identified by Definition references | 2026-09-02 baseline |
| `Tools.BuildCapability` | Current sources/contracts identified by Definition references | 2026-09-02 Registry seam |
| `Tools.CapabilityBuilder` | Current sources/contracts identified by Definition references | 2026-09-02 Registry seam |

Update the mutable checkpoint when sources/contracts are reassessed. An input-version change does
not by itself increment an Element release; immutable release-source snapshots stay in history when
later releases are produced.

## Current Migration

None. Authoritative existing outcome migrations remain under `AIDE_Migration`. A future Element
change carries Current Migration until release confirmation.

## Platform Definition and Build Platforms

The Capability is platform-neutral. Current generic Working Surface evidence must be resolved before
a Capability Build request. Newly supported platforms are surfaced and retain designer selection
`Build: null` until explicitly decided; unsupported plus `Build:true` is blocking.

## Post-Build intent

No Registry publication is inferred automatically. A Capability Build request may nominate `AIDE_DeploymentRegistryTool@v1` action `Register` with configured Registry and optional open Release Batch, or another applicable post-Build Tool/explicit none. Registry result remains external to the immutable package and Tool semantic releases.

---
Dependencies: !AIDE_DocumentationMethodology@v27, AIDE_Capability@v1, AIDE_Dependencies@v3, AIDE_Migration@v2
References: Capabilities_Tools_Design_v5, AIDE_ToolsProduction@v2, AIDE_DeploymentRegistryTool@v1
<!-- END SOURCE: Capabilities_Tools_Definition_v2.md -->

---

<!-- BEGIN SOURCE: Capabilities_Tools_Brief_v5.md -->
# Capabilities Tools — Brief

> **Version 5** (2026-09-02). Advances Build Capability and Capability Builder for the current Registry seam.

---

## Purpose

Tools owns the reusable model for invokable AI capability behaviour: how a Tool defines its
identity/actions, inputs, preconditions, procedure, bounded decisions, escalation, outputs,
reporting, failure handling, and idempotency.

A Tool removes the need to re-derive a repeatable action each time. It may orchestrate bounded
judgment explicitly defined by its contract, but does not silently take substantive authority that
belongs to the work owner or another capability.

## Output

Tools publishes `AIDE_ToolsProduction@v1`, the canonical production contract used by domains and
Build Capability to produce/validate individual canonical Tools from confirmed Tool/Capability
Design. Platform Build Standards/Tools turn logical actions into target-specific skills, commands,
UI actions, scripts, or other representations.

## Required relationships

A Tool:

- declares applicability through `AIDE_Scope`;
- may declare dependencies through `AIDE_Dependencies`;
- may carry `AIDE_Migration` transition declarations where its release changes durable consumer
  state/configuration/contract;
- defines logical actions independently of their platform rendering; and
- reports what it did, what changed, and what needs attention.

## Boundaries

Tools does not own Scope, Tags, Dependencies, Migration, Review, Deployment, WorkPackage, or generic
platform implementation.

A Standard may describe procedure; a named invokable action is a Tool.

## Success signals

- A Tool can be invoked without re-deriving its mechanism.
- Inputs and decision/escalation boundaries are explicit.
- Re-running behaviour is known.
- Platform implementations preserve one logical action contract despite different command/skill
  representations.
- Durable release transitions are handled through the shared Migration contract rather than a
  Tool-specific version mechanism.


## Current Tool set

Element update, Build request orchestration and Build-side execution are separate current Tools under `Capabilities_Tools_Definition_v2`; Registry publication remains an AI-Deployment-owned post-Build action.

---
Dependencies: !AIDE_DocumentationMethodology@v27, Capabilities_Design_v13, Capabilities_Tools_Design_v5
References: Capabilities_Brief_v11, AIDE_Scope@v2, AIDE_Dependencies@v3, AIDE_Migration@v2
<!-- END SOURCE: Capabilities_Tools_Brief_v5.md -->

---

<!-- BEGIN SOURCE: Capabilities_Tools_Design_v5.md -->
# Capabilities Tools — Design

> **Version 5** (2026-09-02). Reconciles Capability Build/Builder Tool outcomes to the current Deployment Registry contract.

---

## §1 — Role and purpose

A Tool encapsulates a repeatable invokable action so its mechanism and safety checks are not
re-derived every time it is used.

Its value remains determinism of the action contract, encapsulation, lower repeated reasoning cost,
and completeness.

A Tool may contain bounded judgment where its contract explicitly defines how to infer, ask,
select, continue, or escalate. Genuine substantive authority remains with the work owner or the
capability that owns that judgment.

### Published production contract

This Design produces `AIDE_ToolsProduction@v1`, the published generic contract for producing and
validating canonical Tools from confirmed Tool/Capability Design. The structure below remains the
Tools-owned semantic source; downstream producers consume the published contract rather than
copying this internal Design.

## §2 — Canonical Tool structure

A Tool Design defines, in this order where applicable:

### Identity and logical actions

Stable Tool identity/common name and the logical actions/commands it contributes. Platform names
and invocation syntax are later renderings.

### Trigger and Scope

Explicit invocation plus contextual circumstances where the Tool should be selected proactively.
Applicability is declared through `AIDE_Scope`, not a Tools-local model.

### Purpose

A dense selection/retrieval statement describing the action/outcome.

### Inputs

For each input: requirement/default, resolution sources, and confirmation posture.

### Preconditions

Facts that must hold before changing state.

### Procedure

Ordered operational steps.

### Decision points

Visible branches and the rule/authority that resolves them. Do not hide substantive decisions in
procedure prose.

### Escalation conditions

Conditions where the Tool must hand back rather than invent policy/authority.

### Outputs and effects

Produced artefacts, changed state, persistent records.

### Reporting

Minimal/summary/detailed/verbose narration as appropriate; failures/deviations always surface.
Narration verbosity does not reduce the persisted record.

### Failure handling and idempotency

Partial-completion semantics, resumability/retry behaviour, and explicit idempotency declaration.

## §3 — Ask, infer, escalate

- infer and state where confidence is strong and cost of error low;
- ask once, preferably batched, for genuinely missing required inputs;
- escalate genuine conflicts, authority decisions, or material uncertainty the Tool does not own.

Never fail for want of information that could reasonably have been requested.

## §4 — Standards boundary

A Standard shapes behaviour/decision context. A Tool exposes a named invokable action.

A Standard may describe a procedure until a Tool exists; once an authoritative Tool owns the
action, the Standard points to it rather than duplicating the executable mechanism.

One Capability Design may produce sibling Standards and Tools from the same confirmed meaning.

## §5 — Scope, dependencies and migration

Tools consumes the shared contracts:

- Scope → whether the Tool/action applies;
- Dependencies → identities/version state the Tool relies on;
- Migration → release transitions affecting durable consumer state/configuration/contract.

Tools are **not categorically excluded from Migration**. If a Tool release has no existing durable
consumer state to transition, it declares `None`; if a real transition exists, it uses the same
Required/OnUpdate/None model as Standards.

## §6 — Canonical production and platform realisation

```text
Tool / Capability Design
   ↓
AIDE_ToolsProduction
   ↓
canonical Tool
   ↓
Build WorkPackage
   ↓
platform Build Standards/Tools
   ↓
platform contribution
```

`AIDE_UpdateCapabilityElementsTool` invokes `AIDE_ToolsProduction@v2` where documented production is required; directly authored Tool Elements and other authorised producers may consume the same contract. The
canonical Tool carries platform-independent action semantics plus capability-specific platform
addenda only. Generic skill/plugin/command-file/UI mechanics belong Build side.

## §7 — Version/release/package boundary

A Tool Element release is distinct from the DocMeth version of its sources and from the containing Capability release/composition. Package identity/integrity identifies a Build instance; Deployment state records what is installed. Neither is another Tool Element release.

## §8 — Reporting preferences

The four narration levels remain minimal, summary, detailed, verbose, defaulting to summary where
no stronger environment/user preference is available. The long-term storage home for account/
environment preferences remains external architecture work; Tools only consumes the resolved
preference.

## §9 — Ownership boundary

Tools owns the generic Tool/action contract and canonical Tool semantics. Shared peer components own
Scope, Dependencies, Migration, Review, Deployment, and platform implementation/build knowledge.


## §8 — Current production/build Tool family

- `AIDE_UpdateCapabilityElementsTool@v1` — design-side Element evaluation/production.
- `AIDE_BuildCapabilityTool@v4` — Build request/readiness/WorkPackage orchestration with current Registry post-Build intent.
- `AIDE_CapabilityBuilderTool@v2` — Build-side specialised executor producing the immutable Registry-compatible Capability Package.

`AIDE_BuildCapabilityTool@v2` remains historical and requires explicit migration; its production
role is not silently interpreted as v3. Tool Element production uses `AIDE_ToolsProduction@v2`.

---
Dependencies: !AIDE_DocumentationMethodology@v27, Capabilities_Design_v13, Capabilities_Decisions_v18
References: Capabilities_Tools_Brief_v4, Capabilities_Standards_Design_v7, AIDE_Scope@v2, AIDE_Dependencies@v3, AIDE_Migration@v2
<!-- END SOURCE: Capabilities_Tools_Design_v5.md -->

---

<!-- BEGIN SOURCE: AIDE_ToolsProduction_Standard_v2.md -->

# AIDE Tools Production — Standard

> **Identity:** `AIDE_ToolsProduction@v2`
> **Common name:** Tools Production
> **Version 2** (2026-09-02). Aligns Tool Element production with Capability Definition, Element releases and LastEvaluated checkpoints.

## Purpose and inputs

Produce or validate one complete platform-independent canonical Tool Element from the current
Capability Definition, confirmed Tool behaviour and documented production inputs. Resolve Element
identity/release, logical actions, Scope, Dependencies, Migration, prior history and Current Migration.

## Canonical Tool contract

Specify stable outcome identity/common name; actions and triggers; inputs/defaults/preconditions;
ordered procedure and decision authority; escalation; outputs/effects; reporting; failure/partial/
idempotency/resumption semantics. Do not leak generic platform mechanics or infer new authority.

## Release rule

Reassess changed inputs. If Tool meaning is unchanged, update only `LastEvaluated`. If meaning
changes, validate the new canonical outcome, convert Current Migration and confirm the next Element
release. Document version, Element release and Capability release remain distinct.

## Output

Return the canonical Tool plus production/checkpoint/release result. Platform Build/package/
Deployment remain later concerns.

```yaml
MigrationSummary:
  CurrentVersion: v2
  LatestRequiredVersion: none
  LatestOnUpdateVersion: none

Transition:
  Version: v2
  Posture: None
```

---
Dependencies: !AIDE_DocumentationMethodology@v27, AIDE_Capability@v1, AIDE_Scope@v2, AIDE_Dependencies@v3, AIDE_Migration@v2
References: Capabilities_Tools_Design_v4, AIDE_UpdateCapabilityElementsTool@v1
<!-- END SOURCE: AIDE_ToolsProduction_Standard_v2.md -->

---

<!-- BEGIN SOURCE: Capabilities_UpdateCapabilityElements_Tool_Design_v1.md -->

# Capabilities Update Capability Elements Tool — Design

> **Version 1** (2026-09-02). Succeeds the canonical-element production role formerly carried by Build Capability v2.

## Purpose

Evaluate documented production inputs and produce/refresh/validate canonical Elements without
inventing meaning or creating false releases.

## Result rule

`input changed → reassess Element → semantic change?`

- no: advance `LastEvaluated`; retain Element release;
- yes: produce/validate the Element, convert Current Migration and confirm the next Element release;
- unresolved conflict/gap: return blocked/incomplete.

Directly authored Elements without derivation need not invoke this Tool.

---
Dependencies: !AIDE_DocumentationMethodology@v27, AIDE_Capability@v1, AIDE_StandardsProduction@v3, AIDE_ToolsProduction@v2
References: Capabilities_Capability_Design_v1
<!-- END SOURCE: Capabilities_UpdateCapabilityElements_Tool_Design_v1.md -->

---

<!-- BEGIN SOURCE: AIDE_UpdateCapabilityElements_Tool_v1.md -->

# AIDE Update Capability Elements — Tool

> **Identity:** `AIDE_UpdateCapabilityElementsTool@v1`
> **Common name:** Update Capability Elements
> **Version 1** (2026-09-02). First design-side Element production/update Tool.

## Actions

`Evaluate | Update | Validate | Status`

## Procedure

1. Resolve the current Capability Definition, target Elements and documented Element Production inputs.
2. Compare each current input/version with its `LastEvaluated` checkpoint.
3. Reassess potentially stale Elements using the applicable production contract.
4. If meaning is unchanged, update only the evaluated checkpoint.
5. If meaning changes, update and validate the canonical Element, complete Current Migration and
   confirm the next Element release/history.
6. If current inputs conflict or are insufficient, return the smallest actionable defect; do not choose/invent.
7. Update the Capability release only if composition or substantive Capability-level Definition changed.

## Migration from Build Capability v2

Calls that used `AIDE_BuildCapabilityTool@v2` to produce canonical Standards/Tools migrate to this
Tool. Do not reinterpret an unreviewed v2 invocation as Build Capability v3.

---
Dependencies: !AIDE_DocumentationMethodology@v27, AIDE_Capability@v1, AIDE_StandardsProduction@v3, AIDE_ToolsProduction@v2
References: Capabilities_UpdateCapabilityElements_Tool_Design_v1, AIDE_BuildCapabilityTool@v2
<!-- END SOURCE: AIDE_UpdateCapabilityElements_Tool_v1.md -->

---

<!-- BEGIN SOURCE: Capabilities_BuildCapability_Tool_Design_v4.md -->

# Capabilities Build Capability Tool — Design

> **Version 4** (2026-09-02). Adds current Deployment Registry post-Build request resolution without changing the v3 orchestration role.

## Purpose

Check Capability Build readiness, establish the current Build request including any nominated Registry `Register` action, and produce/authorise the WorkPackage for Capability Builder execution.

## Breaking transition

v2 produced canonical Standards/Tools. That responsibility moves to Update Capability Elements.
v3 is not backwards-compatible by silent reinterpretation; existing invocations/configuration must
be reviewed and split/migrated.

---
Dependencies: !AIDE_DocumentationMethodology@v27, AIDE_CapabilityBuild@v2, AIDE_WorkPackage@v3
References: AIDE_UpdateCapabilityElementsTool@v1, AIDE_CapabilityBuilderTool@v2, AIDE_DeploymentRegistryTool@v1
<!-- END SOURCE: Capabilities_BuildCapability_Tool_Design_v4.md -->

---

<!-- BEGIN SOURCE: AIDE_BuildCapability_Tool_v4.md -->

# AIDE Build Capability — Tool

> **Identity:** `AIDE_BuildCapabilityTool@v4`
> **Common name:** Build Capability
> **Version 4** (2026-09-02). Resolves current Deployment Registry post-Build intent while preserving the v3 orchestration role.

## Actions

`Request | ValidateReadiness | Authorise | Status`

## Procedure

1. Resolve the current Capability Definition, released Elements/composition and production currency.
2. Require resolved Build Platforms and at least one explicit `Build:true`.
3. Resolve applicable Capability Build/platform rules, Registry-compatible package acceptance and explicit post-Build intent. When Registry publication is requested, resolve `AIDE_DeploymentRegistryTool@v1` action `Register`, configured Registry and optional open Release Batch.
4. If an Element may be stale, return `UpdateElementsRequired`; do not produce it here.
5. Validate that the requested force scope, if any, cannot imply false semantic release changes.
6. Create/authorise the self-contained `AIDE_WorkPackage@v3` for Capability Builder.
7. Return WorkPackage identity, readiness, selected platforms, post-Build request and blockers. Keep actual post-Build result outside the validated package.

## Required migration from v2

`AIDE_BuildCapabilityTool@v2` canonical production calls move to
`AIDE_UpdateCapabilityElementsTool@v1`. Only explicitly migrated orchestration calls use v3.

```yaml
MigrationSummary:
  CurrentVersion: v4
  LatestRequiredVersion: v3
  LatestOnUpdateVersion: none

Transition:
  Version: v3
  Posture: Required
  Action: Review every v2 invocation; move Element production to AIDE_UpdateCapabilityElementsTool@v1 and retain only Build-request orchestration here.

Transition:
  Version: v4
  Posture: None
```

---
Dependencies: !AIDE_DocumentationMethodology@v27, AIDE_Capability@v1, AIDE_CapabilityBuild@v2, AIDE_WorkPackage@v3
References: Capabilities_BuildCapability_Tool_Design_v4, AIDE_UpdateCapabilityElementsTool@v1, AIDE_DeploymentRegistryTool@v1
<!-- END SOURCE: AIDE_BuildCapability_Tool_v4.md -->

---

<!-- BEGIN SOURCE: Capabilities_CapabilityBuilder_Tool_Design_v2.md -->

# Capabilities Capability Builder Tool — Design

> **Version 2** (2026-09-02). Adds the current immutable Registry-compatible Capability Package envelope and post-Build result boundary.

## Purpose

Execute an authorised Capability Build WorkPackage using `AIDE_CapabilityBuild` and applicable
platform rules, returning a complete validated Registry-compatible Capability Package and separate Outcome/post-Build evidence.

## Boundary

The Builder does not change Capability/Element meaning, choose Build Platforms, infer Registry contracts, write Registry results back into immutable package bytes, or increment semantic releases because it was forced/re-run.

---
Dependencies: !AIDE_DocumentationMethodology@v27, AIDE_CapabilityBuild@v2, AIDE_Build@v7
References: Capabilities_CapabilityBuild_Design_v2, AIDE_DeploymentRegistryTool@v1
<!-- END SOURCE: Capabilities_CapabilityBuilder_Tool_Design_v2.md -->

---

<!-- BEGIN SOURCE: AIDE_CapabilityBuilder_Tool_v2.md -->

# AIDE Capability Builder — Tool

> **Identity:** `AIDE_CapabilityBuilderTool@v2`
> **Common name:** Capability Builder
> **Version 2** (2026-09-02). Produces the current immutable Registry-compatible Capability Package and keeps Registry result external.

## Procedure

1. Accept/validate the authorised WorkPackage under `AIDE_Build`.
2. Resolve current Definition, released Elements, selected Build Platforms and applicable rules.
3. Determine affected internal work; reuse/cache only with valid provenance and integrity.
4. Build every selected platform output to the complete external contract.
5. Assemble the complete `CapabilityPackage` Registry envelope: Logical Package Identity, PackageId/integrity, Capability/Element composition, source/production/Build provenance, complete built output/member identities, Build-owned composition posture where applicable, dependencies/Migration, evidence, optional package/member Tags, surface variation/degradation and namespaced extensions.
6. Validate the complete Package against WorkPackage Acceptance.
7. Freeze the validated PackageId payload; do not write later Registry receipt/lifecycle state back into it.
8. Invoke the nominated post-Build Tool if successful; for Registry publication use `AIDE_DeploymentRegistryTool@v1` action `Register` with configured Registry and optional open Release Batch.
9. Return WorkPackage Outcome with actual Package and separate post-Build/Registry receipt state.

Force build never increments semantic releases. Missing/unknown required platform or governing
capability state blocks rather than being assumed.

---
Dependencies: !AIDE_DocumentationMethodology@v27, AIDE_CapabilityBuild@v2, AIDE_Build@v7, AIDE_WorkPackage@v3, AIDE_Tags@v2
References: Capabilities_CapabilityBuilder_Tool_Design_v2, AIDE_DeploymentRegistryTool@v1
<!-- END SOURCE: AIDE_CapabilityBuilder_Tool_v2.md -->
