# AIDE — Direct Registry Seam Reconciliation — Change Delivery Instructions — 2026-09-02

## Purpose

Apply the outstanding Build and Capabilities changes created by the now-current AI Deployment Registry contract. This replaces the earlier cross-project handoff step: the changes have been authored directly from the supplied/current Binders.

This pass is deliberately limited to the **Registry seam**. It does not finalise Build Target Profiles/Definitions, conformance/degradation policy resolution, Deployment Set selectors, Deployment Package/output definitions, Delivery Actions or target adapters.

## Build — replace Current

- `Build_Index_v7.md` replaces v6.
- `Build_Design_v7.md` replaces v6.
- `Build_Decisions_v7.md` replaces v6.
- `AIDE_Build_Standard_v7.md` replaces v6 (`AIDE_Build@v7`).
- `Build_PostBuild_Design_v2.md` replaces v1.

Retain unchanged `Build_WorkPackage_Design_v3.md`, `AIDE_WorkPackage_Standard_v3.md`, and `AIDE_PublishBuildOutput_Tool_v1.md`.

Expected generated Binder: `Build_Binder_v7.md`.

## Capabilities Core — replace Current

- `Capabilities_Index_v21.md`
- `Capabilities_Brief_v12.md`
- `Capabilities_Overview_v18.md`
- `Capabilities_Design_v13.md`
- `Capabilities_Decisions_v18.md`
- `Capabilities_CapabilityBuild_Design_v2.md`
- `Capabilities_CapabilityBuild_Decisions_v2.md`
- `AIDE_CapabilityBuild_Standard_v2.md` (`AIDE_CapabilityBuild@v2`)

Retain Capability model Design/Decisions and `AIDE_Capability@v1` unchanged.

Expected generated Binder: `Capabilities_Binder_Core_v7.md`.

## Capabilities Standards/Tools — replace Current

- `Capabilities_Standards_Definition_v2.md`
- `Capabilities_Tools_Definition_v2.md` (Tools Capability advances to `Tools@v2`)
- `Capabilities_Tools_Brief_v5.md`
- `Capabilities_Tools_Design_v5.md`
- `Capabilities_BuildCapability_Tool_Design_v4.md`
- `AIDE_BuildCapability_Tool_v4.md` (`AIDE_BuildCapabilityTool@v4`)
- `Capabilities_CapabilityBuilder_Tool_Design_v2.md`
- `AIDE_CapabilityBuilder_Tool_v2.md` (`AIDE_CapabilityBuilderTool@v2`)

Expected generated Binder: `Capabilities_Binder_StandardsTools_v4.md`.

## Other Capability Definitions — replace Current

These Definition-document updates close only the post-Build Registry reference and do **not** create new Capability/Element semantic releases:

- `Capabilities_Tags_Definition_v2.md`
- `Capabilities_Scope_Definition_v2.md`
- `Capabilities_Dependencies_Definition_v2.md`
- `Capabilities_Migration_Definition_v2.md`
- `Capabilities_Review_Definition_v2.md`
- `Capabilities_Messaging_Definition_v2.md`

After replacement, regenerate:

- `Capabilities_Binder_Runtime_v3`
- `Capabilities_Binder_Review_v5`
- `Capabilities_Binder_Messaging_v5` (supplied as expected generated Binder)

`Capabilities_Binder_Runtime_v3` and `Capabilities_Binder_Review_v5` are not supplied because those full Binder files were available through File Library rather than mounted source files; the changed authoritative Definition masters are supplied and all other masters remain unchanged.

Update the lightweight generated Binder map to `Capabilities_Binder_Set_Index_v2.md` after the partition Binders are regenerated.

## Common generated Bundle

Replace the temporary common runtime Bundle with `AIDE_Bundle_StandardsTools_v7.md`. It now includes Build v7, Capability Build v2, Build Capability Tool v4, Capability Builder Tool v2, AI Deployment v5, Deployment Tool v5 and `AIDE_DeploymentRegistryTool@v1`.

## Confirmed semantic results

- Registry publication is no longer a future placeholder: use `AIDE_DeploymentRegistryTool@v1` action `Register`.
- Successful Build/package validation remains separate from post-Build action success.
- Capability Package is the first specialised Deployable Package.
- Validated PackageId bytes are immutable; Registry receipt/current/lifecycle/batch state remains external.
- Capability Package carries the generic Registry envelope, including Logical Package Identity, resolvable built-output/member identity, Build-owned composition posture where applicable, dependency/Migration material, and optional package/member Tags, surface variation/degradation and namespaced extensions.
- No separate capability-only Deployment Manifest is introduced.
- Release Batch remains an atomic Registry-visibility boundary only.

## Explicitly unchanged/deferred

- `AIDE_WorkPackage@v3`.
- Capability/Element release distinction and Element Production/LastEvaluated model.
- Build Target/Profile redesign and current `Build Platforms` model pending the next design checkpoint.
- Review D remains on hold.
