# AIDE Guidance + Bootstrap — Change Delivery Instructions

> **Reissue R2 — 2026-08-31.**
>
> Built against the user-supplied current `Core_Binder` containing `Core_System_Design_v5`,
> `Core_System_Decisions_v4` and `AIDE_Domain@v1`, and the current Documentation Methodology
> Binder containing `AIDE_DocumentationMethodology@v19`.
>
> This file and the enclosing ZIP are transfer/application artefacts, not enduring masters.

## Summary

This package supersedes the earlier `AIDE_GuidanceBootstrap_ChangeDelivery_2026-08-31` delivery
package. **Do not apply the earlier package.**

R2:

1. integrates Bootstrap directly against the current post-Domain Core corpus;
2. establishes Principles and Working Practices as top-level AIDE projects;
3. produces the first canonical Standards:
   - `AIDE_Bootstrap@v1`
   - `AIDE_Principles@v1`
   - `AIDE_WorkingPractices@v1`;
4. conforms new/changed governed documents to Documentation Methodology v19; and
5. adds the Working Practice requiring current owning-project Binder/current-source checks before
   cross-project master changes.

## Application manifest

| File | Action | Destination | Replaces / supersedes | Context/action |
|---|---|---|---|---|
| `Core/Core_Index_v3.md` | Replace Current | `AIDE/Core/` | `Core_Index_v2.md` → `superseded/` | Regenerate/replace Core Binder/context |
| `Core/Core_System_Design_v6.md` | Replace Current | `AIDE/Core/` | `Core_System_Design_v5.md` → `superseded/` | Regenerate/replace Core Binder/context |
| `Core/Core_System_Decisions_v5.md` | Replace Current | `AIDE/Core/` | `Core_System_Decisions_v4.md` → `superseded/` | Regenerate/replace Core Binder/context |
| `Core/Core_Bootstrap_Design_v2.md` | Add | `AIDE/Core/` | Earlier unadopted delivery candidate `v1` must not be applied | Registered by Core Index v3 |
| `Core/Core_Bootstrap_Decisions_v2.md` | Add | `AIDE/Core/` | Earlier unadopted delivery candidate `v1` must not be applied | Registered by Core Index v3 |
| `Core/AIDE_Bootstrap_Standard_v1.md` | Add | `AIDE/Core/` | New | Include in next common Bundle |
| `Principles/Principles_Index_v3.md` | Replace Current | `AIDE/Principles/` | Current `v1` → `superseded/`; earlier unadopted delivery `v2` not applied | Replace Principles project context via Binder |
| `Principles/Principles_Brief_v3.md` | Replace Current | `AIDE/Principles/` | Current `v1` → `superseded/`; earlier unadopted delivery `v2` not applied | Registered in Index |
| `Principles/Principles_Design_v3.md` | Replace Current | `AIDE/Principles/` | Current `v1` → `superseded/`; earlier unadopted delivery `v2` not applied | Source of Standard |
| `Principles/Principles_Decisions_v3.md` | Replace Current | `AIDE/Principles/` | Current `v1` → `superseded/`; earlier unadopted delivery `v2` not applied | Same-pass reasoning record |
| `Principles/AIDE_Principles_Standard_v1.md` | Add | `AIDE/Principles/` | New | Include in next common Bundle |
| `Working Practices/WorkingPractices_Index_v2.md` | Add/current | `AIDE/Working Practices/` | Earlier unadopted `v1` candidate not applied | Establish project/context |
| `Working Practices/WorkingPractices_Brief_v2.md` | Add/current | `AIDE/Working Practices/` | Earlier unadopted `v1` candidate not applied | Establish project/context |
| `Working Practices/WorkingPractices_Design_v2.md` | Add/current | `AIDE/Working Practices/` | Earlier unadopted `v1` candidate not applied | Source of Standard |
| `Working Practices/WorkingPractices_Decisions_v2.md` | Add/current | `AIDE/Working Practices/` | Earlier unadopted `v1` candidate not applied | Same-pass reasoning record |
| `Working Practices/AIDE_WorkingPractices_Standard_v1.md` | Add | `AIDE/Working Practices/` | New | Include in next common Bundle |
| `Generated/Core_Binder.md` | Generated replacement | Core project context | Current Core Binder after masters applied | Do not edit directly |
| `Generated/Principles_Binder.md` | Generated | Principles project context | New generated consumption artefact | Do not edit directly |
| `Generated/WorkingPractices_Binder.md` | Generated | Working Practices project context | New generated consumption artefact | Do not edit directly |

## Core application

1. Move these current issued files to `AIDE/Core/superseded/`:

   - `Core_Index_v2.md`
   - `Core_System_Design_v5.md`
   - `Core_System_Decisions_v4.md`

2. Copy the six files under `Core/` into `AIDE/Core/`.

3. Leave the existing Domain masters unchanged:

   - `Core_Domain_Design_v1.md`
   - `Core_Domain_Decisions_v1.md`
   - `AIDE_Domain_Standard_v1.md`

4. The supplied `Generated/Core_Binder.md` was generated using those unchanged Domain files plus
   the new Core/Bootstrap masters. After copying the masters, it may replace the Core project
   Binder/context copy.

5. Do not apply `Core_Bootstrap_Design_v1.md` or `Core_Bootstrap_Decisions_v1.md` from the earlier
   delivery package.

## Principles application

The known pre-change current Principles masters are v1.

1. Move current v1 issued masters to `AIDE/Principles/superseded/`:

   - `Principles_Index_v1.md`
   - `Principles_Brief_v1.md`
   - `Principles_Design_v1.md`
   - `Principles_Decisions_v1.md`

2. Copy all five files under `Principles/` into `AIDE/Principles/`.

3. Do not apply the v2 Principles files from the earlier delivery package; they were delivery
   candidates superseded before adoption by this current-baseline reconciliation.

4. Replace the project-context Binder with `Generated/Principles_Binder.md`.

5. `AIDE_Principles_Standard_v1.md` is now ready for inclusion in the next common Standards/Tools
   Bundle.

## Working Practices application

Working Practices is a new top-level project/master folder.

1. Create:

   ```text
   AIDE/Working Practices/
   ```

2. Copy all five files under `Working Practices/` into that folder.

3. The v1 Working Practices files from the earlier delivery package were unadopted candidates and
   should not be applied.

4. Use `Generated/WorkingPractices_Binder.md` as the initial project-context Binder.

5. `AIDE_WorkingPractices_Standard_v1.md` is ready for inclusion in the next common Bundle.

## What changed in the architecture

### Bootstrap

Core now owns:

```text
persistent platform bootstrap
        ↓
Bootstrap Profile (what / why / where)
        ↓
thin separate Bootstrap Contributions
        ↓
full material loaded when needed
```

Startup-required presence reuses Dependencies. Bootstrap may surface missing requirements but does
not deploy them.

No formal `Deployment Authority` role is introduced by Core. Permission/control remains with the
host administrator/environment/deployment process that actually owns host changes.

Future trusted automatic acquisition is left possible but not designed.

### Principles

Principles is independently deployable base reasoning/problem-solving guidance.

The old seed wording that Domains are always declared is replaced by authoritative-evidence
reasoning compatible with `AIDE_Domain@v1`.

### Working Practices

Working Practices is an independently deployable sibling top-level concern.

Its initial canonical Standard includes:

- Change Delivery Package;
- current owning-project baseline checks before cross-project master changes;
- coded-reference glossing;
- current/external fact verification;
- state-change truthfulness;
- selective architecture-decision surfacing;
- layered complex work; and
- durable handoff.

### Guidance Profiles

Principles and Working Practices are base Standards.

Organisation/group/team/user Guidance Profiles may Add, Refine or explicitly Override named base
guidance using small deltas. Do not fork the entire base Standard.

No separate generic Guidance Profile AIDE component is created yet.

## Next common Bundle pass

After this package is applied, the next step is the one requested by the user:

1. collect the **current Binders from every AIDE project**;
2. use those Binders as the source of current canonical published Standards/Tools;
3. rebuild one current common Standards/Tools Bundle from the current outcomes;
4. include at least the newly published:
   - `AIDE_Bootstrap@v1`
   - `AIDE_Domain@v1`
   - `AIDE_Principles@v1`
   - `AIDE_WorkingPractices@v1`
   plus the latest current Standards/Tools from all other project Binders;
5. do not carry an older Standard merely because it is present in the previous Bundle when a
   current Binder proves a newer one;
6. output the rebuilt Bundle as a generated consumption artefact, not an authoritative master;
7. replace the common Bundle in each project context manually for now.

This is a temporary manual distribution pass until the AI Deployment design is fully operational.

## Files not changed by this package

- Core Domain Design/Decisions/Standard.
- Documentation Methodology masters/Standard/Guide.
- Capabilities, Project Design, Build, AI Deployment or other project masters.

Their current Binders should be supplied to the later Bundle-build chat so the Bundle is assembled
from current published outcomes rather than assumptions.

## Transfer-only artefacts

The ZIP, this instructions file and `PACKAGE_HASHES.md` are transfer/application artefacts.

Do not add them to the Core, Principles or Working Practices master corpus or long-term project
context.

## State not claimed complete

Generating this package does **not** prove that:

- files were copied to master folders;
- previous versions were moved to `superseded/`;
- project contexts were replaced;
- the Bundle was regenerated;
- any runtime/platform bootstrap was installed; or
- any deployment occurred.

Those remain user/environment actions until observed.

---
References: Core_Bootstrap_Design_v2, Principles_Design_v3, WorkingPractices_Design_v2
