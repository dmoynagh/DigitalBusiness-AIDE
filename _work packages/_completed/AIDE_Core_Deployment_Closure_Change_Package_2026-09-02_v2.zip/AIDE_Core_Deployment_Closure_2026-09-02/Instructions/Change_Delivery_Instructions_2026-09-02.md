# Change Delivery Instructions — AIDE Core Build/Deployment Closure — 2026-09-02

## Purpose

Apply the confirmed Build Target/Profile and AI Deployment Set/output/delivery design as one
coordinated change across `AIDE/AI Deployment/`, `AIDE/Build/` and `AIDE/Capabilities/`.

This package establishes:

- reusable Build Target Profiles/Definitions;
- the concrete four-contribution `AIDE_Core` Build Target Profile;
- exact immutable `AIDE_Core@vN` Deployment Set releases;
- four final Deployment Outputs;
- Delivery Actions and independently reconcilable Target Adapters;
- desired/publication/platform/runtime state separation and verification assurance;
- the concrete marketplace and bundle publication destinations; and
- a refreshed generated Standards & Tools Bundle.

## 1. Apply to `AIDE/AI Deployment/` masters

Add as new current masters:

- `AIDeployment_SetRelease_Design_v1.md`
- `AIDeployment_TargetAdapter_Design_v1.md`
- `AIDeployment_AIDECore_Reference_v1.md`

Add the following current replacements, then move the corresponding earlier current masters to the
topic's `Superseded` location:

| Add current | Supersedes |
|---|---|
| `AIDeployment_Index_v6.md` | `AIDeployment_Index_v5.md` |
| `AIDeployment_Design_v6.md` | `AIDeployment_Design_v5.md` |
| `AIDeployment_Decisions_v6.md` | `AIDeployment_Decisions_v5.md` |
| `AIDeployment_Registry_Design_v2.md` | `AIDeployment_Registry_Design_v1.md` |
| `AIDeployment_OpenAI_Reference_v3.md` | `AIDeployment_OpenAI_Reference_v2.md` |
| `AIDE_Deployment_Standard_v6.md` | `AIDE_Deployment_Standard_v5.md` |
| `AIDE_Deployment_Tool_v6.md` | `AIDE_Deployment_Tool_v5.md` |

Replace the generated Binder:

- add `AIDeployment_Binder_v6.md` as current;
- move `AIDeployment_Binder_v5.md` to `Superseded`.

Keep `AIDE_DeploymentRegistry_Tool_v1.md` unchanged and current. It is embedded in the regenerated
Binder for complete consumption context but is not a replacement master in this package.

## 2. Apply to `AIDE/Build/` masters

Add the following current replacements, then move the corresponding earlier current masters to
`Superseded`:

| Add current | Supersedes |
|---|---|
| `Build_Index_v8.md` | `Build_Index_v7.md` |
| `Build_Design_v8.md` | `Build_Design_v7.md` |
| `Build_Decisions_v8.md` | `Build_Decisions_v7.md` |
| `AIDE_Build_Standard_v8.md` | `AIDE_Build_Standard_v7.md` |

Replace the generated Binder:

- add `Build_Binder_v8.md` as current;
- move `Build_Binder_v7.md` to `Superseded`.

Do not replace `AIDE_WorkPackage@v3`, the WorkPackage Design, Post-Build Design or
`AIDE_PublishBuildOutputTool@v1`; they remain unchanged and are included only inside the regenerated
Binder.

## 3. Apply to `AIDE/Capabilities/` Core masters

Add as new current masters:

- `Capabilities_BuildTargetProfile_Design_v1.md`
- `Capabilities_AIDECore_BuildTargetProfile_v1.md`

Add the following current replacements, then move the corresponding earlier current masters to
`Superseded`:

| Add current | Supersedes |
|---|---|
| `Capabilities_Index_v22.md` | `Capabilities_Index_v21.md` |
| `Capabilities_Brief_v13.md` | `Capabilities_Brief_v12.md` |
| `Capabilities_Overview_v19.md` | `Capabilities_Overview_v18.md` |
| `Capabilities_Design_v14.md` | `Capabilities_Design_v13.md` |
| `Capabilities_Decisions_v19.md` | `Capabilities_Decisions_v18.md` |
| `Capabilities_Capability_Design_v2.md` | `Capabilities_Capability_Design_v1.md` |
| `AIDE_Capability_Standard_v2.md` | `AIDE_Capability_Standard_v1.md` |
| `Capabilities_CapabilityBuild_Design_v3.md` | `Capabilities_CapabilityBuild_Design_v2.md` |
| `Capabilities_CapabilityBuild_Decisions_v3.md` | `Capabilities_CapabilityBuild_Decisions_v2.md` |
| `AIDE_CapabilityBuild_Standard_v3.md` | `AIDE_CapabilityBuild_Standard_v2.md` |

Replace the generated Core Binder:

- add `Capabilities_Binder_Core_v8.md` as current;
- move `Capabilities_Binder_Core_v7.md` to `Superseded`.

`Capabilities_Capability_Decisions_v1.md` remains unchanged/current and is embedded only for Binder
completeness.

## 4. Apply to `AIDE/Capabilities/` StandardsTools masters

Add the following current replacements, then move the corresponding earlier current masters to
`Superseded`:

| Add current | Supersedes |
|---|---|
| `Capabilities_Tools_Definition_v3.md` | `Capabilities_Tools_Definition_v2.md` |
| `Capabilities_Tools_Brief_v6.md` | `Capabilities_Tools_Brief_v5.md` |
| `Capabilities_Tools_Design_v6.md` | `Capabilities_Tools_Design_v5.md` |
| `Capabilities_BuildCapability_Tool_Design_v5.md` | `Capabilities_BuildCapability_Tool_Design_v4.md` |
| `AIDE_BuildCapability_Tool_v5.md` | `AIDE_BuildCapability_Tool_v4.md` |
| `Capabilities_CapabilityBuilder_Tool_Design_v3.md` | `Capabilities_CapabilityBuilder_Tool_Design_v2.md` |
| `AIDE_CapabilityBuilder_Tool_v3.md` | `AIDE_CapabilityBuilder_Tool_v2.md` |

Replace the generated partition Binder:

- add `Capabilities_Binder_StandardsTools_v5.md` as current;
- move `Capabilities_Binder_StandardsTools_v4.md` to `Superseded`.

All Standards masters and Update Capability Elements masters in this partition remain unchanged;
they are embedded only for Binder completeness.

## 5. Apply to `AIDE/Capabilities/` Runtime masters

Add the following current replacements, then move the corresponding earlier current masters to
`Superseded`:

| Add current | Supersedes |
|---|---|
| `Capabilities_Tags_Definition_v2.md` | `Capabilities_Tags_Definition_v1.md` |
| `Capabilities_Scope_Definition_v2.md` | `Capabilities_Scope_Definition_v1.md` |
| `Capabilities_Dependencies_Definition_v2.md` | `Capabilities_Dependencies_Definition_v1.md` |
| `Capabilities_Migration_Definition_v2.md` | `Capabilities_Migration_Definition_v1.md` |

These Definition replacements close the previously undelivered Registry seam. They do not advance
the Capability/Element semantic releases or replace the canonical Runtime Standards/Tools.

Replace the generated Runtime Binder:

- add `Capabilities_Binder_Runtime_v3.md` as current;
- move `Capabilities_Binder_Runtime_v2.md` to `Superseded`.

## 6. Apply to `AIDE/Capabilities/` Review masters

Add `Capabilities_Review_Definition_v2.md` as current and move
`Capabilities_Review_Definition_v1.md` to `Superseded`. This closes the same previously undelivered
Registry seam without changing the Review Capability/Element semantic releases.

Replace the generated Review Binder:

- add `Capabilities_Binder_Review_v5.md` as current;
- move `Capabilities_Binder_Review_v4.md` to `Superseded`.

The remainder of the Review corpus is unchanged and is embedded only for Binder completeness.

## 7. Replace generated Capabilities Binder map

- add `Capabilities_Binder_Set_Index_v3.md` as current;
- move `Capabilities_Binder_Set_Index_v2.md` to `Superseded`.

`Capabilities_Binder_Messaging_v5` remains unchanged/current.

The supplied Runtime v2 and Review v4 Binders were the actual current baselines. Earlier Core/Set
Index references to Runtime v3 and Review v5 described versions that had not been delivered. This
package now includes those missing Definition updates and regenerated Binders so the Index, Set map
and delivered files agree.

## 8. Replace the generated Standards & Tools Bundle

- add `AIDE_Bundle_StandardsTools_v8.md` as the current generated consumption Bundle;
- move `AIDE_Bundle_StandardsTools_v7.md` to `Superseded`.

The Bundle is derived/non-authoritative. The individual topic-owned masters above remain the source
of truth.

## 9. Post-application checks

1. Confirm each new Index identifies the matching current Standard/Tool versions.
2. Confirm the four new Binders and Bundle reproduce their manifests/hashes.
3. Confirm `AIDE_Core` resolves as Build Target Profile, output Tag and Deployment Set without
   collapsing those roles.
4. Confirm the initial four Outputs are Claude plugin, Claude bundle, ChatGPT bundle and OpenAI
   plugin, all sharing one exact `AIDE_Core@vN` release marker/digest.
5. Confirm the configured destinations are the separate Claude/OpenAI areas of
   `DigitalBusiness-AIDE-Marketplace` and
   `C:\Users\david\dev\repos\Documentation\DeployedBundles` with `superseded` for prior bundles.
6. Keep Review D on hold until application is complete and its baseline is refreshed; then restart
   Review D fresh rather than continuing the stale pre-redesign findings.

No Project Handoff documents are required: the current authoritative topic Binders supplied enough
context to apply the coordinated changes directly.
