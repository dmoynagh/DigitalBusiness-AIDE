# Core — Change Delivery Instructions — 2026-09-01

> Transfer/application artefact. Not an authoritative Core master.

## Purpose

Apply the final Review A Round 2 Core correction set produced from the current `Core_Binder_v2.md` baseline and the authorised `Core_ReviewA_R2_ChangeDelivery_Instructions_2026-09-01.md`. This delivery is intentionally narrow: inclusive Propagation Stop semantics plus deterministic implicit-Domain settings-host eligibility. No Review B, Build/Deployment, Documentation Methodology, Bootstrap, Index-contract, or common Standards/Tools Bundle work is included.

## Add / Replace Current — `AIDE/Core/`

Copy these files into the active Core master-folder root and treat them as Current:

| Add | Replaces Current | Action for replaced file |
|---|---|---|
| `Core_Index_v6.md` | `Core_Index_v5.md` | Move v5 to `AIDE/Core/_superseded/`. |
| `Core_System_Design_v9.md` | `Core_System_Design_v8.md` | Move v8 to `AIDE/Core/_superseded/`. |
| `Core_Domain_Design_v4.md` | `Core_Domain_Design_v3.md` | Move v3 to `AIDE/Core/_superseded/`. |
| `Core_Domain_Decisions_v4.md` | `Core_Domain_Decisions_v3.md` | Move v3 to `AIDE/Core/_superseded/`. |
| `AIDE_Domain_Standard_v4.md` | `AIDE_Domain_Standard_v3.md` | Move v3 to `AIDE/Core/_superseded/`. Canonical identity becomes `AIDE_Domain@v4`. |
| `Core_Binder_v3.md` | `Core_Binder_v2.md` | Move Binder v2 to `AIDE/Core/_superseded/`. Binder v3 remains generated/read-only. |

Do not edit the superseded files in place.

## Intentionally unchanged

Do not replace or reissue these current masters for this delivery:

- `Core_System_Decisions_v7.md`
- `Core_Index_Design_v2.md`
- `Core_Index_Decisions_v2.md`
- `AIDE_Index_Standard_v2.md`
- `Core_Bootstrap_Design_v3.md`
- `Core_Bootstrap_Decisions_v3.md`
- `AIDE_Bootstrap_Standard_v2.md`

They are included inside `Core_Binder_v3.md` as unchanged current sources but are not duplicated as standalone files in this Change Delivery Package.

## Binder / project-context changes

1. Replace `Core_Binder_v2.md` with `Core_Binder_v3.md` in the Core ChatGPT project context.
2. Remove stale Binder v2 context so only Binder v3 represents the current Core snapshot.
3. Keep the individual current master files as authority; do not edit Binder v3 directly.
4. Return/provide `Core_Binder_v3.md` to the Capabilities Review coordination context for Lead verification of Review A R2.

## Other affected sources/projects

- **Documentation Methodology:** no master or Binder change required. This pass records current conformance as `AIDE_DocumentationMethodology@v23` only on the reissued Core documents.
- **Capabilities Review coordination:** consume `Core_Binder_v3.md` for the planned Lead verification/Review A closure. No Capabilities master change is prescribed by this package.
- **Common Standards/Tools Bundle:** do **not** rebuild `AIDE_Bundle_StandardsTools` as part of this delivery. Runtime/build/deployment propagation remains later work after Review A closure.

## Package lifecycle

1. Stage `Core_ChangeDelivery_2026-09-01.zip` in `Documentation/_changeDeliveryPackages/`.
2. Apply the files/actions above.
3. Complete the planned Capabilities Lead verification.
4. When application/review is complete, move the ZIP to `Documentation/_changeDeliveryPackages/_completed/`.

## Result represented by this delivery

```text
Core R2 changes produced: yes
Replacement masters produced: yes
Core_Binder_v3 produced: yes
Core changes applied to repository: no (application step required)
Review A completed: no (Capabilities Lead verification remains)
```
