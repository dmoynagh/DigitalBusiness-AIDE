# Working Practices — Review B R2 Change Delivery Instructions

> **Delivery date:** 2026-09-01  
> **Scope:** Review B R2 closing clarification only  
> **Source:** `ProjectHandoff_ReviewB_R2_to_WorkingPractices.md`

## Purpose

Apply the accepted Review B R2 non-substantive clarification to the current Working Practices corpus.
The change makes the existing Project Handoff closure wording explicitly respect the current
Documentation Methodology OpenItems→WorkRegister routing rule. It introduces no new Handoff
mechanism, state, register, archive or lifecycle.

## What you need to do

1. In `Documentation/AIDE/Working Practices/`, add the new current masters:
   - `WorkingPractices_Index_v7.md`
   - `WorkingPractices_Design_v7.md`
   - `AIDE_WorkingPractices_Standard_v6.md`
2. Move the replaced current issues to the normal `_superseded/` location:
   - `WorkingPractices_Index_v6.md`
   - `WorkingPractices_Design_v6.md`
   - `AIDE_WorkingPractices_Standard_v5.md`
3. Leave these current masters unchanged:
   - `WorkingPractices_Brief_v5.md`
   - `WorkingPractices_Decisions_v6.md`
4. Replace the current generated Binder `WorkingPractices_Binder_v3.md` (or the locally named copy of
   that Binder) with `WorkingPractices_Binder_v4.md`; move the replaced Binder to `_superseded/`.
5. Replace the Working Practices project-context Binder with `WorkingPractices_Binder_v4.md`.
6. The R2 Project Handoff is transfer-only material. Once this delivery is applied/reconciled, remove
   it from active project context; do not register or archive it as a new Handoff mechanism.
7. After application/review is complete, move this Change Delivery ZIP from
   `Documentation/_changeDeliveryPackages/` to `Documentation/_changeDeliveryPackages/_completed/`.

## Exact Project Handoff closure wording introduced

```text
- remove that OpenItem only when reconciliation/incorporation is complete and any confirmed-but-undelivered consequence produced by that reconciliation has been routed to
  the destination WorkRegister under the current Documentation Methodology; and
```

This wording appears in both the current Design and canonical Standard.

## Resulting current set

- `WorkingPractices_Index_v7.md`
- `WorkingPractices_Brief_v5.md` — unchanged
- `WorkingPractices_Design_v7.md`
- `WorkingPractices_Decisions_v6.md` — unchanged
- `AIDE_WorkingPractices_Standard_v6.md`
- `WorkingPractices_Binder_v4.md` — generated consumption artefact

Formal capability identity remains `AIDE_WorkingPractices@v1`.

## Scope confirmation

No new Project Handoff DocType, lifecycle, archive/register, obligations ledger or other persisted
Handoff state was introduced. The clarification only cross-references the existing destination
OpenItems→WorkRegister semantics owned by Documentation Methodology.
