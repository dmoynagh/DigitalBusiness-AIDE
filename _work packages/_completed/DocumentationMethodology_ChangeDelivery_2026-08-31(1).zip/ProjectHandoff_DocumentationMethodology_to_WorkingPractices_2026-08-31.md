# Project Handoff — Documentation Methodology → Working Practices

> Transfer artefact. Not an authoritative corpus master.

## Confirmed ownership boundary

Documentation Methodology v20 now owns **document lifecycle semantics** and deliberately does not
own the physical repository/storage workflow used to realise them.

Working Practices may therefore own management-folder naming, file movement, staging/completion
folders, Binder placement/replacement and repository/external-archive handling without competing
with Documentation Methodology.

## Lifecycle semantics retained by Documentation Methodology

- **Current** — the issued authoritative version/instance resolved for normal current use.
- **Superseded** — an older issued version, or a document displaced/withdrawn without reaching an
  archival terminal disposition of its own.
- **Archived** — a document whose type-specific lifecycle reaches an archival terminal disposition;
  the terminal archival record is frozen except through the type's permitted correction route.
- Document versioning, type-specific completion/terminal rules and the `_Archived_{date}` filename
  marker remain Documentation Methodology concerns.
- Governed history must not be discarded merely to simplify the active repository/view.
- The Index must preserve the current register, dead-name/rehoming mappings and archived-history
  information needed to keep the corpus truthful/resolvable.
- Generated Binders/Bundles remain non-authoritative consumption artefacts assembled from
  authoritative masters.

## Physical/storage semantics relinquished

Documentation Methodology no longer prescribes:

- an active/master folder as the definition/location of Current;
- `superseded/`, `_superseded/`, `archived/` or `_archived/` as lifecycle-defining folders;
- movement rules between those folders;
- sweep/no-guarantee/cold-storage semantics for a particular folder;
- periodic repository-to-external-archive cadence;
- Change Delivery Package staging/completion folder structure;
- Binder physical placement, replacement or supersession workflow; or
- a default physical `assets/` holding folder.

## Constraints Working Practices must respect

A Working Practices implementation may use the proposed conventions:

```text
_superseded/
_archived/
Documentation/_changeDeliveryPackages/
Documentation/_changeDeliveryPackages/_completed/
```

and may periodically move history outside the active repository, provided it does not alter the
lifecycle meaning above or erase governed history/locator information required by the corpus.

Physical absence from the active AI context/repository must not be treated as proof that historical
material never existed. If history is externalised, the retained corpus records must remain truthful
about its existence and any locator/recovery information the environment requires.

Binder versioning/placement is now cleanly a Working Practices concern. Documentation Methodology
only requires that a Binder remain generated/non-authoritative and trace its exact source set (the
Binder manifest is the current mechanism).

## Authoritative updated source pointers

- `DocumentationMethodology_Design_v17.md`
- `DocumentationMethodology_Decisions_v18.md` — D20/D21
- `AIDE_DocumentationMethodology_Standard_v20.md` — identity `AIDE_DocumentationMethodology@v20`
- `DocumentationMethodology_Guide_v20.md`
- `DocumentationMethodology_Index_v5.md`
- Generated consumption artefact: `DocumentationMethodology_Binder_v1.md`

## Remaining cross-project consequences

1. Working Practices can now confirm and publish its underscore-prefixed management-folder and
   Change Delivery/Binder workflow conventions.
2. Its wording should state that folders **implement** Current/Superseded/Archived disposition; they
   do not define those lifecycle states.
3. External archival/sweep rules must preserve governed history and retained locator truth.
4. Binder version semantics (Binder issue version, independent from project/capability release) and
   replacement handling belong in Working Practices.
5. The common AIDE Standards/Tools Bundle and other runtime distributions should adopt
   `AIDE_DocumentationMethodology@v20` on their next normal bundle/build/deployment pass; this is a
   Build/Deployment consequence, not Working Practices ownership.
