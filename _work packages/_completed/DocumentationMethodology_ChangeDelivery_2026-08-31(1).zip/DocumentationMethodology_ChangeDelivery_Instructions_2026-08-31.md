# Documentation Methodology — Change Delivery Instructions — 2026-08-31

> Transfer/application artefact. Not an authoritative corpus master.

## Destination

Apply these changes to the Documentation Methodology project/master corpus at:

```text
AIDE/Document Methodology/
```

The lifecycle/storage semantics in the new v20 masters deliberately do not prescribe physical
folders. The handling steps below use the current AIDE Working Practices convention supplied with
this work; if that convention has not yet been installed, use the equivalent current project
handling while preserving the same lifecycle state.

## Replace Current masters

| New file | Replaces current master | Action |
|---|---|---|
| `DocumentationMethodology_Index_v5.md` | `DocumentationMethodology_Index_v4.md` | Install v5 as Current; v4 becomes Superseded. |
| `DocumentationMethodology_Design_v17.md` | `DocumentationMethodology_Design_v16.md` | Install v17 as Current; v16 becomes Superseded. |
| `DocumentationMethodology_Decisions_v18.md` | `DocumentationMethodology_Decisions_v17.md` | Install v18 as Current; v17 becomes Superseded. |
| `AIDE_DocumentationMethodology_Standard_v20.md` | `AIDE_DocumentationMethodology_Standard_v19.md` | Install v20 as Current canonical Standard; v19 becomes Superseded. |
| `DocumentationMethodology_Guide_v20.md` | `DocumentationMethodology_Guide_v19.md` | Install v20 as Current Guide; v19 becomes Superseded. |

Under the current Working Practices folder convention, move those five replaced issued masters to:

```text
AIDE/Document Methodology/_superseded/
```

Do not move them there because the folder defines their state; they are Superseded because the v20
issue replaced them. The folder is only the current physical implementation.

## Generated Binder

**Add/replace generated project-context artefact:**

```text
DocumentationMethodology_Binder_v1.md
```

This is the first independently versioned Documentation Methodology Binder. It assembles exactly the
five Current masters in this package. It is generated/read-only and is not an authoritative master.

Replace the previously loaded/generated Documentation Methodology Binder whose manifest contains:

```text
Index v4 / Design v16 / Decisions v17 / Standard v19 / Guide v19
```

If the prior generated Binder is retained, treat it as Superseded and place it according to the
current Working Practices Binder/superseded convention. Do not edit the Binder directly.

## Project-context change

Remove the prior Documentation Methodology Binder from this GPT Project context and add
`DocumentationMethodology_Binder_v1.md` so the project context matches the Current masters.

## Project Handoff

`ProjectHandoff_DocumentationMethodology_to_WorkingPractices_2026-08-31.md` is a transfer artefact.
Paste/provide it to the Working Practices project for its next substantive pass. Do **not** install
it as a Documentation Methodology master.

## Bundle / deployment consequence — not included in this package

Do not modify the common AIDE Standards/Tools Bundle as part of this package. On the next normal
bundle/build/deployment pass, replace the Documentation Methodology Standard member with:

```text
AIDE_DocumentationMethodology_Standard_v20.md
```

and update the bundle manifest/hash accordingly.

This package intentionally leaves broader Bundle reconciliation to its separate owning job.

## Change Delivery Package handling

Stage this ZIP in the current Working Practices Change Delivery location while applying/reviewing it:

```text
Documentation/_changeDeliveryPackages/
```

After all master/context/handoff actions above are complete, move the ZIP to:

```text
Documentation/_changeDeliveryPackages/_completed/
```

Those paths are operating conventions, not Documentation Methodology lifecycle definitions.

## Verification

After application, the Documentation Methodology Current register should read:

```text
Index v5
Design v17
Decisions v18
AIDE_DocumentationMethodology Standard v20
Guide v20
```

and the loaded Binder manifest should report the same five source versions.
