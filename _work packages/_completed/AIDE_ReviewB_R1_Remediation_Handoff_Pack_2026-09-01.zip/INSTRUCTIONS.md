# Review B R1 Remediation Handoff Pack — Instructions

This package contains transfer/reconciliation artefacts only. It does not itself change any
authoritative master.

## Files

- `ReviewB_R1_LeadDisposition_gpt-002.md`
  - paste into the existing Claude Review B chat after Claude's Round 1 response.
- `ProjectHandoff_ReviewB_R1_to_DocumentationMethodology.md`
  - paste into a new/current Documentation Methodology project chat.
- `ProjectHandoff_ReviewB_R1_to_WorkingPractices.md`
  - paste into a new/current Working Practices project chat.
- `ProjectHandoff_ReviewB_R1_to_ProjectDesign.md`
  - paste into a new/current Project Design project chat.
- `ProjectHandoff_ReviewB_R1_to_Build.md`
  - paste into a new/current Build project chat.
- `Capabilities_WIP_v8.md`
  - replace the current Capabilities WIP v7 checkpoint after you adopt this Review B R1
    disposition/checkpoint.

## Application order

1. Paste the Lead disposition into the existing Claude Review B chat.
2. Replace `Capabilities_WIP_v7` with `Capabilities_WIP_v8` in the Capabilities live context.
3. Run each Project Handoff against that owning project's current Binder/current masters.
4. Each owning project should return its normal Change Delivery Package/instructions (or a
   no-change result where appropriate).
5. Apply those packages in their owning master folders and replace/regenerate their current Binders.
6. Return the new current Binders to the Capabilities Review B Lead chat.
7. Do not start Review B Round 2 until all accepted remediation relevant to R2 is represented by
   the current source set.
8. Round 2 will be `Inspect / High / Full`.
9. Do not begin Review C before Review B completes or is explicitly escalated.

## State truthfulness

- Handoffs prepared != destination changes applied.
- Change Delivery Package created != applied.
- New Binder generated != loaded into project context unless actually replaced.
- Review B remains `Continuing`, not `Complete`.
