# Project Handoff — Review B R1 remediation → Working Practices

> Transfer/reconciliation artefact. Not an authoritative corpus master.

## Reason for the handoff

AIDE Architecture Peer Review Review B — Documentation/work-state model — completed Round 1 as
`Robust / High / Full` with Claude Opus 5.

The Lead accepts targeted Working Practices changes. Reconcile this handoff against the **current
Working Practices Binder/current masters** and issue the smallest coherent substantive pass.

## Accepted changes owned or co-owned here

### RB-R1-F4 — remove duplicated normative ownership

Preserve the existing declared split:

```text
Documentation Methodology
  → WIP / Working / OpenItems / WorkRegister semantics, lifecycle, authority and Binder/live-state
    semantic treatment

Working Practices
  → when/how active state is persisted, checkpointed, transferred, synchronised, verified and
    handled operationally
```

Keep Working Practices as the normative owner of:
- practical checkpoint triggers;
- preservation-first behaviour;
- WIP currency/transfer verification;
- physical/repository handling conventions;
- practical handoff workflow.

Where Working Practices currently restates Documentation Methodology semantic rules (for example
Binder exclusion/lifecycle/routing meaning), replace the duplicate normative wording with a
reference or a clearly bounded non-normative summary.

Do not broaden this pass into redesign of standalone deployment/dependency architecture.

Correct stale in-body Documentation Methodology version references encountered in this material
where they read as current instruction, but do not establish a general citation-version policy
(Review C owns that later question).

### RB-R1-F6 — received Project Handoff must have a live holder if not reconciled immediately

Project Handoff remains transfer material, not a new DocType.

On destination receipt:
- if the destination reconciles/incorporates the Handoff in the same pass, no extra live register
  entry is required;
- if incorporation is deferred beyond the current pass/context, create one concise OpenItem such as
  `Reconcile Project Handoff <identity/source>`;
- remove that OpenItem when incorporation/reconciliation is complete;
- remove the transfer material from active context once its purpose is complete.

This is operational use of the existing OpenItems semantics, not a new Handoff lifecycle system.

## Explicit non-changes

Do not create:
- Project Handoff DocType;
- Handoff archive/register;
- another cross-project obligations ledger.

Preserve:
- destination current Binder/masters as baseline;
- Handoff non-authority;
- Handoff vs Change Delivery distinction;
- normal ownership-preserving flow:
  originating project → Project Handoff → owning project → authoritative update.

## Required output

Run one normal substantive Working Practices pass against the current masters.

Update Design/Decisions/Standard/Index/Brief only where the accepted changes require it and regenerate
the current Working Practices Binder.

Return a normal Change Delivery Package with concise application instructions.

State:
- files changed;
- findings implemented;
- resulting Binder name/version;
- any remaining cross-owner dependency for Review B Round 2.
