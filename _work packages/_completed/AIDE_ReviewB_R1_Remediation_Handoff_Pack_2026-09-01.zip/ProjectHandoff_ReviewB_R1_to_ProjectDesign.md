# Project Handoff — Review B R1 remediation → Project Design

> Transfer/reconciliation artefact. Not an authoritative corpus master.

## Reason for the handoff

AIDE Architecture Peer Review Review B — Documentation/work-state model — completed Round 1 as
`Robust / High / Full` with Claude Opus 5.

The Lead accepts a refinement to the WorkRegister boundary. Reconcile this handoff against the
**current Project Design Binder/current masters**.

## Accepted Project Design change

### RB-R1-F1 — Project Design owns a mandatory producer rule, not the whole WorkRegister admission boundary

Preserve the hard Design consequence guarantee:

> After each substantive confirmed Design change, identify material downstream consequences. If a
> consequence is not fully delivered in the same pass, create/update the owning top-level topic's
> WorkRegister.

This remains mandatory and load-bearing.

Refine wording that currently defines WorkRegister itself as only the
`undelivered-design-consequence ledger`.

The general Documentation Methodology type is being clarified as:

> WorkRegister holds confirmed work owed by the owning top-level topic and not yet fully delivered.

Project Design therefore owns the Design→WorkRegister producer rule and its reconciliation
requirements, while Documentation Methodology owns the general WorkRegister admission/type
semantics.

Consequences:
- Project Design must not imply that non-Design committed work is invalid in WorkRegister;
- Project Design should continue to say WorkRegister is not a generic backlog;
- unresolved ideas/possible work remain outside WorkRegister;
- a WorkPackage may still be directly defined where no register item is needed.

### Return/reconciliation wording

Align return wording with the accepted Review B clarification:
- if a mapped Outcome is received and reconciliation cannot be completed in the same uninterrupted
  step, preserve a compact `Returned — reconciliation pending` state in the owning register before
  leaving the context;
- detailed evidence remains in Outcome;
- Project Design/director, not Build, closes the obligation.

No new mechanism is required.

## Explicit non-changes

Preserve:
- Design as authoritative current model;
- Decisions as reasoning/history, not downstream input;
- hard no-third-state consequence rule;
- WorkRegister→WorkPackage many-to-many mapping;
- Build does not close WorkRegister;
- completed register rows are removed after reconciliation.

## Required output

Run one normal substantive Project Design pass against the current masters.

Update Design, Decisions and canonical Standard together where required, plus Index only if current
registration/reference facts need change, and regenerate the current Project Design Binder.

Return a normal Change Delivery Package with concise application instructions.

State:
- files changed;
- exact F1 refinement implemented;
- resulting Binder name/version;
- any unresolved seam requiring Documentation Methodology coordination.
