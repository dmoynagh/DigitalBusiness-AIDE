# Project Handoff — Review B R1 remediation → Build / WorkPackage

> Transfer/reconciliation artefact. Not an authoritative corpus master.

## Reason for the handoff

AIDE Architecture Peer Review Review B — Documentation/work-state model — completed Round 1 as
`Robust / High / Full` with Claude Opus 5.

The Lead preserves the current Build/Outcome ownership boundary and accepts one targeted
WorkPackage mapping clarification.

Reconcile this handoff against the **current Build Binder/current WorkPackage masters**.

## Accepted change

### RB-R1-F8 — deterministic-enough coverage when one WorkRegister obligation is split

Preserve the existing many-to-many model:
- one WorkPackage may cover portions of several WorkRegister items;
- one WorkRegister item may require several WorkPackages;
- WorkRegister mapping is traceability, not a substitute for a self-contained WorkPackage.

Where one WorkRegister obligation is deliberately split across multiple WorkPackages:
- the source obligation's required changes must be independently identifiable, normally as an
  enumerated/bulleted set supplied by the owner;
- WorkPackage `Covers` must identify the exact portions of that obligation this package claims;
- equivalent clear prose is valid when unambiguous;
- do not introduce structured sub-obligation identifiers unless later evidence proves necessary.

On Outcome return, preserve current per-obligation result/evidence/remaining-work reporting.

## Boundary explicitly preserved

No Build change is authorised that would:
- let Build close the source WorkRegister;
- move detailed Outcome evidence into WorkRegister;
- make WorkRegister references replace WorkPackage Objective/Scope/Inputs/Outputs/Acceptance;
- merge WorkPackage and WorkRegister; or
- remove/fold Outcome as an independent live return record.

The accepted Review B F5/F7 corrections are owner-side WorkRegister reconciliation clarifications,
not a transfer of register authority to Build.

## Required output

Run one normal substantive Build/WorkPackage pass if the current masters require wording changes to
make the coverage rule explicit.

Update only the minimum Build/WorkPackage Design/Decisions/Standard sources required and regenerate
the current Build Binder.

If the current WorkPackage contract already fully establishes the accepted rule, return a
no-change/clarification result with exact evidence rather than reissuing files unnecessarily.

If changed, return a normal Change Delivery Package with concise application instructions.

State:
- whether a master change was required;
- files changed, if any;
- how `Covers` now handles split obligations;
- resulting Binder name/version, if changed.
