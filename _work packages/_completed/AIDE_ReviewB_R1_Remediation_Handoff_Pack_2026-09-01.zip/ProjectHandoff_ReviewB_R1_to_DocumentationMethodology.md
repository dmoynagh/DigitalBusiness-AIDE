# Project Handoff — Review B R1 remediation → Documentation Methodology

> Transfer/reconciliation artefact. Not an authoritative corpus master.

## Reason for the handoff

AIDE Architecture Peer Review Review B — Documentation/work-state model — completed Round 1 as
`Robust / High / Full` with Claude Opus 5.

The Lead disposition accepts targeted Documentation Methodology changes. The overall architecture
is preserved: no state mechanism is being removed or merged in Review B.

Reconcile this handoff against the **current Documentation Methodology Binder/current masters**.
Treat the destination's current corpus as authoritative. Apply the smallest coherent substantive
pass that implements the accepted findings below.

Do not broaden into Review C / Dependencies policy.

## Accepted changes owned or co-owned here

### RB-R1-F1 — WorkRegister admission semantics

Clarify the general WorkRegister type/admission rule as:

> WorkRegister holds confirmed work owed by the owning top-level topic and not yet fully delivered.

This is broader than Design consequences but narrower than a generic backlog:
- include genuinely committed/owed work;
- exclude ideas, possible future work, unconfirmed findings and unresolved matters still requiring
  judgment;
- OpenItems remains the home for unresolved live attention.

Preserve the hard Design consequence rule as a mandatory subset:
- every confirmed Design change with an undelivered downstream consequence must create/update
  WorkRegister;
- this is a guaranteed producer rule, not the complete WorkRegister admission definition.

Align Design/Decisions/Standard/Guide wording so the general type semantics are owned here and do not
conflict with Project Design's producer rule.

### RB-R1-F2 — WIP per-thread exit

Preserve one current WIP series per top-level topic.

Add explicit per-thread lifecycle:
- when an `Active thread — ...` section's useful material is safely routed to its proper owners,
  remove that thread from the next WIP checkpoint;
- whole-file withdrawal/disposal is the case where no active continuation thread remains;
- routed material must not accumulate indefinitely beside active continuation state.

Keep WIP non-authoritative and temporary duplication-safe.

### RB-R1-F3 — Working discoverability

Working is intentionally outside the normal Binder but does not have a locator derivable from the
top-level-topic name.

Require a version-agnostic Working-series locator in the topic Index `Live state` section when a new
Working series is issued.

Constraints:
- Working version increments do not require Index updates;
- Working remains outside the normal Binder;
- remove/withdraw the live-state locator when the Working series ceases to be live;
- do not generalise this into a live-state manifest for WIP/OpenItems/WorkRegister.

### RB-R1-F4 — Documentation Methodology / Working Practices owner seam

Keep Documentation Methodology normative ownership of:
- WIP/Working/OpenItems/WorkRegister semantic meanings;
- lifecycle/routing meanings;
- authority/non-authority boundaries;
- Binder/live-state semantic treatment.

Operational checkpoint timing, practical transfer/sync and file/repository handling belong to
Working Practices.

Remove or convert operational trigger/checkpoint handling duplicated here into a reference/brief
non-normative explanation where needed. Coordinate wording with the Working Practices handoff.

Do not erase useful explanatory material merely to remove identical wording; the goal is one
normative owner per rule.

### RB-R1-F5 — returned but unreconciled WorkPackage state

Clarify WorkRegister reconciliation semantics so that, when a mapped Outcome is received and full
owner reconciliation is not completed in the same uninterrupted step, the existing package/action
mapping or equivalent compact register state first records:

`Returned — reconciliation pending`

If reconciliation is immediate, no ceremonial intermediate persisted state is required.

This marker must not copy execution evidence.

### RB-R1-F7 — returned result means compact reconciliation state

Clarify `returned result` in open WorkRegister rows.

Retain only:
- current/terminal WorkPackage status;
- stable WorkPackage/Outcome reference;
- concise returned result where useful; and
- remaining obligation/blocker.

Detailed evidence remains owned by WorkPackage Outcome and is referenced, not copied.

### RB-R1-F8 — split obligation entry depth

Where one WorkRegister obligation is deliberately split across multiple WorkPackages, require its
required changes to be independently identifiable, normally as an enumerated/bulleted set.

Coordinate with Build/WorkPackage so each `Covers` mapping identifies the exact portions claimed.

Do not introduce structured sub-obligation IDs.

### RB-R1-F9 — OpenItem negative conclusion

Clarify closure where an OpenItem resolves to no change.

Do not preserve a tombstone merely because the row existed.

Where the negative conclusion and reason are material and could credibly be re-raised, preserve that
conclusion in Decisions (or another genuinely proper durable owner) before removing the OpenItem.
Otherwise remove it with no durable history.

### RB-R1-F10 — concrete stale in-body references only

During this pass, correct concrete stale in-body capability-version references that otherwise read
as current executable instructions.

Do **not** establish a new general policy for versioned in-body capability references. That general
question is deferred to Review C / Dependencies.

## Explicit non-changes

Preserve:
- WIP as non-authoritative;
- Working as a distinct type;
- OpenItems and WorkRegister as distinct registers for Review B;
- live-only/no-tombstone register semantics;
- stable Binder exclusion of WIP/Working/OpenItems/WorkRegister;
- Design/Decisions separation;
- WorkPackage/Outcome boundaries.

Do not create:
- live-state manifest;
- closed-items archive;
- Project Handoff DocType;
- structured sub-obligation IDs.

## Required output

Run one normal substantive Documentation Methodology pass against the current masters.

Update Design, Decisions, Standard, Guide and Index together wherever the accepted semantic changes
require it, and regenerate the current Documentation Methodology Binder.

Return a normal Change Delivery Package with concise application instructions.

In the return, identify:
- files changed;
- accepted finding(s) implemented;
- any finding not fully implementable from current authority;
- the resulting Binder name/version; and
- whether any cross-owner issue remains for Review B Round 2.
