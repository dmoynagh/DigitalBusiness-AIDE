# Project Design — Review B R1 Change Delivery Instructions — 2026-09-01

## Purpose

Apply the accepted Review B Round 1 F1 refinement to the current Project Design corpus as one
substantive pass. The change preserves the hard Design consequence guarantee while correcting the
ownership boundary: Project Design owns the mandatory Design→WorkRegister producer/reconciliation
rule; Documentation Methodology owns the general WorkRegister type/admission semantics.

## Apply to `AIDE/Project Design/`

### Replace Current

Add these files to the current Project Design master folder and replace the corresponding v2
masters:

- `ProjectDesign_Index_v3.md` — replaces `ProjectDesign_Index_v2.md`.
- `ProjectDesign_Design_v3.md` — replaces `ProjectDesign_Design_v2.md`.
- `ProjectDesign_Decisions_v3.md` — replaces `ProjectDesign_Decisions_v2.md`.
- `AIDE_ProjectDesign_Standard_v3.md` — replaces `AIDE_ProjectDesign_Standard_v2.md` and changes the
  canonical identity/current release to `AIDE_ProjectDesign@v3`.

Move the replaced v2 masters to `_superseded/` under the normal repository convention.

### Add live state

Add:

- `ProjectDesign_WorkRegister_v1.md`

This is a live-state document, not part of the stable Binder. It records the concrete downstream
obligation created by this pass: the current temporary `AIDE_Bundle_StandardsTools_v5` still embeds
`AIDE_ProjectDesign@v2` and must be rebuilt through the normal owning Build/deployment/bundle route.
Remove the WorkRegister row after that outcome is verified/reconciled.

### Replace generated Binder

Add:

- `ProjectDesign_Binder_v2.md`

It replaces `ProjectDesign_Binder_v1.md`. Move Binder v1 to `_superseded/`. Replace the Project
Design Binder loaded into AI project context with Binder v2. Do not add the WorkRegister to the
stable Binder; load it separately when managing current obligations.

## Exact Review B F1 refinement implemented

1. Preserved the hard rule: after every substantive confirmed Design change, identify material
   downstream consequences and either fully deliver each in the same pass or record/update the
   owning top-level topic's WorkRegister.
2. Made that producer guarantee explicit `Requirement` weight in the canonical Standard.
3. Removed the implication that Project Design defines the whole WorkRegister admission boundary.
   Documentation Methodology owns the general type/admission semantics; confirmed non-Design work
   is not invalid merely because it was not produced by Project Design.
4. Preserved the non-backlog boundary: unresolved ideas/possible work remain outside WorkRegister.
5. Preserved direct WorkPackage definition where no register item is needed.
6. Preserved Design as authoritative current state, Decisions as reasoning/history, the hard
   no-third-state Design-consequence rule, many-to-many WorkRegister→WorkPackage mapping, Build not
   closing WorkRegister, and removal of completed rows after reconciliation.
7. Added the accepted return seam: when a mapped Outcome is received but cannot be reconciled in
   the same uninterrupted step, persist `Returned — reconciliation pending` plus an Outcome pointer
   before leaving the context; keep detailed evidence in Outcome; the directing owner later closes.

## Documentation Methodology coordination

Current `AIDE_DocumentationMethodology@v21` already recognises WorkRegister as confirmed work/
consequences not yet fully delivered, but some v21 wording still describes the type primarily as
confirmed downstream consequences. Review B's accepted Documentation Methodology clarification
should complete the general type/admission wording there. This does not block Project Design v3;
Project Design v3 deliberately defers the general admission contract to Documentation Methodology.

## Intentionally not changed

- `AIDE_Bundle_StandardsTools_v5.md` is not edited in this Project Design package; its required
  rebuild is tracked in `ProjectDesign_WorkRegister_v1.md`.
- No Build, WorkPackage, Documentation Methodology or other project masters are modified here.
- No historical Decision entry is rewritten; D12 explicitly refines the boundary of historical D7.
