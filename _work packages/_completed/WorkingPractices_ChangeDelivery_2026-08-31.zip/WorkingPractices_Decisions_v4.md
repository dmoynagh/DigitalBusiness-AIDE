# Working Practices — Decisions

> **Version 4** (2026-08-31). Preserves existing history and records the fuller Project Handoff
> trigger, ownership, contents and destination-reconciliation contract.
>
> Created: 2026-08-31 | Last modified: 2026-08-31

## D1 — Working Practices is a top-level AIDE topic

**Decision.** Working Practices is a sibling of Principles, Core, Project Design, Build,
Capabilities and other principal AIDE concerns.

**Reason.** It governs practical AI/user collaboration across work types and output forms.

## D2 — Working Practices is independently deployable

**Decision.** `AIDE_WorkingPractices@v1` is usable without full AIDE.

**Reason.** General AI sessions can benefit from working conventions without development-specific
context.

## D3 — Working Practices is base guidance

**Decision.** The canonical Standard supplies portable defaults rather than one user/team's final
customised behaviour.

## D4 — Guidance Profiles provide deltas

**Decision.** Organisation/group/team/user Profiles may Add, Refine or explicitly Override named
Working Practices without copying/forking the base Standard.

## D5 — Specialised owners retain semantics

**Decision.** Working Practices may require the AI to communicate/hand off specialised state but
does not redefine lifecycle, deployment, dependency, migration, Domain or other owned semantics.

## D6 — Material multi-file handoff uses a Change Delivery Package

**Trigger / problem.** Multi-file and cross-project outputs leave the user reconstructing file
placement, supersession, Binder/context and follow-up actions from conversation.

**Decision.** Deliver one package containing the created/changed deliverables plus concise
application instructions.

**Alternative considered.** Provide files individually and explain them conversationally. Rejected
for material change sets because the conversation is not a durable application manifest and steps
are easily missed.

## D7 — Package creation does not imply application

**Decision.** A Change Delivery Package is a transfer artefact; generation does not mean its
changes were applied.

## D8 — Trivial one-file output does not require package ceremony

**Decision.** Apply Change Delivery proportionately based on complexity/risk.

## D9 — Preserve operational seed behaviours from Principles

**Decision.** Coded-reference glossing, verification before assertion and no-silent-state-change
behaviour remain as Working Practices rather than being lost during Principles separation.

## D10 — Architecture decisions are surfaced selectively

**Decision.** Routine/reversible choices are handled autonomously; genuinely architecture-shaping
choices expose recommendation, rationale, alternative and consequence.

## D11 — Layered work is a Working Practice backed by Principles

**Decision.** Complex work establishes compact intent/model layers before deep elaboration.

## D12 — Durable handoff is required when substantial work moves

**Decision.** Cross-project/session/environment handoffs preserve authoritative inputs, confirmed
decisions, remaining work and integration instructions.

**Consequence.** Handoff summaries are normally transfer-only and should not become stale competing
sources beside adopted masters.

## D13 — Cross-project master changes use the owner's current baseline

**Trigger / problem.** A cross-project change package was prepared from an earlier Core/DocMeth
state while parallel work subsequently advanced Domain integration and Documentation Methodology.

**Alternatives considered.**

- Trust the earlier handoff snapshot and let the destination reconcile conflicts later. Rejected
  because it creates avoidable stale-version collisions.
- Always require every master file individually before doing cross-project work. Rejected because a
  current generated Binder is specifically intended to provide a coherent read-only corpus source.

**Decision.** Before issuing cross-project master changes, use the owning project's current Binder
or current masters when reasonably available.

**Consequence.** The destination's current state is the baseline; generated Binders are never edited
directly, and the changed masters are used to regenerate them afterward.

## D14 — Project Handoff is the named cross-project form of durable handoff

**Trigger / problem.** WP8 already requires durable transfer when substantial work moves between
projects, sessions, environments or owners, but cross-project work lacked a concise shared name and
an explicit lifecycle. As a result, useful reasoning could either remain trapped in the originating
conversation or persist as stale context beside the destination's authoritative sources.

**Alternatives considered.**

- Create Project Handoff as a wholly separate Working Practice. Rejected because the underlying
  behaviour is already the cross-project case of WP8 and a second mechanism would duplicate the
  same preservation/lifecycle rules.
- Treat every cross-project conversation or transfer as a Project Handoff. Rejected because routine
  chatter and already-authoritative information do not justify transfer artefacts.

**Decision.** **Project Handoff** is the named cross-project form of WP8. It transfers material
knowledge, reasoning, decisions, implications and authoritative source pointers from an originating
project to the project that owns or should act on them. Use it where the transferred knowledge would
materially help the owning project make or understand its next decision.

**Consequences.** The destination reconciles the Handoff against its current Binder/masters before
changing authoritative state, incorporates useful content into its own authoritative records, and
normally removes the Handoff from active context once that transfer is complete. The AI should
proactively suggest or produce a Project Handoff when material work clearly creates a consequence
owned by another project.

## D15 — Project Handoff and Change Delivery Package remain distinct

**Trigger / problem.** Existing Change Delivery language used the generic word “handoff”, while the
newly named Project Handoff solves a different problem. Without an explicit distinction, a
knowledge-only Project Handoff could incorrectly trigger file-packaging ceremony, or a file package
could be mistaken for preservation of design reasoning.

**Decision.** Keep the two mechanisms separate:

```text
Project Handoff
  → transfers knowledge/reasoning/decisions/implications/source pointers

Change Delivery Package
  → transfers concrete created/changed files plus application instructions
```

They may be used together. A Project Handoff may contain no changed files; a Change Delivery
Package may carry or point to a Project Handoff when both are needed.

**Consequence.** WP1 language uses “cross-project change set” rather than “cross-project handoff” so
Project Handoff does not accidentally become a packaging trigger.

## D16 — Project Handoff clarification remains within AIDE_WorkingPractices@v1

**Decision.** Keep the formal capability identity `AIDE_WorkingPractices@v1` and reissue the
canonical Standard as document version 2 rather than creating a new capability release.

**Reason.** This pass names and sharpens an already-established v1 durable-handoff behaviour and
removes an ambiguity with Change Delivery; it does not require consumer-state migration or introduce
a new independent mechanism. Document issue version and capability release identity remain distinct.

**Consequence.** `AIDE_WorkingPractices_Standard_v1.md` becomes superseded by
`AIDE_WorkingPractices_Standard_v2.md`, while the published capability identity remains
`AIDE_WorkingPractices@v1`.

## D17 — Project Handoff has a material-knowledge trigger and compact transfer contract

**Trigger / problem.** The initial named form established in D14 identifies when cross-project
knowledge matters, but the operational contract must also make Handoffs recognisable from natural
work and useful without becoming conversation transcripts or copied mini-corpora.

**Decision.** Use or suggest a Project Handoff when knowledge developed in one project would
materially help the owning project make, understand or implement its next decision. A Handoff
proportionately carries the reason for transfer, material reasoning/context, destination-relevant
confirmed decisions, important alternatives/constraints/trade-offs, implications, unresolved or
deferred items, authoritative source pointers, proposed-versus-confirmed state, expected destination
action, and important non-goals/boundaries.

Conversational **Handoff** is acceptable shorthand where the cross-project destination/context is
obvious. Routine chatter and information already fully represented by authoritative sources do not
justify a Project Handoff.

**Consequence.** The AI can recognise cross-project ownership consequences during ordinary work,
proactively suggest a Project Handoff, and produce one when requested without needing a separate
mechanism or document type.

## D18 — Cross-project ownership defaults to Handoff, not remote master editing

**Trigger / problem.** WP2 permits safe cross-project master changes when such changes are actually
authorised, but discovery of a consequence in one project does not itself confer authority to
modify another project's authoritative corpus. Without the distinction, Project Handoff could be
undermined by direct editing based on originating-project assumptions.

**Decision.** The normal ownership-preserving flow is:

```text
originating project
→ Project Handoff
→ owning project
→ authoritative update
```

A Project Handoff never overrides the destination's current authoritative state. The destination
reconciles against its current Binder/masters, surfaces genuine conflict, incorporates useful
content into its own authoritative records, and normally removes the Handoff from active context
once its purpose is complete.

Where a separate task or authority explicitly requires cross-project master changes, D13/WP2 still
applies and current owner state must be obtained before those changes are issued.

**Consequence.** Ownership is preserved without weakening the existing current-baseline safeguard.

## D19 — Fuller Project Handoff wording is another document issue, not a capability release

**Decision.** Preserve formal capability identity `AIDE_WorkingPractices@v1` and reissue the
canonical Standard as document version 3.

**Reason.** This pass completes the operational expression of the already-confirmed WP8/D14 model.
It introduces no new independent capability mechanism and requires no consumer-state migration.
The earlier document-v2 delivery was issued but superseded before adoption into the project's
Current masters.

**Consequence.** The intended Current Standard after this delivery is
`AIDE_WorkingPractices_Standard_v3.md`; capability identity remains `AIDE_WorkingPractices@v1`.

---
Dependencies: !AIDE_DocumentationMethodology@v19, WorkingPractices_Design_v4
References: Principles_Decisions_v3
