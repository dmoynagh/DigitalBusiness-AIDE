# Working Practices — Change Delivery Instructions

> **Change Delivery:** 2026-08-31 — Project Handoff operational contract
>
> This document is a transfer/application artefact, not a master document.

## Result

The current authoritative Working Practices Binder (Index/Brief/Design/Decisions v2 and Standard
v1) has been reconciled against the additional Project Handoff transfer context.

No conflict was found with the current project model. The change keeps **Project Handoff** as the
named cross-project form of WP8 durable handoff and now makes its operational contract explicit:

- formal definition and conversational `Handoff` shorthand;
- material-knowledge trigger/test;
- proactive AI suggestion behaviour;
- proportionate Handoff contents;
- destination reconciliation/lifecycle;
- cross-project ownership rule;
- relationship between that ownership rule and separately authorised WP2 cross-project editing; and
- explicit distinction from Change Delivery Package.

The formal capability identity remains `AIDE_WorkingPractices@v1`. The canonical Standard is
reissued as document version 3.

## Earlier in-chat delivery

An earlier Change Delivery in this chat issued intermediate proposed versions:

- `WorkingPractices_Index_v3.md`
- `WorkingPractices_Design_v3.md`
- `WorkingPractices_Decisions_v3.md`
- `AIDE_WorkingPractices_Standard_v2.md`

That package was superseded before adoption into the project's Current masters. **Do not apply that
earlier package.** This package is the replacement delivery.

The version numbers advance because the intermediate files had already been issued in-chat even
though they were not applied to the project.

## Apply to `AIDE/Working Practices/`

| Action | File | Destination / consequence |
|---|---|---|
| Replace Current | `WorkingPractices_Index_v4.md` | active Working Practices master folder; replaces current `WorkingPractices_Index_v2.md` |
| Replace Current | `WorkingPractices_Design_v4.md` | active Working Practices master folder; replaces current `WorkingPractices_Design_v2.md` |
| Replace Current | `WorkingPractices_Decisions_v4.md` | active Working Practices master folder; replaces current `WorkingPractices_Decisions_v2.md` |
| Replace Current | `AIDE_WorkingPractices_Standard_v3.md` | active Working Practices master folder; replaces current `AIDE_WorkingPractices_Standard_v1.md`; published identity remains `AIDE_WorkingPractices@v1` |
| Replace generated Binder | `WorkingPractices_Binder.md` | Working Practices project context / Binder location after the masters above are installed |

`WorkingPractices_Brief_v2.md` is intentionally unchanged and remains Current.

## Move current masters to `superseded/`

After the new Current masters are installed, move these currently installed issued versions to the
Working Practices `superseded/` folder:

- `WorkingPractices_Index_v2.md`
- `WorkingPractices_Design_v2.md`
- `WorkingPractices_Decisions_v2.md`
- `AIDE_WorkingPractices_Standard_v1.md`

Do not archive or delete them; they are superseded issued history.

The intermediate v3/v2 files from the earlier unadopted delivery do not need to be installed into
the master folder merely to preserve a continuous Current sequence. They were issued transfer
outputs and are recorded as superseded-before-adoption in the new Index/Decisions.

## Binder / project-context change

Replace the old generated `WorkingPractices_Binder.md` with the Binder supplied in this package.
The Binder is generated/read-only and must not be edited as a master.

If the Working Practices project context also contains individual superseded master files, remove
those old versions from active context after the new Binder/current masters are in place unless a
specific historical purpose requires them.

## Cross-project / deployment consequence — Project Handoff

The supplied common AIDE Standards/Tools Bundle v3 does not contain the Working Practices Standard.
Do **not** edit that Bundle from this project.

Carry this Project Handoff to the project/process that owns the next common Bundle/deployment
refresh:

> **Why:** Working Practices has completed the Project Handoff operational contract.
>
> **Confirmed state:** The intended Current canonical Standard is
> `AIDE_WorkingPractices_Standard_v3.md`, formal capability identity
> `AIDE_WorkingPractices@v1`.
>
> **Destination consequence:** The next applicable common Standards/Tools Bundle or standalone
> Working Practices deployment should consume Standard document v3 and replace any earlier Working
> Practices Standard issue present there.
>
> **Boundary:** This Handoff does not authorise Working Practices to edit another project's Bundle
> masters. The owning project should reconcile against its current Bundle/source state first.
> Bundle generation also does not establish deployment; target state must be verified separately
> under AI Deployment.

This Handoff transfers the consequence/context only. No Bundle or Deployment change is applied by
this package.

## Intentionally unchanged / not performed

- `WorkingPractices_Brief_v2.md` — no change required.
- Core masters — not edited.
- Principles masters — not edited.
- Documentation Methodology masters — not edited.
- Common AIDE Standards/Tools Bundle — not edited in this package.
- Deployment targets — not changed or verified by this package.

## State of this delivery

These files have been **created** as the replacement reconciled Change Delivery Package. Their
presence here does not establish that they have been copied into the master folder, added to project
context, bundled, deployed, or verified in a runtime target.
