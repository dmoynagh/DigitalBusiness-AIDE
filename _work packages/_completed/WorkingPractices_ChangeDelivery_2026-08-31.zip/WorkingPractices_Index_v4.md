# Working Practices — Index

> **Version 4** (2026-08-31). Registers the fuller Project Handoff operational contract and the
> resulting Design/Decisions/Standard reissue.
>
> Created: 2026-08-31 | Last modified: 2026-08-31

## Project identity

**Topic:** Working Practices  
**Master folder / GPT Project:** `AIDE/Working Practices/`  
**Published capability identity:** `AIDE_WorkingPractices@v1`

Working Practices is a top-level cross-cutting AIDE concern and can also be deployed independently.

## Topic declarations

| Name | Parent topic | Filename prefix | Inheritance | Mode |
|---|---|---|---|---|
| Working Practices | None | `WorkingPractices` | independent | expanded |

## Local configuration

None.

## Document register

| Document | Version | Type | Management | Status |
|---|---:|---|---|---|
| `WorkingPractices_Index` | v4 | Index | established | Current |
| `WorkingPractices_Brief` | v2 | Brief | established | Current |
| `WorkingPractices_Design` | v4 | Design | established | Current |
| `WorkingPractices_Decisions` | v4 | Decisions | established | Current |
| `AIDE_WorkingPractices_Standard` | v3 | Standard | established | Current canonical AI-facing outcome; identity `AIDE_WorkingPractices@v1` |

### Superseded by this pass

The currently installed v2/v1 masters are replaced directly by the versions above:

| Document | Current before application | Replacement | Disposition |
|---|---:|---:|---|
| `WorkingPractices_Index` | v2 | v4 | move v2 to `superseded/` |
| `WorkingPractices_Design` | v2 | v4 | move v2 to `superseded/` |
| `WorkingPractices_Decisions` | v2 | v4 | move v2 to `superseded/` |
| `AIDE_WorkingPractices_Standard` | v1 | v3 | move v1 to `superseded/`; capability identity remains `AIDE_WorkingPractices@v1` |

`WorkingPractices_Brief_v2.md` is unchanged and remains Current.

An intermediate Change Delivery issued `WorkingPractices_Index/Design/Decisions` v3 and
`AIDE_WorkingPractices_Standard` v2 but was superseded before adoption into the project's Current
masters. Those issued transfer outputs are not the Current baseline and should not be applied.

### Withdrawn, renamed or rehomed

None.

## Output model

```text
WorkingPractices_Design
        ↓
AIDE_WorkingPractices_Standard
```

## Relationship to Principles

Principles owns durable reasoning/problem-solving premises.

Working Practices owns concrete cross-surface conventions for carrying out, communicating,
verifying and handing over work.

## Assets register

None.

---
Dependencies: !AIDE_DocumentationMethodology@v19
References: WorkingPractices_Design_v4, AIDE_WorkingPractices@v1, Principles_Design_v3
