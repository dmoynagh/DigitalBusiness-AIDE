# AI Deployment — Registry Layer Change Delivery Instructions — 2026-09-02

## Purpose

Apply the confirmed **Deployment Registry layer** only.

This pass closes the current Build/Capabilities → AI Deployment package-registration seam and records the agreed Registry lifecycle/Release Batch model. It deliberately does **not** finalise the next Deployment Set/output/delivery layer.

## Authoritative baseline

Apply against the current AI Deployment v4 masters represented by `AIDeployment_Binder_v4` and reconcile with the supplied current Build v6 / Capabilities v6 corpus.

Generated Binders are consumption artefacts; individual masters remain authoritative.

## Apply to `AIDE/AI Deployment/` masters

### Replace Current

- `AIDeployment_Index_v5.md` — replaces `AIDeployment_Index_v4.md`.
- `AIDeployment_Design_v5.md` — replaces `AIDeployment_Design_v4.md`.
- `AIDeployment_Decisions_v5.md` — replaces `AIDeployment_Decisions_v4.md`.
- `AIDE_Deployment_Standard_v5.md` — replaces `AIDE_Deployment_Standard_v4.md`.
- `AIDE_Deployment_Tool_v5.md` — replaces `AIDE_Deployment_Tool_v4.md`.

Move replaced issued versions according to the normal current/Superseded physical workflow.

### Add as new Current masters

- `AIDeployment_Registry_Design_v1.md`.
- `AIDE_DeploymentRegistry_Tool_v1.md` — identity `AIDE_DeploymentRegistryTool@v1`.

### Retain unchanged

- `AIDeployment_OpenAI_Reference_v2.md`.

## Regenerate Binder

Use the supplied generated `AIDeployment_Binder_v5.md` as the expected resulting Binder/checkpoint after the masters above are installed.

Do not edit the Binder directly as authoritative source.

## Confirmed changes in this pass

The applied design establishes:

1. **Deployable Package** as the generic Registry package concept; `Capability Package` remains the first specialised kind.
2. **Deployment Registry** as the AI-Deployment-owned authoritative source of validated built supply.
3. Stable **Logical Package Identity** separated from immutable concrete **PackageId**.
4. Registry-owned **Current Package** relation.
5. Registry lifecycle:
   - `Available`;
   - `Deprecated`;
   - `Withdrawn`;
   - physical purge deliberately separate/not automatic in v1.
6. Package-level and built-target/member-level `AIDE_Tags` selection support.
7. **Release Batch** for coordinated Registry visibility of multi-package changes.
8. Registry semantic events / **Deployment Trigger** seam for downstream Set re-evaluation.
9. `AIDE_DeploymentRegistryTool@v1` actions:
   - Register;
   - BeginBatch;
   - ReleaseBatch;
   - AbandonBatch;
   - Deprecate;
   - Withdraw;
   - Status.
10. Registry publication remains a post-Build action whose result is separate from successful immutable package production.

## Explicitly not finalised by this pass

Do not treat this change package as final architecture for:

- Build Target Profile/Definition ownership or schema;
- full Deployment Set Definition selector syntax;
- exact Resolved Deployment Set revision/lock model;
- Deployment Package/output-definition schema;
- Delivery Action configuration;
- detailed trigger-to-Set matching; or
- platform target adapters/package assembly mechanics.

These are the next design layers.

## Cross-topic handoffs

This package includes two Project Handoffs. They are **not AI Deployment masters**.

### Send to Build owning project

`ProjectHandoff_AIDeployment_Registry_to_Build_2026-09-02.md`

Purpose: replace Build v6's current “future AI-Deployment-owned Registry Tool” placeholder with the now-current `AIDE_DeploymentRegistryTool@v1`, without changing generic Build/WorkPackage semantics.

### Send to Capabilities owning project

`ProjectHandoff_AIDeployment_Registry_to_Capabilities_2026-09-02.md`

Purpose: reconcile Capability Package with the Registry envelope, immutable PackageId, Tags, current Registry Tool, and the post-Build-result boundary.

Important specific correction: the actual Registry post-Build result must remain external to the immutable Capability Package and be reported through Registry receipt/WorkPackage Outcome.

## No direct Core change in this package

The previously discussed Platform Profile / Build Target Profile model is intentionally deferred to the next producer/platform layer. Do not issue a Core change solely from this Registry pass.

## Validation after application

Confirm:

- current AI Deployment Index resolves v5 Design/Decisions/Standard/Tool plus Registry Design/Tool;
- no current executable AI Deployment instruction still expects Build v3 or Dependencies v2;
- `AIDE_DeploymentRegistryTool@v1` is available to post-Build callers;
- `AIDE_PublishBuildOutputTool@v1` remains ordinary-publication only;
- a Registry PackageId cannot be silently overwritten with changed content;
- Release Batch staging does not change ordinary Current visibility until Release; and
- Deprecated/Withdrawn Registry state does not directly mutate runtime targets outside normal Deployment reconciliation.

## Completion state

After applying the AI Deployment masters and dispatching the two handoffs, this Registry-layer change package is complete.

Continue AI Deployment design with the **Deployment Set Definition / resolution / output / Delivery Action layer**.
