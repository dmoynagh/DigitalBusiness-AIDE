# Project Handoff — AI Deployment Registry → Build

## Purpose

Close the Build v6 post-Build placeholder now that AI Deployment has defined the first Deployment Registry contract and Tool.

Treat current Build Binder/current Build masters as authoritative. This handoff requests only the smallest seam reconciliation; it does not change generic Build ownership or WorkPackage semantics.

## Confirmed AI Deployment contract

AI Deployment now owns:

```text
Deployment Registry
AIDE_DeploymentRegistryTool@v1
```

The Tool owns registration/publication of a validated **Deployable Package** into the Registry plus Registry lifecycle and Release Batch actions.

`Capability Package` is the first specialised Deployable Package kind.

A registered PackageId is immutable. Registry Current/lifecycle/batch state is separate from package bytes.

## Required Build reconciliation

Update current active statements that currently say the Registry action requires a **future** AI-Deployment-owned Tool so they identify the now-current contract:

```text
AIDE_DeploymentRegistryTool@v1
```

Normal post-Build use is:

```text
successful validated Build/package
        ↓
explicit nominated post-Build Tool
        ↓
AIDE_DeploymentRegistryTool Register
        ↓
Registry receipt/state returned separately
```

The Register action requires at least the validated package source/identity, PackageKind, Logical Package Identity, PackageId, integrity/provenance evidence, nominated Registry and optional Release Batch identity.

## Preserve current Build semantics

Do not change:

- `AIDE_WorkPackage@v3`;
- generic Build ownership;
- Build success/validation semantics;
- `AIDE_PublishBuildOutputTool@v1` ownership of ordinary filesystem/repository publication;
- the rule that post-Build failure does not erase successful production; or
- `MemberContribution | AssembledConsumptionArtefact` ownership.

`AIDE_PublishBuildOutputTool@v1` must continue to refuse to claim Deployment Registry state.

## Important immutability rule

The Registry action result is **not written back into the validated package bytes**. Build reports the post-Build result separately in its Outcome/returned evidence.

## Release Batch

Where a directing/specialised Build needs several packages to become Registry-current together, the post-Build request may nominate an existing open Release Batch or an authorised process may begin/release the Batch through `AIDE_DeploymentRegistryTool@v1`.

Release Batch supplies an atomic Registry-visibility boundary only; it is not a cross-target runtime deployment transaction.

## Expected smallest Build-owned change set

Likely active masters affected:

- `Build_Design` — replace pending/future Registry Tool wording with current Tool reference;
- `Build_Decisions` — record/clarify that the formerly pending Tool now exists if current history convention warrants a new decision event;
- `AIDE_Build_Standard` — replace current executable future-tool wording/reference;
- `Build_PostBuild_Design` — identify current Registry Tool;
- `AIDE_PublishBuildOutput_Tool` — reference current Registry Tool while preserving refusal boundary;
- Index/Binder/reference versions as required by Build's normal versioning methodology.

Do not broaden beyond this seam.

## AI Deployment references

```text
AIDE_Deployment@v5
AIDE_DeploymentRegistryTool@v1
AIDeployment_Registry_Design_v1
```
