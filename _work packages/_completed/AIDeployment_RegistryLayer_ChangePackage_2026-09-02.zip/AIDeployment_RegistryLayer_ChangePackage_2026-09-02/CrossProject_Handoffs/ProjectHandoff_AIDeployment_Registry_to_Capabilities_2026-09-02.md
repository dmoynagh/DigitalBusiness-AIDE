# Project Handoff — AI Deployment Registry → Capabilities

## Purpose

Return the confirmed producer/Registry seam requested by the current Capabilities architecture.

Treat the current Capabilities Binders/current masters as authoritative. Apply only the concrete Capability-package/post-Build changes required by this seam. Build Target Profile/Definition redesign is a later producer/platform reconciliation and is deliberately not required by this handoff.

## Accepted producer interface

AI Deployment accepts the current **Capability Package** concept as the first specialised kind of generic **Deployable Package**.

No separate capability-only Deployment Manifest is required by AI Deployment v5.

The ownership boundary is:

```text
Capabilities / specialised Capability Build
        ↓
complete validated Capability Package
        ↓
AIDE_DeploymentRegistryTool Register
        ↓
Deployment Registry
---------------- boundary ----------------
AI Deployment Set resolution / delivery / verification
```

## Registry package envelope required from Capability Package

Ensure a Capability Package exposes, directly or through its package contract:

```text
PackageKind: CapabilityPackage
Logical Package Identity
unique concrete PackageId
integrity evidence
Capability identity/release
exact Element-release composition
source/canonical provenance
production/Build contract provenance
complete built target/member outputs
Build-owned CompositionPosture where applicable
payload/file/area identity sufficient to resolve each built output
dependency and Migration material required downstream
Build/validation evidence
```

Where applicable, the Capability Package should also expose:

- Package Tags;
- built-target/member Tags;
- producer-declared surface support / conformance / variation / degradation information;
- namespaced owner-specific metadata/extensions required downstream; and
- the nominated post-Build request/intent.

Use `AIDE_Tags` semantics rather than a Capability/Deployment-specific tag language.

## Package immutability

Once validated and registered, one `PackageId` identifies one immutable concrete package instance.

A forced/repeated build may create another PackageId without changing Element/Capability semantic releases when meaning did not change.

Logical Package Identity groups those package instances; the Deployment Registry owns which PackageId is Current.

## Required correction — post-Build result

Current `AIDE_CapabilityBuild@v1` says the successful Package includes the nominated post-Build request/result, while generic Build v6 correctly says post-Build results are reported separately after successful output validation.

Reconcile this as:

```text
Capability Package may carry:
  nominated post-Build request / intent

Capability Package must not be mutated to carry:
  actual Registry post-Build result

Actual post-Build result:
  WorkPackage Outcome / Registry receipt/state
```

This preserves PackageId/integrity and safe retry after Registry failure.

## Post-Build Tool

The previously pending Registry Tool is now:

```text
AIDE_DeploymentRegistryTool@v1
```

Capability Build/Build Capability may nominate:

```text
Action: Register
Registry: <resolved configured Registry>
ReleaseBatch: <optional open Batch identity>
```

The Tool action/result is separate from Capability semantic release state.

## Dependencies, Migration and extensions

Continue carrying dependency and Migration material required downstream. AI Deployment preserves/consumes those owner-defined facts but does not redefine their semantics.

A package may carry additional namespaced metadata for capability-specific deployment-time logic. Unknown optional extension data is preserved; metadata declared mandatory for correct Deployment must identify/resolve the applicable handler or Deployment blocks the affected operation.

## Tags

Add support for Tags at:

```text
Capability Package level
built target/member level
```

Deployment selection treats a target/member's effective tags as:

```text
Package Tags + target/member Tags
```

This allows future Set definitions such as selection by `AIDE_Core` without hard-coding every Capability identity.

## Surface variation/degradation

The Registry contract can preserve Capability Build's actual surface support/degradation result so later Deployment verification knows what behaviour is expected.

The detailed Build Target Profile/Definition and conformance/degradation policy model is **not** finalised by this Registry handoff. Do not prematurely redesign current Build Platforms solely from this message; that producer/platform layer will be returned separately after the active AI Deployment design reaches that checkpoint.

## Required Capabilities changes now

Smallest current changes are expected in:

- Capability Package contract / `AIDE_CapabilityBuild`;
- Capability Builder package assembly/output description;
- Build Capability post-Build intent/reference;
- relevant Capability Definitions' current “Registry seam pending” wording;
- current Design/Overview/Index references that say the Registry contract is still pending;
- Binder/versions required by normal methodology.

Do not reopen Capability/Element semantics or Review D in this pass.

## Confirmed no-change areas

No change is required to:

- Capability/Element semantic release distinction;
- Element Production/LastEvaluated model;
- dependency ownership;
- Migration ownership;
- generic Build/WorkPackage ownership; or
- the rule that Capability Build produces a complete external package even when its internal work was incremental/reused.

## AI Deployment references

```text
AIDE_Deployment@v5
AIDE_DeploymentRegistryTool@v1
AIDeployment_Registry_Design_v1
```
