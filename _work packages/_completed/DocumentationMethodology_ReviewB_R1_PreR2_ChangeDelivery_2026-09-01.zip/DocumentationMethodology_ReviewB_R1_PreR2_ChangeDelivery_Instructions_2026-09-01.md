# Documentation Methodology — Review B R1 Pre-Round-2 Preflight — Change Delivery Instructions — 2026-09-01

## Purpose

Apply the smallest truthful Documentation Methodology correction required after coordinated Review B R1 remediation issued `AIDE_WorkPackage@v3`.

This package corrects only the current Review B R1 WorkPackage split-obligation seam:

- D39 now records that `AIDE_WorkPackage@v3` explicitly carries the deterministic-enough `Covers` rule;
- the current Standard's executable WorkPackage integration reference now uses `AIDE_WorkPackage@v3`;
- no new mechanism or structured sub-obligation identifier system is introduced; and
- the WorkRegister/WorkPackage ownership boundary is unchanged.

Historical Decision references are not rewritten. Footer `Dependencies:` / `References:` are not swept merely to make external capability versions look current. No general in-body version-reference or dependency-checkpoint policy is established; that remains reserved for Review C / Dependencies.

## What you need to do

Destination current master folder:

`AIDE/Document Methodology/`

### Replace Current

Add these files to the current master folder and replace the listed current versions:

- `DocumentationMethodology_Index_v10.md` — replaces `DocumentationMethodology_Index_v9.md`.
- `DocumentationMethodology_Design_v22.md` — replaces `DocumentationMethodology_Design_v21.md`.
- `DocumentationMethodology_Decisions_v23.md` — replaces `DocumentationMethodology_Decisions_v22.md`.
- `AIDE_DocumentationMethodology_Standard_v25.md` — replaces `AIDE_DocumentationMethodology_Standard_v24.md`.
- `DocumentationMethodology_Guide_v25.md` — replaces `DocumentationMethodology_Guide_v24.md`.
- `DocumentationMethodology_Binder_v6.md` — replaces `DocumentationMethodology_Binder_v5.md`.

### Move to `_superseded/`

Move the six replaced current files above to:

`AIDE/Document Methodology/_superseded/`

### Project context

Replace the Documentation Methodology Binder currently loaded into the project/context with:

`DocumentationMethodology_Binder_v6.md`

Do not edit the Binder directly; it is generated from the five current masters.

### No action in this package

- Do **not** rewrite genuinely historical Decision references.
- Do **not** sweep external footer `Dependencies:` / `References:` to newer capability versions merely for currency.
- Do **not** update `AIDE_Bundle_StandardsTools_v5.md` from this package; the common Bundle remains a separate normal rebuild.
- Do **not** introduce Review C / Dependencies policy.

## Why all five masters are replaced

The semantic correction is only the WorkPackage seam, but the canonical Documentation Methodology Standard is an issued, release-aligned outcome. Reissuing it requires `AIDE_DocumentationMethodology@v25`; the current Design/Guide/Index/Decisions issue set therefore advances only as required to keep the current corpus and Binder truthful. This is version/distribution consistency, not broader semantic remediation.

## Resulting current Binder

`DocumentationMethodology_Binder_v6.md`

Generated from exactly:

- `DocumentationMethodology_Index_v10.md` — sha256 `e464e9bfb350`
- `DocumentationMethodology_Design_v22.md` — sha256 `4a3e144b69e9`
- `DocumentationMethodology_Decisions_v23.md` — sha256 `9fc6c4396f54`
- `AIDE_DocumentationMethodology_Standard_v25.md` — sha256 `16e3b2a5c94a`
- `DocumentationMethodology_Guide_v25.md` — sha256 `2067bd12501d`

Binder sha256 `d53c436ac6c8`.

## Validation

- No current in-body `AIDE_WorkPackage@v2` remains in the replacement masters.
- Remaining `AIDE_WorkPackage@v2` occurrences, where present, are only footer `Dependencies:` / `References:` intentionally left outside this correction.
- D39 now describes the actual coordinated v3 result.
- The Standard current executable WorkPackage integration clause now names `AIDE_WorkPackage@v3`.
- No historical Decision event was mass-rewritten and no general version/conformance rule was added.
