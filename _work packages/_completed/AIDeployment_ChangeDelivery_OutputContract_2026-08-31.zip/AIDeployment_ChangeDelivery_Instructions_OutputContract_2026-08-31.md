# AI Deployment — Change Delivery Instructions — Build Output Contract Alignment — 2026-08-31

## Purpose

Apply the Build v3 → AI Deployment interface alignment with the smallest AI Deployment-owned change set.

The current AI Deployment v3 model already established the semantic-production / mechanical-assembly boundary. This pass adopts the Build-owned deployment-facing output facts explicitly:

- authoritative/canonical source identity/version provenance;
- concrete Build-output/package identity and integrity evidence; and
- `CompositionPosture: MemberContribution | AssembledConsumptionArtefact`.

No new Deployment mechanism, Build mechanism, packaging subsystem or acquisition mechanism is introduced.

## Apply to `AIDE/AI Deployment/` masters

### Replace Current

Add these files to the current AI Deployment master folder and replace the corresponding v3 masters:

- `AIDeployment_Index_v4.md` — replaces `AIDeployment_Index_v3.md`.
- `AIDeployment_Design_v4.md` — replaces `AIDeployment_Design_v3.md`.
- `AIDeployment_Decisions_v4.md` — replaces `AIDeployment_Decisions_v3.md`.
- `AIDE_Deployment_Standard_v4.md` — replaces `AIDE_Deployment_Standard_v3.md`; canonical identity becomes `AIDE_Deployment@v4`.
- `AIDE_Deployment_Tool_v4.md` — replaces `AIDE_Deployment_Tool_v3.md`; canonical identity becomes `AIDE_DeploymentTool@v4`.

### Move to `_superseded`

Move these replaced issued files to `AIDE/AI Deployment/_superseded/`:

- `AIDeployment_Index_v3.md`
- `AIDeployment_Design_v3.md`
- `AIDeployment_Decisions_v3.md`
- `AIDE_Deployment_Standard_v3.md`
- `AIDE_Deployment_Tool_v3.md`

### Leave Current unchanged

Do not replace or reissue:

- `AIDeployment_OpenAI_Reference_v2.md`

The Build output-contract alignment does not alter its empirical OpenAI findings.

## What changed

AI Deployment now consumes Build's exact deployment-facing composition posture rather than describing an equivalent local distinction:

- `MemberContribution` may participate in deterministic Deployment-owned mechanical target assembly.
- `AssembledConsumptionArtefact` is atomic at its internal semantic/member-composition boundary. Deployment may place, publish, wrap or otherwise handle it mechanically, but a change to that internal composition requires another Build output.
- Reconciliation resolves composition posture together with canonical/source provenance, Build-output/package identity and integrity.
- Deployment does not infer posture from payload shape, representation name, filename, deployed state or an older Bundle/package.
- Missing or posture-incompatible Build output is a Build/material blocker, not permission for Deployment to perform semantic production.
- Version-specific Build references now point to `Build_Design_v3` / `AIDE_Build@v3` where applicable.

`AIDeployment_Decisions_v4.md` preserves D15 and D16 as the existing historical boundary decisions and adds D17 for explicit consumption of the Build-owned composition-posture contract.

## Binder change

Use `AIDeployment_Binder_v4.md` as the new generated AI Deployment Binder/project-context Binder.

Replace `AIDeployment_Binder_v3.md` in active project context. Retain/move the older generated Binder according to the normal generated-artefact lifecycle; do not edit either Binder directly.

## Build Project Handoff

No new Project Handoff to Build is required.

The Build v3 response satisfies the interface facts previously requested by AI Deployment. This pass only aligns AI Deployment terminology and behaviour to consume those Build-owned facts explicitly. The Build ↔ AI Deployment interface loop is therefore closed unless later work exposes a new Build-owned consequence.

## Common Standards/Tools Bundle

Do **not** patch `AIDE_Bundle_StandardsTools_v3.md` directly from this package.

The current Bundle is already stale across both sides of this interface and should be regenerated in the planned cross-project Bundle build. At that regeneration, select the current canonical sources including:

- `AIDE_Build@v3` from the current Build Binder; and
- `AIDE_Deployment@v4` / `AIDE_DeploymentTool@v4` from `AIDeployment_Binder_v4.md`.

Record the normal generated-Bundle provenance rather than treating the existing Bundle as a semantic source.

## Capability/version consequence

`AIDE_Deployment@v4` and `AIDE_DeploymentTool@v4` declare `Transition: v4 / Posture: None`.

The change tightens the downstream interface contract but does not prescribe migration of existing consumer state merely because v4 is available. Normal dependency/migration/save rules determine checkpoint advancement.

## Project-context changes

After applying the master changes:

1. replace the AI Deployment project-context Binder with `AIDeployment_Binder_v4.md`;
2. do not add this Change Delivery Instructions file as authoritative project context;
3. retain `AIDeployment_OpenAI_Reference_v2.md` as the unchanged current empirical Reference through the Binder; and
4. later regenerate/replace the common Standards/Tools Bundle from all current canonical sources rather than patching the old Bundle.

## Package contents

```text
AIDeployment_ChangeDelivery_OutputContract_2026-08-31.zip
├── AIDeployment_Index_v4.md
├── AIDeployment_Design_v4.md
├── AIDeployment_Decisions_v4.md
├── AIDE_Deployment_Standard_v4.md
├── AIDE_Deployment_Tool_v4.md
├── AIDeployment_Binder_v4.md
└── AIDeployment_ChangeDelivery_Instructions_OutputContract_2026-08-31.md
```
