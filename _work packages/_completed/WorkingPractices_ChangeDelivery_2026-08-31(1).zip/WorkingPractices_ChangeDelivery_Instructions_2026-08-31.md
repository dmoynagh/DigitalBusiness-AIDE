# Working Practices — Change Delivery Instructions — 2026-08-31

> Transfer/application artefact. Not an authoritative corpus master.

## Destination

Apply these changes to the Working Practices project/master corpus at:

```text
AIDE/Working Practices/
```

This change reconciles the confirmed Documentation Methodology v20 boundary: Documentation
Methodology owns document lifecycle meaning; Working Practices owns the practical physical
repository/workflow convention used to implement those states.

## Replace Current masters

| New file | Replaces current master | Action |
|---|---|---|
| `WorkingPractices_Index_v3.md` | `WorkingPractices_Index_v2.md` | Install v3 as Current; v2 becomes Superseded. |
| `WorkingPractices_Brief_v3.md` | `WorkingPractices_Brief_v2.md` | Install v3 as Current; v2 becomes Superseded. |
| `WorkingPractices_Design_v3.md` | `WorkingPractices_Design_v2.md` | Install v3 as Current; v2 becomes Superseded. |
| `WorkingPractices_Decisions_v3.md` | `WorkingPractices_Decisions_v2.md` | Install v3 as Current; v2 becomes Superseded. |
| `AIDE_WorkingPractices_Standard_v2.md` | `AIDE_WorkingPractices_Standard_v1.md` | Install v2 as Current canonical Standard; v1 becomes Superseded. |

Under the Working Practices convention established by this issue, move those five replaced issued
masters to:

```text
AIDE/Working Practices/_superseded/
```

Their lifecycle state is determined before the move; `_superseded/` is only the physical handling
convention.

## Generated Binder

**Add/replace generated project-context artefact:**

```text
WorkingPractices_Binder_v1.md
```

This is the first independently versioned Working Practices Binder. It assembles exactly:

```text
Index v3
Brief v3
Design v3
Decisions v3
AIDE_WorkingPractices Standard v2
```

Keep it in the active/master Working Practices folder alongside the Current masters. It is
generated/read-only and is not an authoritative master.

Replace the previously loaded/generated unversioned `WorkingPractices_Binder.md`. If that previous
Binder is retained, it becomes Superseded because it was replaced and should be placed in:

```text
AIDE/Working Practices/_superseded/
```

Do not edit either Binder directly.

## Project-context change

Remove the previous `WorkingPractices_Binder.md` from this GPT Project context and add
`WorkingPractices_Binder_v1.md` so the project context visibly identifies the loaded Binder version
and matches the Current masters.

## New Working Practices conventions introduced

This issue confirms:

- structural/workflow-management folders use `_` prefix where useful;
- current physical lifecycle locations are `_superseded/` and `_archived/` where folders are used;
- lifecycle state is semantic and is never created by moving a file into one of those folders;
- active Change Delivery ZIPs are staged in `Documentation/_changeDeliveryPackages/`;
- completed/applied Change Delivery ZIPs move to `Documentation/_changeDeliveryPackages/_completed/`;
- historical material in `_superseded/`, `_archived/` and `_changeDeliveryPackages/_completed/` may
  periodically move to longer-term storage outside the active repository while preserving required
  history/traceability;
- generated Binders use `<Project>_Binder_vN.md`, are independently versioned, and the current Binder
  stays with active masters; and
- Project Handoff is the formal cross-project knowledge-transfer convention.

## Bundle / build / deployment consequence — not included in this package

The common Standards/Tools Bundle is intentionally not changed here. On the next normal
Bundle/build/deployment reconciliation, use:

```text
AIDE_WorkingPractices_Standard_v2.md
```

as the canonical Working Practices member. If Working Practices has not yet been added to that
Bundle, add v2 rather than first adding the superseded v1. Update the bundle manifest/hash and
platform representations as required by their owning processes.

Documentation Methodology v20 bundle reconciliation remains a separate owning job and is not
performed by this Working Practices package.

## Change Delivery Package handling

Stage `WorkingPractices_ChangeDelivery_2026-08-31.zip` in:

```text
Documentation/_changeDeliveryPackages/
```

while reviewing/applying it. After all master, Binder and project-context actions above are
complete, move the ZIP to:

```text
Documentation/_changeDeliveryPackages/_completed/
```

## Verification

After application, the Working Practices Current register should read:

```text
Index v3
Brief v3
Design v3
Decisions v3
AIDE_WorkingPractices Standard v2
```

and `WorkingPractices_Binder_v1.md` should report those same five source versions in its manifest.
The active project folder should contain the Current masters and current Binder; superseded issued
versions should be physically handled under `_superseded/` according to this convention.
