# Review B Round 2 Relay Pack — Instructions

This is a Review relay/checkpoint pack, not a Change Delivery Package.

## Contents

- `ReviewB_R2_Claude_Request_gpt-003.md`
  - exact Round 2 AI-MESSAGE to paste into the existing Claude Review B chat.

- `Capabilities_WIP_v9.md`
  - current Capabilities continuation checkpoint for Review B before Round 2 relay.

## What to do

1. Replace the current Capabilities WIP v8 checkpoint with `Capabilities_WIP_v9.md`.
2. Stay in the **existing Claude Review B chat**.
3. Supply these seven current files:
   - DocumentationMethodology_Binder_v6.md
   - WorkingPractices_Binder_v3.md
   - ProjectDesign_Binder_v3.md
   - Build_Binder_v5.md
   - Capabilities_WIP_v9.md
   - Capabilities_OpenItems_v15.md
   - Capabilities_WorkRegister_v15.md
4. Paste `ReviewB_R2_Claude_Request_gpt-003.md`.
5. Use Claude Opus 5 if available.
6. Bring Claude's returned AI-MESSAGE back to the GPT Lead chat unchanged.
7. Do not begin Review C yet.

## State truthfulness

- Request prepared != relayed.
- Relay != proven receipt unless positive receipt evidence exists.
- Review B remains Continuing until the High re-review is dispositioned and completed or escalated.
