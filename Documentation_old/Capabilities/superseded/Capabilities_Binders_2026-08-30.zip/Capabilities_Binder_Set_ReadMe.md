# Capabilities GPT Project Source Set

Generated from `Capabilities.zip`. Upload the five Binders plus the unchanged Documentation Methodology Guide as the GPT Project source set.

## Upload these 6 sources

- `Capabilities_Core_Binder.md` — 5 source documents, 114.9 KB
- `Capabilities_Work_Binder.md` — 3 source documents, 20.0 KB
- `Capabilities_StandardsTools_Binder.md` — 4 source documents, 16.6 KB
- `Capabilities_Runtime_Binder.md` — 10 source documents, 55.8 KB
- `Capabilities_Review_Binder.md` — 5 source documents, 92.4 KB
- `DocumentationMethodology_Guide_v17.md` — unchanged source, 85.3 KB

## Coverage

- Current Capabilities documents registered in `Capabilities_Index_v12`: 27
- Current Capabilities documents included exactly once across Binders: 27
- Missing: none
- Duplicated: none

The uploaded ZIP contained 28 files total: the 27 registered current Capabilities documents plus `DocumentationMethodology_Guide_v17.md`.
