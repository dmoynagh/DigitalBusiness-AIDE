# Capabilities Binder Set

Generated: 2026-08-30

These Binders are generated GPT Project consumption artefacts. They are **not authoritative master documents** and must not be edited directly. Edit the individual files in `AIDE/Capabilities/` and regenerate the Binder set.

## GPT Project sources

Use these six sources:

1. `Capabilities_Binder_Core.md`
2. `Capabilities_Binder_Work.md`
3. `Capabilities_Binder_StandardsTools.md`
4. `Capabilities_Binder_Runtime.md`
5. `Capabilities_Binder_Review.md`
6. `DocumentationMethodology_Guide_v17.md`

The five Capabilities Binders contain all **33 current Capabilities documents registered in `Capabilities_Index_v13` exactly once**. The Documentation Methodology Guide remains a separate unchanged source.

## Grouping

- **Core** — Index, Brief, Overview, parent Design and Decisions.
- **Work** — Work Register, Open Items, and DocMeth review handoff.
- **StandardsTools** — Standards/Tools design corpus, Standards Production/Usage outputs, and Build Capability Tool.
- **Runtime** — Tags, Scope, Dependencies, Migration, including the canonical Migration Tool.
- **Review** — Review design/decisions/standards and canonical Review Tool.

Each Binder carries a source manifest with a short SHA-256 digest and explicit `BEGIN SOURCE` / `END SOURCE` boundaries. Embedded master documents are byte-for-byte unchanged.
