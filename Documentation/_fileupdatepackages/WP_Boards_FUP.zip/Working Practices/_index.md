# Working Practices

Role: component design
Aliases: WP, workprac

Working Practices defines the operational conventions, behaviours, and working methods that govern how work is conducted — across any phase, any surface, and any kind of work. It is the umbrella for action and behaviour. Phase-specific methods are owned by their phase component; WP owns what they all consume.

WP operates at two levels. At component level, capture-and-place, operational tools, file delivery rules, and the overview-first discipline are standing obligations. Below that, two areas provide the models and conventions work uses: Working State and Content Delivery.

## Documents

| Prefix | Document | Type |
|---|---|---|
| WP_ | Brief v2 | brief |
| WP_ | Design v5 | design |
| WP_ | Decisions v3 | decisions |

## Parts

**Boards** (prefix `WP_Boards_`)
How work is tracked across its full lifecycle — boards as scoped task records with zones, dependencies, work sets, and AI maintenance. Supersedes the work plan (D10).

## Working documents

| Prefix | Document | Type |
|---|---|---|
| WP_WorkManagement_ | Working v1 | working |
