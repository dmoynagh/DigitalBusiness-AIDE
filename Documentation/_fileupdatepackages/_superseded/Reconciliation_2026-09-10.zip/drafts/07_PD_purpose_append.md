## Content to APPEND to _rebuild/ProjectDesign_Design_Pending_v1.md

### Item 18 — Purpose statement (confirmed 2026-09-09)

Design document types exist to make the design process easier. This is the purpose statement for Project Design — it is not a principle. Project Design's role is producing the design specification; the document types it defines (brief, design, decisions, overview, work register) are the means by which that specification is produced and maintained.
