## Edits to _rebuild/AIDE_Component_PurposeLines_v2.md

### ROW 12 — REPLACE Core row in the "Active components" table:

OLD:
| 12 | Core | Hold whatever shared requirements have no natural home elsewhere. | Deferred by design, resolved last. Carries the settled Index, Domain and Bootstrap work forward. |

NEW:
| 12 | Core | The root entry to AIDE — the framework's self-description, component model, framework-wide requirements, and the map to all components. | Two parts: Structure (folder conventions, container labels, path authority, the AIDE document) and AIDE Principles (facilitate-not-constrain, opt-in, strength model). Owns the three-pillar framing and component/capability/utility definitions. |

### HELD TABLE — ADD Tags note:

After the existing Tags row, add a note or update the row to reflect that Tags has been resurrected as an active area within Core (session 2026-09-09) while Scope and Dependencies remain held.

Option A (recommended, moderate) — move Tags out of Held and into Active:

ADD to Active table:
| 13 | Tags | Label documents for classification, discovery, and feature activation — a shared vocabulary any component can define and any logic can consume. | Core capability, own area (Core_Tags). Flat list of string keys in header, with optional named groups for ownership that collapse to a flat distinct list for consumers. Standard as output; tools deferred. |

REMOVE from Held table:
The Tags row. Leave Scope and Dependencies.

Option B — annotate within Held:
Update the Tags row to note it has been resurrected and is being designed in Core_Tags_Working.
