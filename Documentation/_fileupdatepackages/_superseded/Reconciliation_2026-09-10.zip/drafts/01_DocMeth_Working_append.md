## Content to APPEND to Documentation Methodology/DocMeth_Working_v1.md
## (after the existing "Prefix convention" section)

---

### Block-type recognition (confirmed 2026-09-09)

A block type is not inherited from its containing doctype, and its specification does not fix its position within a document. Both facts mean a reader — human or AI — needs a way to recognise where a block begins.

**The two-part test.** Something is a block-type instance when: (1) it is not assigned to this position by the doctype definition, AND (2) the specification does not fix its position. When both hold, a marker is needed.

**The marker.** An HTML comment placed immediately after the heading that begins the block, not before it. The after-heading placement is deliberate — it survives RAG chunking, which typically splits on headings. A marker before the heading would be separated from the content it identifies.

This is a Documentation Methodology concern — it is part of the grammar of how documents are structured, not owned by any individual block type.

### Identity and versioning — ownership confirmed (2026-09-09)

Identity (name + @version) and the versioning model are Documentation Methodology concerns. DocMeth owns the mechanics of how documents identify themselves and how versions work — the naming grammar, the publish transition, draft support, immutability of published versions, and reference forms.

Path and root are Core/Structure concerns (settled 2026-09-10 — path authority in the document header, physical folders as the structure).

The boundary: DocMeth owns what a document calls itself and how its versions progress. Core/Structure owns where a document sits and how that location is expressed.
