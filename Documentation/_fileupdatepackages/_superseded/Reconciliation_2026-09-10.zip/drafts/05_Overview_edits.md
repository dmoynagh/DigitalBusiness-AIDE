## Edits to _rebuild/AIDE_Rebuild_Overview_v1.md — Open items section

### REPLACE the current "Open items" section with:

## Open items

These are recorded explicitly as unresolved. Each has a stated trigger for resolution.

**Component boundaries and structure.** What makes something a component, where the boundaries fall, and whether components can contain sub-components. At least Working Practices and Build show signs of wanting nesting. The three held candidates also feed into this discussion. Trigger: resolve before or during the Standards pass, because the definition of a component is foundational.

**Whether domains exist as a concept.** The old model said development domains consume AIDE; they are not components of it. Whether that concept carries forward has no demonstrated need yet. Trigger: resolve if and when the relationship between AIDE and consuming projects needs to be defined.

### RESOLVED — moved from open items (session 2026-09-10)

**Utilities and infrastructure placement — RESOLVED.** Infrastructure is a methodological component: it defines how to build and deploy utilities and owns the aide dispatcher design. It does not hold all utility designs — those live with their owning component or area. The three existing utility designs (binder-builder, FUP, version-cleanup) move from Infrastructure to the File Operations part of Working Practices. Utilities are distributed via a pip package from git, with an `aide` dispatcher on PATH, an interactive menu, and per-project batch launcher support.

**The capability-as-deployable-unit question — RESOLVED.** Capabilities is a term, not a container. It covers Standards, Tools, and Utilities — components delivering functionality. The Capabilities/ folder is dropped (no longer needed as a separate folder). Standards and Tools are methodological components following the same pattern as Infrastructure: they define how to create their type, while individual instances live with their consuming component.
