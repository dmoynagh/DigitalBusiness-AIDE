> identity: Core_Schema_Standard@v1 | doctype: standard | date: 2026-09-12
> uses: Standards:[Schema_Standard@v1], DocMeth:[Definitions_Standard@v4]

# Core — Schema Standard

The doctype and block-type definitions owned by Core.

## What this standard is for

Information. This standard defines the index doctype and the tags block type. The index is the identity document at the root of a component's folder. Tags is deferred — defined here for completeness but not active until a consumer demonstrates need.

## Doctypes

### Index

- **Purpose:** A component's identity document at its folder root. Carries the component name, role, aliases, document listing, and parts declaration.
- **Format constraint:** markdown.
- **Format conventions:** the filename is `_index.md`. The leading underscore sorts it to the top of a directory listing.

Information. The index is not a table of contents or a navigation aid — it is identity. A component without an index has no declared identity in the file system. The document listing is a register of the component's governed documents, not a binder manifest.

## Block types

### Tags

- **Purpose:** Classification labels for a governed document.
- **Placement:** footer.
- **Fields:**
  - tags (optional) — a flat list of classification labels

Information. Deferred under the demonstrated-requirement rule. The definition is recorded so the concept is not lost. Tags returns to active use when a consumer demonstrates need — the primary candidate was root scope, which is parked.

---

Version note: v1 — initial schema definitions for Core. 2026-09-12.
