> identity: WP_Schema_Standard@v1 | doctype: standard | date: 2026-09-12
> uses: Standards:[Schema_Standard@v1], DocMeth:[Definitions_Standard@v4]

# Working Practices — Schema Standard

The doctype and block-type definitions owned by Working Practices.

## What this standard is for

Information. This standard defines the generic doctypes consumed across components (decisions, knowledge, WIP, open items, work item) and the definition of done block type. These types are owned by Working Practices under the what-knows-most-about-it principle — they describe how work is conducted, not how documents are shaped. Operational rules for these types are in the Working Practices operational standards.

## Doctypes

### Decisions

- **Purpose:** Topic-scoped reasoning — the fuller why, including paths not taken. The permanent record of reasoning behind settled positions.

Information. Decisions is a generic doctype consumed by any component. Design holds the live why inline; decisions holds the fuller why and the rejected alternatives.

### Knowledge

- **Purpose:** Reference knowledge with no single owning topic. Created on demand, not pre-created empty.

Information. When knowledge needs to reach the AI platform, it is authored into a standard at information strength. Knowledge is a design-time document, not a delivery vehicle.

### WIP

- **Purpose:** Current memory — live state, pending content for unwritten masters. The staging buffer; the binder is persisted memory.

Information. A WIP carries content destined for masters not yet written. A master is not authoritative alone between updates — reading a master means checking its pending section in the WIP first.

### Open Items

- **Purpose:** Parked questions and items requiring attention that are not active work. Live but unresolved.

Information. Open items are not work items — a work item flows through a workflow and has fates. An open item waits until it is taken up, resolved, or explicitly dropped.

### Work Item

- **Purpose:** An encapsulated unit of something pending in a workflow. Raised from any source — the human, a build return, a session noticing a consequence, another component handing something in.

Information. Two axes: type (what kind of thing it turned out to be, determined on judgement) and state (open, current, closed — views, not separate entities). Types are not enumerated — capture-and-place is expected to surface the real type list.

Information. Five fates, chosen by the session on context: dealt with in conversation; resolved and recorded as a decision; parked as an open item; captured into WIP; become committed work in the register.

Information. Governing rule: no knowledge lost. A work item may be dropped only by a decision that it carries nothing worth keeping.

## Block types

### Definition of Done

- **Purpose:** The completion bar — short, accurate, concise. The primary success test for whatever consumes it.
- **Recognition:** by subheading.

Information. The invariant: every item must be testable or assessable. Definition of done carries the invariant; the consuming doctype fills the content. The brief consumes it as a required element block. Other consumers (component project documentation, build packages) fill it with their own criteria.

---

Version note: v1 — initial schema definitions for Working Practices. 2026-09-12.
