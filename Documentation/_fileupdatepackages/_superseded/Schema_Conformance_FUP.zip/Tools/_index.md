# Tools

Role: component design
Aliases: none

Tools defines the methodology for building tools — repeatable, named, invokable actions performed by the AI in-session. It owns the tool definition, the invocability test that draws the boundary between a tool and a standard, and the authoring methodology used to design and author tools.

Tools is a methodological component. It defines how to create its type; individual tools live with their owning component under the what-knows-most-about-it principle.

## Documents

| Prefix | Document | Type |
|---|---|---|
| Tools_ | Design v3 | design |
| Tools_ | Decisions v3 | decisions |
| Tools_ | Authoring Standard v5 | standard |

## Parts

None declared.
