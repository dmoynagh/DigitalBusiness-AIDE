> identity: ProjectDesign_Schema_Standard@v1 | doctype: standard | date: 2026-09-12
> uses: Standards:[Schema_Standard@v1], DocMeth:[Definitions_Standard@v4]

# Project Design — Schema Standard

The doctype and block-type definitions owned by Project Design.

## What this standard is for

Information. This standard defines the types Project Design owns — four doctypes (brief, design, overview, work register) and one block type (the brief composite). For the grammar these definitions use, see the DocMeth Schema Standard. For generic types consumed by Project Design (decisions, knowledge, WIP, open items, work item, definition of done), see the Working Practices Schema Standard.

## Doctypes

### Brief

- **Purpose:** Fixes the problem and the bar for success before designing. The brief is the problem space; the design is the solution space.
- **Included blocktypes:** Definition of done (required).
- **Format constraint:** markdown.

Information. A brief is mandatory — always. Standalone or inline at the head of a design document, but never absent. When inline, the brief composite block type is used. When standalone, this doctype applies. The split test governs the choice.

Information. The brief's body sections (purpose, objectives, requirements, scope and boundaries, linked build outcome, considerations, target/outcome) are the brief's internal structure, not independently-defined block types. The author may add custom sections as needed. Required and optional sections are specified in the PD operational standard.

### Design

- **Purpose:** The confirmed model and approach, carrying its own live reasoning. The primary source for the handoff to build.
- **Included blocktypes:** Brief (optional — inline when not standalone), Contents (recommended), Version note (recommended).

Information. The design doctype is criteria and advice, not a schema. Composition varies by project. Nine required criteria and four advice items govern content — these are authoring rules in the operational standard, not block-type definitions.

### Overview

- **Purpose:** The project-scale snapshot — current state, progress, active concerns. Also a deviation detector against the design.
- **Included blocktypes:** Contents (optional), Summary (optional).

Information. The overview sits inline in the design document for small projects. It splits to its own document per the split test. While inline, the host document does not also carry a Summary — the overview is already doing the orienting job.

### Work Register

- **Purpose:** The ledger of confirmed work owed and not yet fully delivered. Default-on — non-use must be stated explicitly.
- **Format constraint:** markdown.

Information. Entry structure and states are operational rules in the Project Design standard, not block-type definitions. The register is flat — no child items, no task tree.

## Block types

### Brief

- **Purpose:** The problem-space composite. Used inline at the head of a design document when scale does not warrant a standalone brief document. Carries the same content structure as the brief doctype.
- **Subheadings:** Purpose (required), Objectives (required), Definition of done (required), Requirements (required), Scope and boundaries (required), Linked build outcome (required), Considerations (optional), Target/outcome (optional). The author may add custom headings as content requires.
- **Recognition:** by subheading — the brief's element headings identify the composite.

---

Version note: v1 — initial schema definitions for Project Design. 2026-09-12.
