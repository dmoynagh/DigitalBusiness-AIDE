Project Design | _index | ProjectDesign_Index@v2 | 2026-09-12

Project Design produces a coherent specification for work of any size and manages the response from build as it pertains to design. Fluid in, precise out — it owns both ends of the design-build loop.

## Documents

| Prefix | Document | Type |
|---|---|---|
| ProjectDesign_ | Design v2 | design |
| ProjectDesign_ | Decisions v2 | decisions |
| ProjectDesign_ | Standard v4 | standard |
| ProjectDesign_ | Schema Standard v1 | standard |

## Parts

None declared.
