# Standards

Role: component design

Standards defines how to create, design, build, and use a standard within the AIDE framework. It is a methodological component — it does not hold all standards. Individual standards are designed and owned by the component or area they serve, under the what-knows-most-about-it principle.

As a capability, Standards owns the definition of what a standard is, the authoring guidance (including leanness), and the pipeline from reference knowledge to deployed standard.

## Documents

| Prefix | Document | Type |
|---|---|---|
| Standards_ | Design v2 | design |
| Standards_ | Decisions v2 | decisions |
| Standards_ | Working v1 | working |
| Standards_ | Authoring Standard v6 | standard |
| Standards_ | Consumption Standard v3 | standard |
| Standards_ | Schema Standard v1 | standard |
