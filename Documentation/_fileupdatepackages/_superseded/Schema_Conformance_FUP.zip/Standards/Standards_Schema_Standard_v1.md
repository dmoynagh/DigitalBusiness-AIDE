> identity: Standards_Schema_Standard@v1 | doctype: standard | date: 2026-09-12
> uses: DocMeth:[Definitions_Standard@v4]

# Standards — Schema Standard

The doctype and block-type definitions owned by Standards.

## What this standard is for

Information. This standard defines the standard doctype and the clarification block type. For how to author a standard, see the Standards Authoring Standard. For how to operate under applicable standards, see the Standards Consumption Standard.

## Doctypes

### Standard

- **Purpose:** Defines rules, expectations, guidance and context that shape decisions and behaviour while work is being done. Reaches the AI platform as a capability — a skill loaded on trigger, or binder content in project context.
- **Included blocktypes:** Contents (recommended), Version note (recommended), Clarification (optional).
- **Format constraint:** markdown.

Information. A standard has no prescribed template. The author decides what it contains and how it is structured, provided the authoring rules are met. The clarification block carries reasoning and justification that would bloat the lean standard if kept inline — joined when small, split by the split test.

## Block types

### Clarification

- **Purpose:** Reasoning, justification, and elaboration behind the standard's rules. The standard itself is lean and stated; clarification is where the why lives when it would compromise leanness to keep it inline.
- **Recognition:** by subheading — a Clarification heading within or alongside the standard body.

Information. When small, clarification content sits within the standard's body sections. When it would bloat the loaded standard, the split test moves it to a separate section or document. The term "clarification" is agreed vocabulary — not "rationale", "commentary", or "appendix".

---

Version note: v1 — initial schema definitions for Standards. 2026-09-12.
