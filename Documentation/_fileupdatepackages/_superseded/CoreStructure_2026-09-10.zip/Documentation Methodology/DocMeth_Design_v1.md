Documentation Methodology | design | DocMeth_Design@v1 | 2026-09-10

## Status

Awaiting the full design pass. Substantial content exists in the settled rebuild decisions (extracted from WIP v22) covering the doctype/block-type model, the block catalogue, the versioning model, format rules, and the decisions doctype. This document will be populated when that material is worked through.
