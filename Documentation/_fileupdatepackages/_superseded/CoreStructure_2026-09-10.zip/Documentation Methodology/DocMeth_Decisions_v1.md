Documentation Methodology | decisions | DocMeth_Decisions@v1 | 2026-09-10

## Status

Awaiting the full design pass. Reasoning from the rebuild sessions covering doctypes, block types, versioning, and format rules will be consolidated here from the settled rebuild decisions and session transcripts.
