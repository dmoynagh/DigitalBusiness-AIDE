# Cross-review request — Tools_Authoring_Standard_v5

## What you are reviewing

The Tools Authoring Standard v5 — the deployed standard a tool author consumes when designing, authoring, and deploying a tool within the AIDE framework.

## What changed (v4 → v5)

The standard previously named a closed list of five authoring rules from the Standards Authoring Standard (carry test, leanness, discriminating guidance, strength assignment, self-containment). The Standards Authoring Standard expanded to eight rules in v6–v7, adding no-consumer-no-rule, applicability scope, and name-your-principles, plus the acceptance test.

The update removes the named list and references the authoring rules generically as "the authoring rules in the standards authoring standard" — capability-wide, consumed by reference. The `uses` declaration is updated from @v5 to @v7. The Tools Design and Decisions were updated alongside.

No other content changed — the seven authoring concerns, invocability test, staging clause, sibling-outputs model, ask/infer/escalate, idempotency, trigger description, applicability scope, deployment, and ownership sections are unchanged.

## Review against

1. **The Standards Authoring Standard v7** (attached) — specifically the eight authoring rules, the acceptance test, the strength model, and the self-containment rule. Does the Tools standard correctly consume these?

2. **The acceptance test**: given only Tools_Authoring_Standard_v5 and its declared dependency (Standards_Authoring_Standard_v7), can a fresh AI design, author, and deploy a tool? Is any convention left to invention?

3. **Internal consistency**: does the standard contradict itself, leave gaps, or carry anything that fails the carry test?

4. **The change itself**: is the generic reference to "the authoring rules" better or worse than naming them? Does anything important get lost?

## Documents attached

1. Tools_Authoring_Standard_v5.md — the standard under review
2. Tools_Design_v4.md — the design it was authored from
3. Tools_Decisions_v5.md — the reasoning behind decisions, including D15 (the update rationale)
4. Standards_Authoring_Standard_v7.md — the standard it declares a dependency on

## Findings format

For each finding, state:
- **ID** (F1, F2, ...)
- **Location** in the standard
- **The finding** — what is wrong, missing, or inconsistent
- **Severity** — defect (must fix), concern (should consider), or observation (note for the record)
- **Suggested fix** if you have one
